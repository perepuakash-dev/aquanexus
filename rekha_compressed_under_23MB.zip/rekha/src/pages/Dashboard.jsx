import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { vehicleApi, customerApi, rentalApi, ownerApi } from '../services/api';
import { isVehicleRentedToday, formatDisplayDate } from '../utils/dateUtils';
import { LoadingSpinner, ErrorBanner } from '../components/LoadingState';
import {
  Car,
  Bike,
  CheckCircle,
  XCircle,
  Users,
  CalendarCheck,
  Clock,
  IndianRupee,
  PlusCircle,
  UserPlus,
  ArrowRight,
  TrendingUp,
  MapPin,
  ShieldCheck,
  Sparkles,
  Check,
  AlertTriangle,
  FileCheck,
} from 'lucide-react';

export default function Dashboard() {
  const navigate = useNavigate();
  const [vehicles, setVehicles] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [rentals, setRentals] = useState([]);
  const [owners, setOwners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  const fetchDashboardData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [vData, cData, rData, oData] = await Promise.all([
        vehicleApi.getAll(),
        customerApi.getAll(),
        rentalApi.getAll(),
        ownerApi.getAll(),
      ]);
      setVehicles(vData || []);
      setCustomers(cData || []);
      setRentals(rData || []);
      setOwners(oData || []);
    } catch (err) {
      setError(err.message || 'Failed to fetch dashboard metrics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleVerifyOwner = async (owner) => {
    try {
      const updated = await ownerApi.update(owner.id, {
        ...owner,
        verificationStatus: 'Verified',
      });
      setOwners((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
      setSuccessMessage(`Owner "${owner.name}" has been Verified.`);
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      alert(`Verification failed: ${err.message}`);
    }
  };

  if (loading) {
    return <LoadingSpinner message="Calculating live platform metrics..." />;
  }

  if (error) {
    return <ErrorBanner message={error} onRetry={fetchDashboardData} />;
  }

  // 11 Core Required Metrics:
  const totalOwners = owners.length;
  const totalCustomers = customers.length;
  const totalCars = vehicles.filter((v) => v.type === 'Car' || (!v.type && v.category !== 'Bike')).length;
  const totalBikes = vehicles.filter((v) => v.type === 'Bike' || v.category === 'Bike').length;
  const totalListedVehicles = vehicles.length;

  const availableVehiclesCount = vehicles.filter(
    (v) => v.available && !isVehicleRentedToday(v.id, rentals)
  ).length;

  const pendingOwnerVerifications = owners.filter((o) => o.verificationStatus === 'Pending');
  const totalBookings = rentals.length;

  const pendingBookingRequests = rentals.filter(
    (r) => (r.bookingStatus || r.status || '').toLowerCase() === 'pending'
  );

  const completedRentals = rentals.filter(
    (r) => (r.bookingStatus || r.status || '').toLowerCase() === 'completed'
  );

  const totalRentalValue = rentals
    .filter((r) => {
      const s = (r.bookingStatus || r.status || '').toLowerCase();
      return s === 'completed' || s === 'approved' || s === 'ongoing';
    })
    .reduce((sum, r) => sum + Number(r.totalAmount || 0), 0);

  const recentRentals = [...rentals].reverse().slice(0, 5);

  const getCustomerName = (cId) => {
    const cust = customers.find((c) => String(c.id) === String(cId));
    return cust ? cust.name : `Customer #${cId}`;
  };

  const getVehicleName = (vId) => {
    const v = vehicles.find((item) => String(item.id) === String(vId));
    return v ? `${v.name}` : `Vehicle #${vId}`;
  };

  const getOwnerName = (oId) => {
    const o = owners.find((item) => String(item.id) === String(oId));
    return o ? o.name : 'Platform Host';
  };

  return (
    <div>
      {successMessage && (
        <div className="alert alert-success" style={{ marginBottom: '1.25rem' }}>
          <Check size={18} />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Header & Quick Action Bar */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '1rem',
          marginBottom: '1.75rem',
        }}
      >
        <div>
          <h2 style={{ fontSize: '1.35rem', fontWeight: '800', color: 'var(--text-main)', margin: 0 }}>
            Admin Management Console
          </h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flexWrap: 'wrap', marginTop: '0.3rem' }}>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', margin: 0 }}>
              Platform Owners: <strong>Rayudi Rekha</strong> • <strong>Kumpatla Reethuka</strong> • <strong>Shaik Najirin</strong> • <strong>Sivadalla Praveen</strong>
            </p>
            <span
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.3rem',
                fontSize: '0.75rem',
                fontWeight: '600',
                color: 'var(--primary)',
                backgroundColor: 'var(--primary-light)',
                padding: '0.2rem 0.55rem',
                borderRadius: 'var(--radius-full)',
                border: '1px solid var(--primary-border)',
              }}
            >
              <MapPin size={12} /> Hub: ATV Tadepalligudem
            </span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '0.65rem', flexWrap: 'wrap' }}>
          <button
            className="btn btn-secondary"
            onClick={() => navigate('/marketplace')}
          >
            <Sparkles size={16} /> Public Marketplace
          </button>
          <button
            className="btn btn-secondary"
            onClick={() => navigate('/owners')}
          >
            <Users size={16} /> Manage Owners
          </button>
          <button
            className="btn btn-secondary"
            onClick={() => navigate('/owner-dashboard')}
          >
            <Car size={16} /> Owner Portal
          </button>
          <button
            className="btn btn-primary"
            onClick={() => navigate('/book')}
          >
            <CalendarCheck size={16} /> New Booking
          </button>
        </div>
      </div>

      {/* Pending Owner Verifications Alert Banner */}
      {pendingOwnerVerifications.length > 0 && (
        <div
          style={{
            backgroundColor: '#fffbeb',
            border: '1px solid #fde68a',
            borderRadius: 'var(--radius-md)',
            padding: '1rem 1.25rem',
            marginBottom: '1.75rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '1rem',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: '#fef3c7', color: '#b45309', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Clock size={20} />
            </div>
            <div>
              <strong style={{ fontSize: '0.95rem', color: '#92400e', display: 'block' }}>
                {pendingOwnerVerifications.length} Vehicle Owner(s) Awaiting Admin Verification
              </strong>
              <span style={{ fontSize: '0.8rem', color: '#b45309' }}>
                Review ID & licence records to enable their vehicles on the public marketplace.
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '0.5rem' }}>
            {pendingOwnerVerifications.slice(0, 2).map((o) => (
              <button
                key={o.id}
                type="button"
                className="btn btn-sm btn-primary"
                onClick={() => handleVerifyOwner(o)}
              >
                Verify {o.name}
              </button>
            ))}
            <button
              type="button"
              className="btn btn-sm btn-secondary"
              onClick={() => navigate('/owners?status=Pending')}
            >
              View All ({pendingOwnerVerifications.length})
            </button>
          </div>
        </div>
      )}

      {/* SECTION 7 REQUIRED KPIS - ROW 1 */}
      <div className="stats-grid" style={{ marginBottom: '1.25rem' }}>
        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Vehicle Owners</span>
            <span className="stat-value">{totalOwners}</span>
            <span className="stat-subtext">{owners.filter((o) => o.verificationStatus === 'Verified').length} verified hosts</span>
          </div>
          <div className="stat-icon purple">
            <Users size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Customers</span>
            <span className="stat-value">{totalCustomers}</span>
            <span className="stat-subtext">Registered clients</span>
          </div>
          <div className="stat-icon blue">
            <Users size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Cars</span>
            <span className="stat-value">{totalCars}</span>
            <span className="stat-subtext">SUVs, sedans, MPVs</span>
          </div>
          <div className="stat-icon blue">
            <Car size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Bikes</span>
            <span className="stat-value">{totalBikes}</span>
            <span className="stat-subtext">Cruisers, sports, scooters</span>
          </div>
          <div className="stat-icon green">
            <Bike size={22} />
          </div>
        </div>
      </div>

      {/* SECTION 7 REQUIRED KPIS - ROW 2 */}
      <div className="stats-grid" style={{ marginBottom: '1.75rem' }}>
        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Listed Vehicles</span>
            <span className="stat-value">{totalListedVehicles}</span>
            <span className="stat-subtext">{availableVehiclesCount} available right now</span>
          </div>
          <div className="stat-icon blue">
            <Car size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Pending Verifications</span>
            <span className="stat-value" style={{ color: pendingOwnerVerifications.length > 0 ? 'var(--warning)' : 'var(--success)' }}>
              {pendingOwnerVerifications.length}
            </span>
            <span className="stat-subtext">Host onboarding queue</span>
          </div>
          <div className="stat-icon amber">
            <Clock size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Bookings</span>
            <span className="stat-value">{totalBookings}</span>
            <span className="stat-subtext">{pendingBookingRequests.length} pending owner approval</span>
          </div>
          <div className="stat-icon blue">
            <CalendarCheck size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Rental Value</span>
            <span className="stat-value" style={{ color: 'var(--success)' }}>
              ₹{totalRentalValue.toLocaleString('en-IN')}
            </span>
            <span className="stat-subtext">From {completedRentals.length} completed rentals</span>
          </div>
          <div className="stat-icon green">
            <IndianRupee size={22} />
          </div>
        </div>
      </div>

      {/* Quick Access Grid: Owners & Marketplace */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginBottom: '1.75rem' }}>
        {/* Verified Owners Snapshot */}
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Active Vehicle Owners</div>
              <div className="card-subtitle">Host partners listing cars and bikes on platform</div>
            </div>
            <Link to="/owners" className="btn btn-sm btn-secondary">
              All Owners <ArrowRight size={14} />
            </Link>
          </div>
          <div className="card-body" style={{ padding: '0.75rem 1.25rem' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {owners.map((o) => {
                const ownerVehiclesCount = vehicles.filter((v) => String(v.ownerId) === String(o.id)).length;
                return (
                  <div
                    key={o.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '0.5rem 0',
                      borderBottom: '1px solid var(--border-color)',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                      <img
                        src={o.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
                        alt={o.name}
                        style={{ width: '36px', height: '36px', borderRadius: '50%', objectFit: 'cover' }}
                      />
                      <div>
                        <strong style={{ fontSize: '0.88rem', color: 'var(--text-main)', display: 'block' }}>
                          {o.name}
                        </strong>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {o.city} • {ownerVehiclesCount} {ownerVehiclesCount === 1 ? 'vehicle' : 'vehicles'}
                        </span>
                      </div>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span className={`badge ${o.verificationStatus === 'Verified' ? 'badge-available' : 'badge-warning'}`} style={{ fontSize: '0.7rem' }}>
                        {o.verificationStatus}
                      </span>
                      <Link to={`/owner-dashboard?ownerId=${o.id}`} className="btn btn-sm btn-secondary" style={{ fontSize: '0.75rem', padding: '0.2rem 0.5rem' }}>
                        View Portal
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Fleet Distribution */}
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Fleet Distribution & Hub Operations</div>
              <div className="card-subtitle">All vehicles stationed at Tadepalligudem</div>
            </div>
            <Link to="/marketplace" className="btn btn-sm btn-secondary">
              Browse Marketplace <ArrowRight size={14} />
            </Link>
          </div>
          <div className="card-body">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.35rem', fontSize: '0.88rem' }}>
                  <span style={{ fontWeight: '600' }}>Cars Fleet</span>
                  <span style={{ color: 'var(--text-muted)' }}><strong>{totalCars}</strong> vehicles ({Math.round((totalCars / (totalListedVehicles || 1)) * 100)}%)</span>
                </div>
                <div style={{ height: '8px', backgroundColor: '#e2e8f0', borderRadius: '999px', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${(totalCars / (totalListedVehicles || 1)) * 100}%`, backgroundColor: 'var(--primary)', borderRadius: '999px' }} />
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.35rem', fontSize: '0.88rem' }}>
                  <span style={{ fontWeight: '600' }}>Bikes & Scooters</span>
                  <span style={{ color: 'var(--text-muted)' }}><strong>{totalBikes}</strong> vehicles ({Math.round((totalBikes / (totalListedVehicles || 1)) * 100)}%)</span>
                </div>
                <div style={{ height: '8px', backgroundColor: '#e2e8f0', borderRadius: '999px', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${(totalBikes / (totalListedVehicles || 1)) * 100}%`, backgroundColor: 'var(--success)', borderRadius: '999px' }} />
                </div>
              </div>

              <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)', padding: '0.85rem', marginTop: '0.5rem', fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                📍 <strong>Operating Location:</strong> Exclusive vehicle rental hub active at <strong>ATV Tadepalligudem</strong>. All registered host vehicles are available for inspection and customer pickup.
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Indian Car Fleet Showcase */}
      <div className="card" style={{ marginBottom: '1.75rem' }}>
        <div className="card-header">
          <div>
            <div className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
              <Car size={18} style={{ color: 'var(--primary)' }} />
              Indian Cars Fleet Showcase
            </div>
            <div className="card-subtitle">
              Verified Indian-market models: Swift, Baleno, Creta, i20, Nexon, Punch, XUV700, Innova Crysta, Sonet & Ertiga
            </div>
          </div>
          <Link to="/marketplace" className="btn btn-sm btn-secondary">
            Explore Marketplace <ArrowRight size={14} />
          </Link>
        </div>
        <div className="card-body">
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))',
              gap: '1rem',
            }}
          >
            {vehicles
              .filter((v) => v.type === 'Car' || (!v.type && v.category !== 'Bike'))
              .slice(0, 5)
              .map((car) => {
                const owner = owners.find((o) => String(o.id) === String(car.ownerId));
                return (
                  <div
                    key={car.id}
                    onClick={() => navigate(`/vehicles/view/${car.id}`)}
                    style={{
                      border: '1px solid var(--border-color)',
                      borderRadius: 'var(--radius-md)',
                      overflow: 'hidden',
                      cursor: 'pointer',
                      transition: 'transform 0.2s ease, box-shadow 0.2s ease',
                      backgroundColor: 'var(--card-bg)',
                    }}
                  >
                    <div style={{ height: '130px', overflow: 'hidden', position: 'relative' }}>
                      <img
                        src={car.imageUrl}
                        alt={car.name}
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      />
                      <span
                        className="badge badge-category"
                        style={{ position: 'absolute', top: '0.4rem', left: '0.4rem', fontSize: '0.68rem' }}
                      >
                        {car.category}
                      </span>
                    </div>
                    <div style={{ padding: '0.75rem' }}>
                      <strong style={{ fontSize: '0.88rem', display: 'block', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {car.name}
                      </strong>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.35rem' }}>
                        {car.brand} • {car.seatingCapacity || 5} Seats • {car.fuelType}
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '0.4rem', borderTop: '1px dashed var(--border-color)' }}>
                        <span style={{ fontSize: '0.85rem', fontWeight: '700', color: 'var(--primary)' }}>
                          ₹{Number(car.pricePerDay).toLocaleString('en-IN')}/day
                        </span>
                        <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                          Host: {owner ? owner.name.split(' ')[0] : 'Host'}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      {/* Recent Bookings Table */}
      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Recent Platform Rental Transactions</div>
            <div className="card-subtitle">Real-time marketplace booking requests across all vehicle hosts</div>
          </div>
          <Link to="/rentals" className="btn btn-sm btn-secondary">
            View All Rentals <ArrowRight size={14} />
          </Link>
        </div>

        <div className="card-body" style={{ padding: 0 }}>
          {recentRentals.length === 0 ? (
            <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
              No rental transactions recorded yet.
            </div>
          ) : (
            <div className="table-container" style={{ border: 'none', borderRadius: 0 }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Rental ID</th>
                    <th>Customer</th>
                    <th>Vehicle</th>
                    <th>Vehicle Owner</th>
                    <th>Rental Dates</th>
                    <th>Days</th>
                    <th>Total Fee</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentRentals.map((r) => {
                    const statusClass = (r.bookingStatus || r.status || '').toLowerCase();
                    return (
                      <tr key={r.id}>
                        <td>
                          <span style={{ fontFamily: 'monospace', fontWeight: '700', color: 'var(--primary)' }}>
                            #{r.id}
                          </span>
                        </td>
                        <td>
                          <strong>{getCustomerName(r.customerId)}</strong>
                        </td>
                        <td>{getVehicleName(r.vehicleId)}</td>
                        <td>
                          <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                            {getOwnerName(r.ownerId)}
                          </span>
                        </td>
                        <td>
                          {formatDisplayDate(r.startDate)} → {formatDisplayDate(r.endDate)}
                        </td>
                        <td>{r.numberOfDays || r.days} days</td>
                        <td>
                          <strong>₹{Number(r.totalAmount || 0).toLocaleString('en-IN')}</strong>
                        </td>
                        <td>
                          <span className={`badge badge-${statusClass === 'approved' ? 'available' : statusClass === 'pending' ? 'warning' : statusClass}`}>
                            {r.bookingStatus || r.status || 'Active'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}