import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { vehicleApi, ownerApi, customerApi, rentalApi } from '../services/api';
import { calculateRentalDays, findConflictingRental, formatDisplayDate, getTodayDateString } from '../utils/dateUtils';
import { LoadingSpinner, ErrorBanner } from '../components/LoadingState';
import PhonePePaymentModal from '../components/PhonePePaymentModal';
import {
  Car,
  Bike,
  ArrowLeft,
  MapPin,
  CheckCircle2,
  Calendar,
  Fuel,
  Users,
  Gauge,
  ShieldCheck,
  Phone,
  Mail,
  Clock,
  Sparkles,
  Check,
  AlertCircle,
  HelpCircle,
  Package,
  Smartphone,
} from 'lucide-react';

export default function VehicleDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [vehicle, setVehicle] = useState(null);
  const [owner, setOwner] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [rentals, setRentals] = useState([]);
  const [selectedImage, setSelectedImage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Booking Widget State
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [startDate, setStartDate] = useState(getTodayDateString());
  const [endDate, setEndDate] = useState('');
  const [dateConflict, setDateConflict] = useState(null);
  const [isBooking, setIsBooking] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(null);
  const [bookingErrors, setBookingErrors] = useState({});

  useEffect(() => {
    const fetchVehicleDetails = async () => {
      setLoading(true);
      setError(null);
      try {
        const [vData, oData, cData, rData] = await Promise.all([
          vehicleApi.getById(id),
          ownerApi.getAll(),
          customerApi.getAll(),
          rentalApi.getAll(),
        ]);

        setVehicle(vData);
        setCustomers(cData || []);
        setRentals(rData || []);

        // Find owner
        const targetOwner = (oData || []).find((o) => String(o.id) === String(vData.ownerId));
        setOwner(targetOwner || null);

        // Primary image
        const imgList = Array.isArray(vData.images) && vData.images.length > 0
          ? vData.images
          : [vData.imageUrl || '/front-left-side-47.avif'];
        setSelectedImage(imgList[0]);
      } catch (err) {
        setError(err.message || 'Vehicle details not found.');
      } finally {
        setLoading(false);
      }
    };

    fetchVehicleDetails();
  }, [id]);

  const isBike =
    vehicle?.type === 'Bike' ||
    ['Cruiser', 'Sports', 'Commuter', 'Scooter'].includes(vehicle?.category) ||
    vehicle?.category === 'Bike';

  // Rental Duration & Charge Calculations
  const rentalDays = (startDate && endDate)
    ? calculateRentalDays(startDate, endDate)
    : 0;

  const dailyRate = Number(vehicle?.pricePerDay || 0);
  const securityDeposit = Number(vehicle?.securityDeposit || 0);
  const totalRentalAmount = rentalDays > 0 ? rentalDays * dailyRate : 0;

  // Real-time conflict checking
  useEffect(() => {
    if (vehicle && startDate && endDate && rentalDays > 0) {
      const conflict = findConflictingRental(rentals, vehicle.id, startDate, endDate);
      setDateConflict(conflict || null);
    } else {
      setDateConflict(null);
    }
  }, [vehicle, startDate, endDate, rentalDays, rentals]);

  // Trigger Payment Step
  const handleBookingSubmit = (e) => {
    e.preventDefault();
    const newErrors = {};

    if (!customerName || !customerName.trim()) {
      newErrors.customerName = 'Please enter your name.';
    }
    if (!startDate) {
      newErrors.startDate = 'Start date is required.';
    }
    if (!endDate) {
      newErrors.endDate = 'End date is required.';
    }
    if (startDate && endDate && rentalDays <= 0) {
      newErrors.endDate = 'End date must be after the start date (at least 1 day).';
    }
    if (dateConflict) {
      newErrors.conflict = 'Vehicle is already reserved for the selected dates.';
    }

    if (Object.keys(newErrors).length > 0) {
      setBookingErrors(newErrors);
      return;
    }

    setBookingErrors({});
    setIsPaymentModalOpen(true);
  };

  // Called after scanning PhonePe QR and entering Transaction ID / choosing pay at hub
  const handlePaymentSuccess = async (paymentDetails) => {
    setIsBooking(true);
    try {
      let finalCustomerId = '1';
      const cleanName = customerName.trim();
      const existingCust = customers.find(
        (c) =>
          c.name?.toLowerCase() === cleanName.toLowerCase() ||
          (customerPhone && c.phone === customerPhone.trim())
      );

      if (existingCust) {
        finalCustomerId = String(existingCust.id);
      } else if (cleanName) {
        try {
          const newCust = await customerApi.create({
            name: cleanName,
            phone: customerPhone.trim() || '9876543210',
            email: `${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '')}@gmail.com`,
            city: 'Tadepalligudem',
            address: 'Tadepalligudem, AP',
            drivingLicenceNumber: `AP${Math.floor(100000 + Math.random() * 900000)}`,
            createdAt: new Date().toISOString(),
          });
          finalCustomerId = String(newCust.id);
          setCustomers((prev) => [...prev, newCust]);
        } catch (cErr) {
          console.warn('Customer auto-create note:', cErr);
          finalCustomerId = String(Date.now());
        }
      }

      const payload = {
        customerId: finalCustomerId,
        customerName: cleanName,
        customerPhone: customerPhone.trim(),
        vehicleId: String(vehicle.id),
        ownerId: String(vehicle.ownerId || owner?.id || '1'),
        startDate: startDate,
        endDate: endDate,
        numberOfDays: rentalDays,
        days: rentalDays,
        pricePerDay: dailyRate,
        dailyPrice: dailyRate,
        securityDeposit: securityDeposit,
        totalAmount: totalRentalAmount,
        pickupLocation: vehicle.pickupLocation || 'ATV Tadepalligudem',
        location: vehicle.pickupLocation || 'ATV Tadepalligudem',
        bookingStatus: 'Pending',
        status: 'Pending',
        paymentMethod: paymentDetails.paymentMethod,
        paymentNumber: paymentDetails.paymentNumber || '9492343566',
        upiId: paymentDetails.upiId || '9492343566@ybl',
        transactionId: paymentDetails.transactionId,
        paymentStatus: paymentDetails.paymentStatus,
        createdAt: new Date().toISOString(),
      };

      const created = await rentalApi.create(payload);
      setBookingSuccess(created);
      setIsPaymentModalOpen(false);
    } catch (err) {
      alert(`Booking request failed: ${err.message}`);
    } finally {
      setIsBooking(false);
    }
  };

  if (loading) {
    return <LoadingSpinner message="Loading full vehicle specifications..." />;
  }

  if (error || !vehicle) {
    return (
      <div>
        <Link to="/" className="btn btn-secondary" style={{ marginBottom: '1rem' }}>
          <ArrowLeft size={16} /> Back to Car Catalogue
        </Link>
        <ErrorBanner message={error || 'Vehicle not found.'} />
      </div>
    );
  }

  const galleryImages = Array.isArray(vehicle.images) && vehicle.images.length > 0
    ? vehicle.images
    : [vehicle.imageUrl || '/front-left-side-47.avif'];

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
      {/* Back button & Breadcrumb */}
      <div style={{ marginBottom: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Link to="/" className="btn btn-sm btn-secondary">
          <ArrowLeft size={14} /> Back to Car Catalogue
        </Link>
        <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
          Vehicle ID: #{vehicle.id} • Registered Hub: <strong>{vehicle.pickupLocation || 'ATV Tadepalligudem'}</strong>
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '2rem', alignItems: 'start' }}>
        {/* LEFT COLUMN: Gallery & Full Specifications */}
        <div>
          {/* Main Hero Image */}
          <div
            style={{
              width: '100%',
              height: '420px',
              borderRadius: 'var(--radius-lg)',
              overflow: 'hidden',
              backgroundColor: '#000000',
              marginBottom: '1rem',
              boxShadow: 'var(--shadow-md)',
              position: 'relative',
            }}
          >
            <img
              src={selectedImage || galleryImages[0]}
              alt={vehicle.name}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
            <span
              className={`badge ${vehicle.available ? 'badge-available' : 'badge-unavailable'}`}
              style={{ position: 'absolute', top: '1rem', right: '1rem', fontSize: '0.85rem', padding: '0.4rem 0.8rem', zIndex: 4 }}
            >
              {vehicle.available ? 'Available for Rent' : 'Currently Booked'}
            </span>

            {/* Car Name overlay on original image */}
            <div
              style={{
                position: 'absolute',
                bottom: 0,
                left: 0,
                right: 0,
                background: 'linear-gradient(to top, rgba(15, 23, 42, 0.95) 0%, rgba(15, 23, 42, 0.5) 60%, transparent 100%)',
                padding: '1.75rem 1.5rem 1rem 1.5rem',
                display: 'flex',
                alignItems: 'flex-end',
                justifyContent: 'space-between',
                gap: '1rem',
                zIndex: 3,
              }}
            >
              <div>
                <span style={{ fontSize: '0.75rem', fontWeight: '700', color: '#93c5fd', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Original Indian Vehicle Image • {vehicle.category}
                </span>
                <h2 style={{ fontSize: '1.65rem', fontWeight: '800', color: '#ffffff', margin: '0.2rem 0 0 0', textShadow: '0 2px 4px rgba(0,0,0,0.8)' }}>
                  {vehicle.name}
                </h2>
                <div style={{ fontSize: '0.85rem', color: '#e2e8f0', marginTop: '0.2rem' }}>
                  Brand: <strong>{vehicle.brand}</strong> • Model: <strong>{vehicle.model}</strong> • Owner: <strong>{owner?.name || 'Rayudi Rekha'}</strong>
                </div>
              </div>
              <div style={{ textAlign: 'right', flexShrink: 0 }}>
                <span
                  style={{
                    backgroundColor: 'rgba(37, 99, 235, 0.9)',
                    color: '#ffffff',
                    padding: '0.35rem 0.75rem',
                    borderRadius: 'var(--radius-sm)',
                    fontSize: '0.82rem',
                    fontWeight: '700',
                    display: 'inline-block',
                    boxShadow: '0 2px 6px rgba(0,0,0,0.4)',
                  }}
                >
                  Original Image
                </span>
              </div>
            </div>
          </div>

          {/* Thumbnail Strip: Front, Side, Rear Views */}
          {galleryImages.length > 1 && (
            <div style={{ display: 'flex', gap: '0.85rem', marginBottom: '1.5rem', overflowX: 'auto', paddingBottom: '0.25rem' }}>
              {galleryImages.map((img, index) => {
                const angleNames = ['Front View', 'Side Profile', 'Rear Angle', 'Interior'];
                const angleLabel = angleNames[index] || `Angle ${index + 1}`;
                const isSelected = (selectedImage || galleryImages[0]) === img;

                return (
                  <div key={index} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.3rem' }}>
                    <button
                      type="button"
                      onClick={() => setSelectedImage(img)}
                      style={{
                        width: '95px',
                        height: '65px',
                        borderRadius: 'var(--radius-sm)',
                        overflow: 'hidden',
                        border: isSelected ? '3px solid var(--primary)' : '1px solid var(--border-color)',
                        padding: 0,
                        cursor: 'pointer',
                        background: 'none',
                        flexShrink: 0,
                        boxShadow: isSelected ? '0 0 0 2px rgba(37,99,235,0.25)' : 'none',
                      }}
                      title={`View ${angleLabel}`}
                    >
                      <img src={img} alt={angleLabel} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    </button>
                    <span
                      style={{
                        fontSize: '0.7rem',
                        fontWeight: isSelected ? '700' : '500',
                        color: isSelected ? 'var(--primary)' : 'var(--text-muted)',
                      }}
                    >
                      {angleLabel}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Title & Brand */}
          <div style={{ marginBottom: '1.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.3rem' }}>
              <span className="badge badge-category" style={{ fontSize: '0.82rem' }}>
                {isBike ? '🏍️ Motorcycle' : '🚗 Car'} • {vehicle.category}
              </span>
              <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                Reg: <strong>{vehicle.registrationNumber}</strong>
              </span>
            </div>
            <h1 style={{ fontSize: '1.9rem', fontWeight: '800', color: 'var(--text-main)', margin: '0.2rem 0' }}>
              {vehicle.name}
            </h1>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>
              {vehicle.brand} • {vehicle.model} • Manufacturing Year: {vehicle.manufacturingYear || '2024'}
            </p>
          </div>

          {/* Description */}
          <div className="card" style={{ marginBottom: '1.5rem' }}>
            <div className="card-body">
              <h3 style={{ fontSize: '1.05rem', fontWeight: '700', marginBottom: '0.5rem' }}>
                Vehicle Overview
              </h3>
              <p style={{ fontSize: '0.92rem', lineHeight: 1.6, color: 'var(--text-main)' }}>
                {vehicle.description || 'No detailed description provided for this vehicle.'}
              </p>
            </div>
          </div>

          {/* Specifications Grid */}
          <div className="card" style={{ marginBottom: '1.5rem' }}>
            <div className="card-header">
              <div className="card-title">Detailed Vehicle Specifications</div>
            </div>
            <div className="card-body">
              {isBike ? (
                /* BIKE SPECIFICATIONS GRID */
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem' }}>
                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Engine Capacity:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.engineCapacityCC || '349'} CC
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Fuel Type:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.fuelType || 'Petrol'}
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Transmission:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.transmission || 'Manual'}
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Mileage:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.mileageKmpl || '35'} km/l
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Fuel Tank Capacity:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.fuelTankCapacity || '13 Litres'}
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Max Power:</span>
                    <div style={{ fontWeight: '700', fontSize: '0.95rem', marginTop: '0.15rem' }}>
                      {vehicle.maxPower || '20.2 bhp'}
                    </div>
                  </div>
                </div>
              ) : (
                /* CAR SPECIFICATIONS GRID */
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem' }}>
                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Seating Capacity:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.seatingCapacity || 5} Passenger Seats
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Fuel Type:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.fuelType || 'Petrol'}
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Transmission:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.transmission || 'Automatic'}
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Mileage:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.mileageKmpl || '18'} km/l
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Air Conditioning:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.airConditioning || 'AC'}
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Boot Space:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.bootSpace || '433 Litres'}
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Doors:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.doors || 4} Doors
                    </div>
                  </div>

                  <div style={{ padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Engine Capacity:</span>
                    <div style={{ fontWeight: '700', fontSize: '1rem', marginTop: '0.15rem' }}>
                      {vehicle.engineCapacityCC || '1498'} CC
                    </div>
                  </div>
                </div>
              )}

              {/* Features & Facilities Checklist */}
              {Array.isArray(vehicle.features) && vehicle.features.length > 0 && (
                <div style={{ marginTop: '1.25rem', paddingTop: '1.25rem', borderTop: '1px solid var(--border-color)' }}>
                  <h4 style={{ fontSize: '0.9rem', fontWeight: '700', marginBottom: '0.65rem' }}>
                    Features & Amenities Included
                  </h4>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.45rem' }}>
                    {vehicle.features.map((feat) => (
                      <span
                        key={feat}
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '0.25rem',
                          backgroundColor: 'var(--primary-light)',
                          color: 'var(--primary)',
                          padding: '0.3rem 0.65rem',
                          borderRadius: 'var(--radius-sm)',
                          fontSize: '0.8rem',
                          fontWeight: '600',
                          border: '1px solid var(--primary-border)',
                        }}
                      >
                        <Check size={13} /> {feat}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Rental Policies Card */}
          <div className="card">
            <div className="card-header">
              <div className="card-title">Rental Terms & Policies</div>
            </div>
            <div className="card-body" style={{ fontSize: '0.88rem', color: 'var(--text-main)', lineHeight: 1.6 }}>
              <ul style={{ paddingLeft: '1.25rem', display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                <li><strong>Refundable Security Deposit:</strong> ₹{vehicle.securityDeposit || 3000} collected at pickup and refunded immediately upon return.</li>
                <li><strong>Minimum Duration:</strong> {vehicle.minRentalDuration || 1} day(s). Maximum booking: {vehicle.maxRentalDuration || 30} days.</li>
                <li><strong>Pickup Hub:</strong> {vehicle.pickupLocation || 'ATV Tadepalligudem'}. {vehicle.deliveryAvailable ? 'Home doorstep delivery is available.' : 'Self-pickup at hub.'}</li>
                <li><strong>Driving Licence:</strong> A valid Indian Driving Licence (original) must be presented during vehicle handover.</li>
              </ul>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Owner Profile & Direct Booking Widget */}
        <div>
          {/* Owner Profile Card */}
          <div className="card" style={{ marginBottom: '1.5rem' }}>
            <div className="card-body">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.85rem' }}>
                <img
                  src={
                    owner?.avatar ||
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
                  }
                  alt={owner?.name || 'Owner'}
                  style={{ width: '56px', height: '56px', borderRadius: '50%', objectFit: 'cover', border: '2px solid var(--border-color)' }}
                />
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    <h3 style={{ fontSize: '1.1rem', fontWeight: '800', margin: 0 }}>
                      {owner ? owner.name : 'Host Partner'}
                    </h3>
                    <CheckCircle2 size={16} style={{ color: 'var(--success)' }} title="Verified Owner" />
                  </div>
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    Host in {owner?.city || 'Tadepalligudem'} • Member since {owner?.registrationDate || '2026'}
                  </div>
                </div>
              </div>

              {owner?.bio && (
                <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', fontStyle: 'italic', marginBottom: '0.85rem' }}>
                  "{owner.bio}"
                </p>
              )}

              <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '0.75rem', fontSize: '0.82rem', display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Phone Contact:</span>
                  <strong>{owner?.phone || 'Verified on booking'}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Location:</span>
                  <span>{owner?.city || 'Tadepalligudem'}, AP</span>
                </div>
              </div>
            </div>
          </div>

          {/* Booking Widget Card */}
          <div className="card" style={{ border: '2px solid var(--primary-border)', position: 'sticky', top: '90px' }}>
            <div className="card-header" style={{ backgroundColor: 'var(--primary-light)' }}>
              <div>
                <div style={{ fontSize: '1.35rem', fontWeight: '800', color: 'var(--primary)' }}>
                  ₹{dailyRate.toLocaleString('en-IN')} <span style={{ fontSize: '0.85rem', fontWeight: '500', color: 'var(--text-muted)' }}>/ day</span>
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  + ₹{securityDeposit.toLocaleString('en-IN')} refundable security deposit
                </div>
              </div>
            </div>

            <div className="card-body">
              {bookingSuccess ? (
                <div style={{ textAlign: 'center', padding: '1rem 0' }}>
                  <CheckCircle2 size={44} style={{ color: 'var(--success)', margin: '0 auto 0.5rem auto', display: 'block' }} />
                  <h3 style={{ fontSize: '1.2rem', fontWeight: '800', marginBottom: '0.3rem', color: 'var(--text-main)' }}>
                    Booking Confirmed!
                  </h3>
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '1.25rem' }}>
                    Rental transaction <strong>#{bookingSuccess.id}</strong> has been secured with PhonePe payment.
                  </p>

                  <div
                    style={{
                      backgroundColor: 'var(--bg-subtle)',
                      borderRadius: 'var(--radius-md)',
                      padding: '1rem',
                      textAlign: 'left',
                      marginBottom: '1.25rem',
                      fontSize: '0.84rem',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '0.4rem',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Booking Status:</span>
                      <span className="badge badge-warning" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                        <Clock size={12} /> Pending Owner Approval
                      </span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Vehicle Host / Owner:</span>
                      <strong style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                        <ShieldCheck size={13} style={{ color: 'var(--success)' }} />
                        {owner ? owner.name : 'Verified Owner'}
                      </strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Customer Name:</span>
                      <strong>{bookingSuccess.customerName || 'Customer'}</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Payment Method:</span>
                      <strong style={{ color: '#5f259f' }}>{bookingSuccess.paymentMethod || 'PhonePe UPI'}</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>PhonePe Number:</span>
                      <strong>9492343566</strong>
                    </div>
                    {bookingSuccess.transactionId && (
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ color: 'var(--text-muted)' }}>UTR / Transaction ID:</span>
                        <span style={{ fontFamily: 'monospace', fontWeight: '600', color: 'var(--primary)' }}>
                          {bookingSuccess.transactionId}
                        </span>
                      </div>
                    )}
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Pickup Hub:</span>
                      <strong>ATV Tadepalligudem</strong>
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        borderTop: '1px dashed var(--border-color)',
                        paddingTop: '0.5rem',
                        fontWeight: '800',
                        color: 'var(--primary)',
                        fontSize: '1rem',
                      }}
                    >
                      <span>Total Amount:</span>
                      <span>₹{Number(bookingSuccess.totalAmount).toLocaleString('en-IN')}</span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.55rem' }}>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                      <button
                        className="btn btn-primary"
                        style={{ flex: 1 }}
                        onClick={() => navigate('/owner-dashboard')}
                      >
                        Owner Dashboard (Approve)
                      </button>
                      <button
                        className="btn btn-secondary"
                        style={{ flex: 1 }}
                        onClick={() => navigate('/rentals')}
                      >
                        Rental History
                      </button>
                    </div>
                    <button
                      className="btn btn-outline btn-sm"
                      onClick={() => setBookingSuccess(null)}
                    >
                      Book Another Vehicle
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleBookingSubmit} noValidate>
                  {/* Date Conflict Alert */}
                  {dateConflict && (
                    <div className="alert alert-error" style={{ marginBottom: '1rem', fontSize: '0.82rem' }}>
                      <AlertCircle size={16} style={{ flexShrink: 0 }} />
                      <span>
                        Unavailable: Booked from {formatDisplayDate(dateConflict.startDate)} to {formatDisplayDate(dateConflict.endDate)}. Please pick other dates.
                      </span>
                    </div>
                  )}

                  {/* Enter Your Name */}
                  <div className="form-group" style={{ marginBottom: '0.85rem' }}>
                    <label className="form-label" htmlFor="bookingCustomerName">
                      Enter Your Name <span className="required">*</span>
                    </label>
                    <input
                      id="bookingCustomerName"
                      type="text"
                      list="vdCustomerSuggestions"
                      className={`form-input ${bookingErrors.customerName ? 'is-invalid' : ''}`}
                      placeholder="Enter your full name"
                      value={customerName}
                      onChange={(e) => {
                        setCustomerName(e.target.value);
                        if (bookingErrors.customerName) {
                          setBookingErrors((prev) => ({ ...prev, customerName: null }));
                        }
                      }}
                      autoComplete="name"
                    />
                    {customers && customers.length > 0 && (
                      <datalist id="vdCustomerSuggestions">
                        {customers.map((c) => (
                          <option key={c.id} value={c.name}>
                            {c.name} ({c.phone})
                          </option>
                        ))}
                      </datalist>
                    )}
                    {bookingErrors.customerName && (
                      <span className="form-error">{bookingErrors.customerName}</span>
                    )}
                  </div>

                  <div className="form-group" style={{ marginBottom: '0.85rem' }}>
                    <label className="form-label" htmlFor="bookingCustomerPhone">
                      Phone Number
                    </label>
                    <input
                      id="bookingCustomerPhone"
                      type="tel"
                      className="form-input"
                      placeholder="e.g. 9876543210"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      autoComplete="tel"
                    />
                  </div>

                  {/* Date Pickers */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', marginBottom: '0.85rem' }}>
                    <div className="form-group" style={{ marginBottom: 0 }}>
                      <label className="form-label" htmlFor="bookStartDate" style={{ fontSize: '0.78rem' }}>
                        Pickup Date <span className="required">*</span>
                      </label>
                      <input
                        id="bookStartDate"
                        type="date"
                        className="form-input"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                      />
                    </div>

                    <div className="form-group" style={{ marginBottom: 0 }}>
                      <label className="form-label" htmlFor="bookEndDate" style={{ fontSize: '0.78rem' }}>
                        Return Date <span className="required">*</span>
                      </label>
                      <input
                        id="bookEndDate"
                        type="date"
                        className="form-input"
                        value={endDate}
                        min={startDate || undefined}
                        onChange={(e) => setEndDate(e.target.value)}
                      />
                    </div>
                  </div>
                  {bookingErrors.endDate && (
                    <span className="form-error" style={{ display: 'block', marginBottom: '0.5rem' }}>
                      {bookingErrors.endDate}
                    </span>
                  )}

                  {/* Fee Calculation Breakdown */}
                  {rentalDays > 0 && (
                    <div
                      style={{
                        backgroundColor: 'var(--bg-subtle)',
                        borderRadius: 'var(--radius-sm)',
                        padding: '0.85rem',
                        marginBottom: '1rem',
                        fontSize: '0.85rem',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
                        <span>₹{dailyRate} × {rentalDays} {rentalDays === 1 ? 'day' : 'days'}:</span>
                        <strong>₹{totalRentalAmount.toLocaleString('en-IN')}</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.35rem', color: 'var(--text-muted)' }}>
                        <span>Refundable Deposit:</span>
                        <span>₹{securityDeposit.toLocaleString('en-IN')}</span>
                      </div>
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          borderTop: '1px solid var(--border-color)',
                          paddingTop: '0.45rem',
                          fontWeight: '800',
                          color: '#5f259f',
                          fontSize: '1rem',
                        }}
                      >
                        <span>Total Payable:</span>
                        <span>₹{totalRentalAmount.toLocaleString('en-IN')}</span>
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="btn"
                    style={{
                      width: '100%',
                      padding: '0.8rem',
                      fontWeight: '700',
                      backgroundColor: '#5f259f',
                      color: '#ffffff',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.45rem',
                      fontSize: '0.95rem',
                    }}
                    disabled={isBooking || dateConflict !== null || rentalDays <= 0}
                  >
                    <Smartphone size={18} /> Book This Car • Pay via PhonePe QR
                  </button>

                  <div style={{ textAlign: 'center', marginTop: '0.65rem', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    PhonePe QR will be generated for <strong>9492343566</strong>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* PhonePe UPI QR Code Payment Modal */}
      <PhonePePaymentModal
        isOpen={isPaymentModalOpen}
        amount={totalRentalAmount}
        vehicleName={vehicle.name}
        rentalDays={rentalDays}
        onPaymentSuccess={handlePaymentSuccess}
        onCancel={() => setIsPaymentModalOpen(false)}
        isProcessing={isBooking}
      />
    </div>
  );
}
