import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { vehicleApi, ownerApi } from '../services/api';
import VehicleForm from '../components/VehicleForm';
import { LoadingSpinner, ErrorBanner } from '../components/LoadingState';
import { ArrowLeft, Car } from 'lucide-react';

export default function VehicleEdit() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [vehicle, setVehicle] = useState(null);
  const [allVehicles, setAllVehicles] = useState([]);
  const [allOwners, setAllOwners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchVehicleData = async () => {
      setLoading(true);
      setError(null);
      try {
        const [targetVehicle, all, oData] = await Promise.all([
          vehicleApi.getById(id),
          vehicleApi.getAll(),
          ownerApi.getAll(),
        ]);
        setVehicle(targetVehicle);
        setAllVehicles(all || []);
        setAllOwners(oData || []);
      } catch (err) {
        setError(err.message || 'Vehicle not found or server error.');
      } finally {
        setLoading(false);
      }
    };

    fetchVehicleData();
  }, [id]);

  const handleUpdate = async (formData) => {
    setIsSubmitting(true);
    try {
      await vehicleApi.update(id, formData);
      navigate('/vehicles');
    } catch (err) {
      alert(`Failed to update vehicle: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return <LoadingSpinner message="Fetching vehicle details..." />;
  }

  if (error) {
    return (
      <div>
        <Link to="/vehicles" className="btn btn-secondary" style={{ marginBottom: '1rem' }}>
          <ArrowLeft size={16} /> Back to Vehicles
        </Link>
        <ErrorBanner message={error} />
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '750px', margin: '0 auto' }}>
      <div style={{ marginBottom: '1.25rem' }}>
        <Link to="/vehicles" className="btn btn-secondary btn-sm" style={{ marginBottom: '0.75rem' }}>
          <ArrowLeft size={14} /> Back to Fleet List
        </Link>
      </div>

      <div className="card">
        <div className="card-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div className="stat-icon blue" style={{ width: '38px', height: '38px' }}>
              <Car size={18} />
            </div>
            <div>
              <div className="card-title">Edit Vehicle: {vehicle?.name}</div>
              <div className="card-subtitle">
                ID #{vehicle?.id} • Registration {vehicle?.registrationNumber}
              </div>
            </div>
          </div>
        </div>
        <div className="card-body">
          <VehicleForm
            initialData={vehicle}
            existingVehicles={allVehicles}
            owners={allOwners}
            onSubmit={handleUpdate}
            onCancel={() => navigate('/vehicles')}
            isLoading={isSubmitting}
          />
        </div>
      </div>
    </div>
  );
}
