import React, { useState, useEffect, useRef } from 'react';
import {
  Save,
  X,
  Upload,
  Image as ImageIcon,
  Link as LinkIcon,
  Trash2,
  Car,
  Bike,
  Plus,
  MapPin,
  ShieldCheck,
  Check,
} from 'lucide-react';

const CAR_CATEGORIES = ['Sedan', 'SUV', 'Hatchback', 'Van', 'Luxury', 'Convertible'];
const BIKE_CATEGORIES = ['Cruiser', 'Sports', 'Commuter', 'Scooter', 'Touring', 'Off-road'];

const CAR_FEATURES_LIST = [
  'Power Steering',
  'Power Windows',
  'Airbags',
  'ABS',
  'Rear Camera',
  'Parking Sensors',
  'GPS',
  'Bluetooth',
  'Music System',
  'Sunroof',
  'Cruise Control',
];

const BIKE_FEATURES_LIST = [
  'ABS',
  'Self Start',
  'Kick Start',
  'Digital Display',
  'Bluetooth Connectivity',
  'Navigation',
  'LED Headlight',
  'Disc Brakes',
];

export default function VehicleForm({
  initialData = null,
  onSubmit,
  onCancel,
  existingVehicles = [],
  owners = [],
  defaultOwnerId = null,
  isLoading = false,
}) {
  const fileInputRef = useRef(null);

  const [formData, setFormData] = useState({
    type: 'Car', // 'Car' | 'Bike'
    ownerId: defaultOwnerId ? String(defaultOwnerId) : '',
    name: '',
    brand: '',
    model: '',
    manufacturingYear: 2024,
    registrationNumber: '',
    category: 'SUV',
    imageUrl: '',
    images: [],
    description: '',
    // Common Rental Details
    pricePerDay: '',
    securityDeposit: '',
    minRentalDuration: 1,
    maxRentalDuration: 30,
    availableFrom: '2026-01-01',
    availableUntil: '2026-12-31',
    pickupLocation: 'ATV Tadepalligudem',
    deliveryAvailable: true,
    available: true,
    approvalStatus: 'Approved',

    // Car Specific
    seatingCapacity: 5,
    doors: 4,
    luggageCapacity: '2 Large Bags',
    airConditioning: 'AC',
    bootSpace: '400 Litres',
    fuelType: 'Petrol',
    transmission: 'Automatic',
    engineCapacityCC: 1498,
    mileageKmpl: 18,
    horsepower: '',
    carFeatures: ['Power Steering', 'Power Windows', 'Airbags', 'ABS', 'Rear Camera', 'Bluetooth'],

    // Bike Specific
    maxPower: '',
    maxTorque: '',
    fuelTankCapacity: '12 Litres',
    bikeFeatures: ['ABS', 'Self Start', 'Disc Brakes', 'Digital Display'],
  });

  const [imageInputUrl, setImageInputUrl] = useState('');
  const [imageMode, setImageMode] = useState('url'); // 'url' | 'upload'
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (initialData) {
      const isBike =
        initialData.type === 'Bike' ||
        (initialData.category && BIKE_CATEGORIES.includes(initialData.category)) ||
        initialData.category === 'Bike';

      const type = isBike ? 'Bike' : 'Car';

      setFormData({
        type: type,
        ownerId: String(initialData.ownerId || defaultOwnerId || (owners[0]?.id || '1')),
        name: initialData.name || '',
        brand: initialData.brand || '',
        model: initialData.model || '',
        manufacturingYear: initialData.manufacturingYear || 2024,
        registrationNumber: initialData.registrationNumber || '',
        category: initialData.category || (isBike ? 'Cruiser' : 'SUV'),
        imageUrl: initialData.imageUrl || '',
        images: Array.isArray(initialData.images) && initialData.images.length > 0
          ? initialData.images
          : (initialData.imageUrl ? [initialData.imageUrl] : []),
        description: initialData.description || '',
        pricePerDay: initialData.pricePerDay !== undefined ? String(initialData.pricePerDay) : '',
        securityDeposit: initialData.securityDeposit !== undefined ? String(initialData.securityDeposit) : '3000',
        minRentalDuration: initialData.minRentalDuration || 1,
        maxRentalDuration: initialData.maxRentalDuration || 30,
        availableFrom: initialData.availableFrom || '2026-01-01',
        availableUntil: initialData.availableUntil || '2026-12-31',
        pickupLocation: initialData.pickupLocation || 'ATV Tadepalligudem',
        deliveryAvailable: initialData.deliveryAvailable !== undefined ? Boolean(initialData.deliveryAvailable) : true,
        available: initialData.available !== undefined ? Boolean(initialData.available) : true,
        approvalStatus: initialData.approvalStatus || 'Approved',

        // Car
        seatingCapacity: initialData.seatingCapacity || 5,
        doors: initialData.doors || 4,
        luggageCapacity: initialData.luggageCapacity || '2 Large Bags',
        airConditioning: initialData.airConditioning || 'AC',
        bootSpace: initialData.bootSpace || '400 Litres',
        fuelType: initialData.fuelType || 'Petrol',
        transmission: initialData.transmission || 'Automatic',
        engineCapacityCC: initialData.engineCapacityCC || (isBike ? 350 : 1498),
        mileageKmpl: initialData.mileageKmpl || (isBike ? 36 : 18),
        horsepower: initialData.horsepower || '',
        carFeatures: Array.isArray(initialData.features) ? initialData.features : ['Power Steering', 'Airbags', 'ABS', 'Bluetooth'],

        // Bike
        maxPower: initialData.maxPower || '',
        maxTorque: initialData.maxTorque || '',
        fuelTankCapacity: initialData.fuelTankCapacity || '13 Litres',
        bikeFeatures: Array.isArray(initialData.features) ? initialData.features : ['ABS', 'Self Start', 'Disc Brakes'],
      });
    } else {
      if (defaultOwnerId) {
        setFormData((prev) => ({ ...prev, ownerId: String(defaultOwnerId) }));
      } else if (owners.length > 0) {
        setFormData((prev) => ({ ...prev, ownerId: String(owners[0].id) }));
      }
    }
  }, [initialData, defaultOwnerId, owners]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const handleTypeChange = (newType) => {
    setFormData((prev) => ({
      ...prev,
      type: newType,
      category: newType === 'Car' ? 'SUV' : 'Cruiser',
      engineCapacityCC: newType === 'Car' ? 1498 : 349,
      mileageKmpl: newType === 'Car' ? 18 : 36,
      securityDeposit: newType === 'Car' ? '5000' : '2000',
    }));
  };

  const toggleCarFeature = (feature) => {
    setFormData((prev) => {
      const exists = prev.carFeatures.includes(feature);
      return {
        ...prev,
        carFeatures: exists
          ? prev.carFeatures.filter((f) => f !== feature)
          : [...prev.carFeatures, feature],
      };
    });
  };

  const toggleBikeFeature = (feature) => {
    setFormData((prev) => {
      const exists = prev.bikeFeatures.includes(feature);
      return {
        ...prev,
        bikeFeatures: exists
          ? prev.bikeFeatures.filter((f) => f !== feature)
          : [...prev.bikeFeatures, feature],
      };
    });
  };

  const handleAddImage = () => {
    if (!imageInputUrl.trim()) return;
    setFormData((prev) => ({
      ...prev,
      imageUrl: prev.imageUrl || imageInputUrl.trim(),
      images: [...prev.images, imageInputUrl.trim()],
    }));
    setImageInputUrl('');
  };

  const handleRemoveImage = (index) => {
    setFormData((prev) => {
      const nextImages = prev.images.filter((_, i) => i !== index);
      return {
        ...prev,
        images: nextImages,
        imageUrl: nextImages[0] || '',
      };
    });
  };

  const handleUploadImageFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select an image file (PNG, JPG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const dataUrl = uploadEvent.target.result;
      setFormData((prev) => ({
        ...prev,
        imageUrl: prev.imageUrl || dataUrl,
        images: [...prev.images, dataUrl],
      }));
    };
    reader.readAsDataURL(file);
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = 'Vehicle name is required.';
    if (!formData.brand.trim()) newErrors.brand = 'Brand is required.';
    if (!formData.model.trim()) newErrors.model = 'Model is required.';

    const reg = formData.registrationNumber.trim().toUpperCase();
    if (!reg) {
      newErrors.registrationNumber = 'Registration number is required.';
    } else {
      const duplicate = existingVehicles.find(
        (v) =>
          v.registrationNumber &&
          v.registrationNumber.toUpperCase() === reg &&
          (!initialData || String(v.id) !== String(initialData.id))
      );
      if (duplicate) {
        newErrors.registrationNumber = `Registration number ${reg} is already used by "${duplicate.name}".`;
      }
    }

    const price = parseFloat(formData.pricePerDay);
    if (!formData.pricePerDay || isNaN(price) || price <= 0) {
      newErrors.pricePerDay = 'Enter a valid daily price greater than 0.';
    }

    if (!formData.ownerId) {
      newErrors.ownerId = 'Owner assignment is required.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const payload = {
      ...formData,
      registrationNumber: formData.registrationNumber.trim().toUpperCase(),
      pricePerDay: parseFloat(formData.pricePerDay),
      securityDeposit: parseFloat(formData.securityDeposit || 0),
      minRentalDuration: parseInt(formData.minRentalDuration, 10) || 1,
      maxRentalDuration: parseInt(formData.maxRentalDuration, 10) || 30,
      engineCapacityCC: parseFloat(formData.engineCapacityCC || 0),
      mileageKmpl: parseFloat(formData.mileageKmpl || 0),
      seatingCapacity: formData.type === 'Car' ? parseInt(formData.seatingCapacity, 10) : undefined,
      doors: formData.type === 'Car' ? parseInt(formData.doors, 10) : undefined,
      features: formData.type === 'Car' ? formData.carFeatures : formData.bikeFeatures,
      imageUrl: formData.imageUrl || (formData.images.length > 0 ? formData.images[0] : (formData.type === 'Car' ? '/front-left-side-47.avif' : '/classic-350.avif')),
      images: formData.images.length > 0
        ? formData.images
        : [formData.imageUrl || (formData.type === 'Car' ? '/front-left-side-47.avif' : '/classic-350.avif')],
    };

    onSubmit(payload);
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {/* 1. Vehicle Type Selector (Car vs Bike) */}
      <div style={{ marginBottom: '1.25rem' }}>
        <label className="form-label" style={{ marginBottom: '0.4rem' }}>
          Select Vehicle Category Type <span className="required">*</span>
        </label>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
          <button
            type="button"
            className={`ownership-option-btn ${formData.type === 'Car' ? 'selected' : ''}`}
            onClick={() => handleTypeChange('Car')}
            style={{ padding: '0.85rem' }}
          >
            <Car size={22} />
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontWeight: '700' }}>Car / SUV / Van</div>
              <div style={{ fontSize: '0.72rem', opacity: 0.8 }}>Sedan, SUV, Hatchback, MPV with seating specs</div>
            </div>
          </button>

          <button
            type="button"
            className={`ownership-option-btn ${formData.type === 'Bike' ? 'selected' : ''}`}
            onClick={() => handleTypeChange('Bike')}
            style={{ padding: '0.85rem' }}
          >
            <Bike size={22} />
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontWeight: '700' }}>Bike / Motorcycle</div>
              <div style={{ fontSize: '0.72rem', opacity: 0.8 }}>Cruiser, Sports, Commuter, Scooter with engine specs</div>
            </div>
          </button>
        </div>
      </div>

      {/* Owner Selector (if multiple owners available) */}
      {owners && owners.length > 0 && !defaultOwnerId && (
        <div className="form-group" style={{ marginBottom: '1.25rem' }}>
          <label className="form-label" htmlFor="ownerSelect">
            Vehicle Owner (Host Partner) <span className="required">*</span>
          </label>
          <select
            id="ownerSelect"
            name="ownerId"
            className={`form-select ${errors.ownerId ? 'is-invalid' : ''}`}
            value={formData.ownerId}
            onChange={handleChange}
            disabled={isLoading}
          >
            <option value="">-- Choose Registered Owner --</option>
            {owners.map((o) => (
              <option key={o.id} value={o.id}>
                {o.name} ({o.city}) • {o.verificationStatus === 'Verified' ? '✓ Verified' : 'Pending'}
              </option>
            ))}
          </select>
          {errors.ownerId && <span className="form-error">{errors.ownerId}</span>}
        </div>
      )}

      {/* Basic Vehicle Information */}
      <div className="form-grid-3">
        <div className="form-group">
          <label className="form-label" htmlFor="vehicleName">
            Vehicle Name <span className="required">*</span>
          </label>
          <input
            id="vehicleName"
            name="name"
            type="text"
            className={`form-input ${errors.name ? 'is-invalid' : ''}`}
            placeholder={formData.type === 'Car' ? 'e.g. Hyundai Creta SX(O)' : 'e.g. Royal Enfield Classic 350'}
            value={formData.name}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.name && <span className="form-error">{errors.name}</span>}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="vehicleBrand">
            Brand <span className="required">*</span>
          </label>
          <input
            id="vehicleBrand"
            name="brand"
            type="text"
            className={`form-input ${errors.brand ? 'is-invalid' : ''}`}
            placeholder="e.g. Hyundai, Toyota, Yamaha"
            value={formData.brand}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.brand && <span className="form-error">{errors.brand}</span>}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="vehicleModel">
            Model <span className="required">*</span>
          </label>
          <input
            id="vehicleModel"
            name="model"
            type="text"
            className={`form-input ${errors.model ? 'is-invalid' : ''}`}
            placeholder="e.g. Creta, Thar, MT-15"
            value={formData.model}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.model && <span className="form-error">{errors.model}</span>}
        </div>
      </div>

      <div className="form-grid-3">
        <div className="form-group">
          <label className="form-label" htmlFor="registrationNumber">
            Registration Number <span className="required">*</span>
          </label>
          <input
            id="registrationNumber"
            name="registrationNumber"
            type="text"
            className={`form-input ${errors.registrationNumber ? 'is-invalid' : ''}`}
            placeholder="e.g. AP37AB1234"
            value={formData.registrationNumber}
            onChange={handleChange}
            disabled={isLoading}
            style={{ textTransform: 'uppercase' }}
          />
          {errors.registrationNumber && (
            <span className="form-error">{errors.registrationNumber}</span>
          )}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="categorySelect">
            Category Style <span className="required">*</span>
          </label>
          <select
            id="categorySelect"
            name="category"
            className="form-select"
            value={formData.category}
            onChange={handleChange}
            disabled={isLoading}
          >
            {formData.type === 'Car'
              ? CAR_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))
              : BIKE_CATEGORIES.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
          </select>
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="manufacturingYear">
            Manufacturing Year
          </label>
          <input
            id="manufacturingYear"
            name="manufacturingYear"
            type="number"
            min="2015"
            max="2027"
            className="form-input"
            value={formData.manufacturingYear}
            onChange={handleChange}
            disabled={isLoading}
          />
        </div>
      </div>

      {/* 2. SPECIFICATIONS SECTION */}
      {formData.type === 'Car' ? (
        /* ================= CAR SPECIFICATIONS ================= */
        <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-md)', padding: '1.25rem', marginBottom: '1.25rem' }}>
          <div style={{ fontSize: '0.9rem', fontWeight: '700', color: 'var(--text-main)', marginBottom: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <Car size={16} style={{ color: 'var(--primary)' }} />
            Car Seating, Dimensions & Engine Specifications
          </div>

          <div className="form-grid-3">
            <div className="form-group">
              <label className="form-label" htmlFor="seatingCapacity">
                Seating Capacity <span className="required">*</span>
              </label>
              <select
                id="seatingCapacity"
                name="seatingCapacity"
                className="form-select"
                value={formData.seatingCapacity}
                onChange={handleChange}
                disabled={isLoading}
              >
                <option value={2}>2 Seater (Coupe)</option>
                <option value={4}>4 Seater</option>
                <option value={5}>5 Seater (Standard)</option>
                <option value={6}>6 Seater</option>
                <option value={7}>7 Seater (MPV / SUV)</option>
                <option value={8}>8 Seater</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="doors">
                Number of Doors
              </label>
              <input
                id="doors"
                name="doors"
                type="number"
                min="2"
                max="6"
                className="form-input"
                value={formData.doors}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="airConditioning">
                Air Conditioning
              </label>
              <select
                id="airConditioning"
                name="airConditioning"
                className="form-select"
                value={formData.airConditioning}
                onChange={handleChange}
                disabled={isLoading}
              >
                <option value="AC">AC (Air Conditioned)</option>
                <option value="Non-AC">Non-AC</option>
              </select>
            </div>
          </div>

          <div className="form-grid-3">
            <div className="form-group">
              <label className="form-label" htmlFor="fuelType">
                Fuel Type
              </label>
              <select
                id="fuelType"
                name="fuelType"
                className="form-select"
                value={formData.fuelType}
                onChange={handleChange}
                disabled={isLoading}
              >
                <option value="Petrol">Petrol</option>
                <option value="Diesel">Diesel</option>
                <option value="CNG">CNG</option>
                <option value="Electric">Electric</option>
                <option value="Hybrid">Hybrid</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="transmission">
                Transmission
              </label>
              <select
                id="transmission"
                name="transmission"
                className="form-select"
                value={formData.transmission}
                onChange={handleChange}
                disabled={isLoading}
              >
                <option value="Manual">Manual</option>
                <option value="Automatic">Automatic / AMT</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="engineCapacityCC">
                Engine Capacity (CC)
              </label>
              <input
                id="engineCapacityCC"
                name="engineCapacityCC"
                type="number"
                className="form-input"
                placeholder="e.g. 1497"
                value={formData.engineCapacityCC}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
          </div>

          <div className="form-grid-3">
            <div className="form-group">
              <label className="form-label" htmlFor="mileageKmpl">
                Mileage (km/l)
              </label>
              <input
                id="mileageKmpl"
                name="mileageKmpl"
                type="number"
                step="0.1"
                className="form-input"
                placeholder="e.g. 18.5"
                value={formData.mileageKmpl}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="bootSpace">
                Boot Space
              </label>
              <input
                id="bootSpace"
                name="bootSpace"
                type="text"
                className="form-input"
                placeholder="e.g. 433 Litres"
                value={formData.bootSpace}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="luggageCapacity">
                Luggage Capacity
              </label>
              <input
                id="luggageCapacity"
                name="luggageCapacity"
                type="text"
                className="form-input"
                placeholder="e.g. 3 Large Bags"
                value={formData.luggageCapacity}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Car Features checklist */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" style={{ marginBottom: '0.4rem' }}>
              Car Features & Facilities
            </label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
              {CAR_FEATURES_LIST.map((feat) => {
                const isSelected = formData.carFeatures.includes(feat);
                return (
                  <button
                    key={feat}
                    type="button"
                    className={`btn btn-sm ${isSelected ? 'btn-primary' : 'btn-secondary'}`}
                    onClick={() => toggleCarFeature(feat)}
                    style={{ fontSize: '0.78rem', padding: '0.3rem 0.65rem' }}
                  >
                    {isSelected ? '✓ ' : '+ '}
                    {feat}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        /* ================= BIKE SPECIFICATIONS ================= */
        <div style={{ backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-md)', padding: '1.25rem', marginBottom: '1.25rem' }}>
          <div style={{ fontSize: '0.9rem', fontWeight: '700', color: 'var(--text-main)', marginBottom: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <Bike size={16} style={{ color: 'var(--primary)' }} />
            Bike Engine & Performance Specifications
          </div>

          <div className="form-grid-3">
            <div className="form-group">
              <label className="form-label" htmlFor="bikeEngineCC">
                Engine Capacity (CC) <span className="required">*</span>
              </label>
              <input
                id="bikeEngineCC"
                name="engineCapacityCC"
                type="number"
                className="form-input"
                placeholder="e.g. 349"
                value={formData.engineCapacityCC}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="bikeFuelType">
                Fuel Type
              </label>
              <select
                id="bikeFuelType"
                name="fuelType"
                className="form-select"
                value={formData.fuelType}
                onChange={handleChange}
                disabled={isLoading}
              >
                <option value="Petrol">Petrol</option>
                <option value="Electric">Electric</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="bikeTransmission">
                Transmission
              </label>
              <select
                id="bikeTransmission"
                name="transmission"
                className="form-select"
                value={formData.transmission}
                onChange={handleChange}
                disabled={isLoading}
              >
                <option value="Manual">Manual Gears</option>
                <option value="Automatic">Automatic / CVT</option>
              </select>
            </div>
          </div>

          <div className="form-grid-3">
            <div className="form-group">
              <label className="form-label" htmlFor="bikeMileage">
                Mileage (km/l or km/charge)
              </label>
              <input
                id="bikeMileage"
                name="mileageKmpl"
                type="number"
                step="0.1"
                className="form-input"
                placeholder="e.g. 36"
                value={formData.mileageKmpl}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="fuelTankCapacity">
                Fuel Tank / Battery Capacity
              </label>
              <input
                id="fuelTankCapacity"
                name="fuelTankCapacity"
                type="text"
                className="form-input"
                placeholder="e.g. 13 Litres or 3.7 kWh"
                value={formData.fuelTankCapacity}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="maxPower">
                Maximum Power
              </label>
              <input
                id="maxPower"
                name="maxPower"
                type="text"
                className="form-input"
                placeholder="e.g. 20.2 bhp @ 6100 rpm"
                value={formData.maxPower}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Bike Features checklist */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" style={{ marginBottom: '0.4rem' }}>
              Bike Features & Equipment
            </label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
              {BIKE_FEATURES_LIST.map((feat) => {
                const isSelected = formData.bikeFeatures.includes(feat);
                return (
                  <button
                    key={feat}
                    type="button"
                    className={`btn btn-sm ${isSelected ? 'btn-primary' : 'btn-secondary'}`}
                    onClick={() => toggleBikeFeature(feat)}
                    style={{ fontSize: '0.78rem', padding: '0.3rem 0.65rem' }}
                  >
                    {isSelected ? '✓ ' : '+ '}
                    {feat}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 3. RENTAL PRICING & POLICIES */}
      <div className="form-grid-3">
        <div className="form-group">
          <label className="form-label" htmlFor="pricePerDay">
            Daily Rental Rate (₹) <span className="required">*</span>
          </label>
          <input
            id="pricePerDay"
            name="pricePerDay"
            type="number"
            min="100"
            className={`form-input ${errors.pricePerDay ? 'is-invalid' : ''}`}
            placeholder="e.g. 2500"
            value={formData.pricePerDay}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.pricePerDay && <span className="form-error">{errors.pricePerDay}</span>}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="securityDeposit">
            Refundable Deposit (₹)
          </label>
          <input
            id="securityDeposit"
            name="securityDeposit"
            type="number"
            min="0"
            className="form-input"
            placeholder="e.g. 5000"
            value={formData.securityDeposit}
            onChange={handleChange}
            disabled={isLoading}
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="pickupLocation">
            Pickup Location
          </label>
          <input
            id="pickupLocation"
            name="pickupLocation"
            type="text"
            className="form-input"
            value={formData.pickupLocation}
            onChange={handleChange}
            disabled={isLoading}
          />
        </div>
      </div>

      <div className="form-grid-3">
        <div className="form-group">
          <label className="form-label" htmlFor="minRentalDuration">
            Min Duration (Days)
          </label>
          <input
            id="minRentalDuration"
            name="minRentalDuration"
            type="number"
            min="1"
            className="form-input"
            value={formData.minRentalDuration}
            onChange={handleChange}
            disabled={isLoading}
          />
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="maxRentalDuration">
            Max Duration (Days)
          </label>
          <input
            id="maxRentalDuration"
            name="maxRentalDuration"
            type="number"
            min="1"
            className="form-input"
            value={formData.maxRentalDuration}
            onChange={handleChange}
            disabled={isLoading}
          />
        </div>

        <div className="form-group" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <label style={{ display: 'inline-flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer', fontSize: '0.88rem', fontWeight: '500' }}>
            <input
              type="checkbox"
              name="deliveryAvailable"
              checked={formData.deliveryAvailable}
              onChange={handleChange}
              disabled={isLoading}
              style={{ width: '16px', height: '16px', accentColor: 'var(--primary)' }}
            />
            Home Delivery Available to Customer
          </label>
        </div>
      </div>

      {/* 4. MULTIPLE VEHICLE IMAGES GALLERY */}
      <div className="attachment-section" style={{ marginBottom: '1.25rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.65rem' }}>
          <label className="form-label" style={{ marginBottom: 0, display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <ImageIcon size={16} style={{ color: 'var(--primary)' }} />
            Vehicle Images Gallery ({formData.images.length})
          </label>

          <div style={{ display: 'flex', gap: '0.4rem' }}>
            <button
              type="button"
              className={`btn btn-sm ${imageMode === 'url' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setImageMode('url')}
            >
              Add by URL
            </button>
            <button
              type="button"
              className={`btn btn-sm ${imageMode === 'upload' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => {
                setImageMode('upload');
                fileInputRef.current?.click();
              }}
            >
              <Upload size={13} /> Upload File
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              style={{ display: 'none' }}
              onChange={handleUploadImageFile}
              disabled={isLoading}
            />
          </div>
        </div>

        {/* Add by URL Input */}
        {imageMode === 'url' && (
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.75rem' }}>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. /front-left-side-47.avif or https://images.unsplash.com/..."
              value={imageInputUrl}
              onChange={(e) => setImageInputUrl(e.target.value)}
              disabled={isLoading}
            />
            <button
              type="button"
              className="btn btn-secondary"
              onClick={handleAddImage}
              disabled={!imageInputUrl.trim() || isLoading}
            >
              <Plus size={15} /> Add Image
            </button>
          </div>
        )}

        {/* Thumbnails row */}
        {formData.images.length > 0 ? (
          <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', marginTop: '0.5rem' }}>
            {formData.images.map((img, idx) => (
              <div
                key={idx}
                style={{
                  position: 'relative',
                  width: '90px',
                  height: '65px',
                  borderRadius: 'var(--radius-sm)',
                  overflow: 'hidden',
                  border: idx === 0 ? '2px solid var(--primary)' : '1px solid var(--border-color)',
                }}
              >
                <img
                  src={img}
                  alt={`Vehicle view ${idx + 1}`}
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
                {idx === 0 && (
                  <span
                    style={{
                      position: 'absolute',
                      bottom: 0,
                      left: 0,
                      right: 0,
                      backgroundColor: 'rgba(37, 99, 235, 0.85)',
                      color: '#fff',
                      fontSize: '0.62rem',
                      textAlign: 'center',
                      fontWeight: '700',
                    }}
                  >
                    PRIMARY
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => handleRemoveImage(idx)}
                  style={{
                    position: 'absolute',
                    top: '2px',
                    right: '2px',
                    backgroundColor: 'rgba(220, 38, 38, 0.85)',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '50%',
                    width: '18px',
                    height: '18px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                  }}
                  title="Remove image"
                >
                  <X size={11} />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            No images attached yet. Add at least one image URL or upload photo above.
          </p>
        )}
      </div>

      {/* Description */}
      <div className="form-group" style={{ marginBottom: '1.25rem' }}>
        <label className="form-label" htmlFor="vehicleDescription">
          Vehicle Description
        </label>
        <textarea
          id="vehicleDescription"
          name="description"
          rows="3"
          className="form-textarea"
          placeholder="Describe vehicle condition, driving comfort, extra safety equipment, or rental terms..."
          value={formData.description}
          onChange={handleChange}
          disabled={isLoading}
        />
      </div>

      {/* Availability Toggle */}
      <div className="form-group" style={{ marginBottom: '1.5rem' }}>
        <label style={{ display: 'inline-flex', alignItems: 'center', gap: '0.6rem', cursor: 'pointer', fontSize: '0.9rem', fontWeight: '500' }}>
          <input
            type="checkbox"
            name="available"
            checked={formData.available}
            onChange={handleChange}
            disabled={isLoading}
            style={{ width: '18px', height: '18px', accentColor: 'var(--primary)' }}
          />
          Vehicle is currently ready & active for customer rentals
        </label>
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', borderTop: '1px solid var(--border-color)', paddingTop: '1.25rem' }}>
        {onCancel && (
          <button
            type="button"
            className="btn btn-secondary"
            onClick={onCancel}
            disabled={isLoading}
          >
            <X size={16} /> Cancel
          </button>
        )}
        <button
          type="submit"
          className="btn btn-primary"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <span className="spinner" style={{ width: '14px', height: '14px', borderWidth: '2px' }}></span>
              Saving Vehicle...
            </>
          ) : (
            <>
              <Save size={16} /> {initialData ? 'Update Vehicle Details' : 'Publish Vehicle Listing'}
            </>
          )}
        </button>
      </div>
    </form>
  );
}