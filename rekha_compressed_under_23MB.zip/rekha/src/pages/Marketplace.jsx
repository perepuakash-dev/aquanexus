import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { vehicleApi, ownerApi, rentalApi } from '../services/api';
import VehicleCard from '../components/VehicleCard';
import { LoadingSpinner, ErrorBanner, EmptyState } from '../components/LoadingState';
import { getTodayDateString, getTomorrowDateString } from '../utils/dateUtils';
import {
  Car,
  Bike,
  Search,
  Filter,
  ArrowUpDown,
  MapPin,
  CheckCircle2,
  CalendarCheck,
  Fuel,
  Sparkles,
  ShieldCheck,
  X,
  SlidersHorizontal,
  Users,
  Smartphone,
} from 'lucide-react';

export default function Marketplace() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [vehicles, setVehicles] = useState([]);
  const [owners, setOwners] = useState([]);
  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Default to 'cars' tab so available Indian cars are displayed immediately on initial load
  const [activeTab, setActiveTab] = useState(searchParams.get('tab') || 'cars');

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [brandFilter, setBrandFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [fuelFilter, setFuelFilter] = useState('All');
  const [transmissionFilter, setTransmissionFilter] = useState('All');
  const [seatingFilter, setSeatingFilter] = useState('All');
  const [priceRangeFilter, setPriceRangeFilter] = useState('All');
  const [locationFilter, setLocationFilter] = useState('All');
  const [ownerFilter, setOwnerFilter] = useState('All');
  const [sortBy, setSortBy] = useState('newest'); // 'newest' | 'price_asc' | 'price_desc'

  // Car Search Bar with pickup location and dates
  const [pickupLocation, setPickupLocation] = useState('ATV Tadepalligudem');
  const [pickupDate, setPickupDate] = useState(getTodayDateString());
  const [returnDate, setReturnDate] = useState(getTomorrowDateString());

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [vData, oData, rData] = await Promise.all([
        vehicleApi.getAll(),
        ownerApi.getAll(),
        rentalApi.getAll(),
      ]);
      setVehicles(vData || []);
      setOwners(oData || []);
      setRentals(rData || []);
    } catch (err) {
      setError(err.message || 'Failed to load vehicle catalogue from JSON Server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setCategoryFilter('All');
    setSearchParams(tab !== 'all' ? { tab } : {});
  };

  const getOwner = (ownerId) => owners.find((o) => String(o.id) === String(ownerId));

  // Only display vehicles from Verified and Active owners (and approved vehicle listings)
  const marketplaceVehicles = vehicles.filter((v) => {
    const owner = getOwner(v.ownerId);
    if (owner) {
      if (owner.verificationStatus === 'Rejected' || owner.accountStatus === 'Inactive') {
        return false;
      }
    }
    if (v.approvalStatus && v.approvalStatus === 'Rejected') {
      return false;
    }
    return true;
  });

  // Filter pipeline
  const filteredVehicles = marketplaceVehicles
    .filter((v) => {
      const isBike =
        v.type === 'Bike' ||
        ['Cruiser', 'Sports', 'Commuter', 'Scooter'].includes(v.category) ||
        v.category === 'Bike';

      // 1. Tab Filter
      if (activeTab === 'cars' && isBike) return false;
      if (activeTab === 'bikes' && !isBike) return false;

      // 2. Search Query (matches name, brand, model, category)
      const query = searchQuery.trim().toLowerCase();
      if (query) {
        const matchesName = (v.name || '').toLowerCase().includes(query);
        const matchesBrand = (v.brand || '').toLowerCase().includes(query);
        const matchesModel = (v.model || '').toLowerCase().includes(query);
        const matchesCategory = (v.category || '').toLowerCase().includes(query);
        if (!matchesName && !matchesBrand && !matchesModel && !matchesCategory) {
          return false;
        }
      }

      // 3. Brand Filter
      if (brandFilter !== 'All') {
        if ((v.brand || '').toLowerCase() !== brandFilter.toLowerCase()) {
          return false;
        }
      }

      // 4. Category Filter
      if (categoryFilter !== 'All') {
        if ((v.category || '').toLowerCase() !== categoryFilter.toLowerCase()) {
          return false;
        }
      }

      // 5. Fuel Filter
      if (fuelFilter !== 'All') {
        if ((v.fuelType || '').toLowerCase() !== fuelFilter.toLowerCase()) {
          return false;
        }
      }

      // 6. Transmission Filter
      if (transmissionFilter !== 'All') {
        if ((v.transmission || '').toLowerCase() !== transmissionFilter.toLowerCase()) {
          return false;
        }
      }

      // 7. Seating Filter (5 Seater / 7 Seater for cars)
      if (seatingFilter !== 'All' && !isBike) {
        if (Number(v.seatingCapacity || 5) !== Number(seatingFilter)) {
          return false;
        }
      }

      // 8. Price Range Filter
      const price = Number(v.pricePerDay || 0);
      if (priceRangeFilter === 'under_1500' && price >= 1500) return false;
      if (priceRangeFilter === '1500_2500' && (price < 1500 || price > 2500)) return false;
      if (priceRangeFilter === '2500_4000' && (price < 2500 || price > 4000)) return false;
      if (priceRangeFilter === 'above_4000' && price <= 4000) return false;

      // 9. Location Filter
      if (locationFilter !== 'All') {
        const loc = (v.pickupLocation || '').toLowerCase();
        if (!loc.includes(locationFilter.toLowerCase())) return false;
      }

      // 10. Owner Filter
      if (ownerFilter !== 'All') {
        if (String(v.ownerId) !== String(ownerFilter)) return false;
      }

      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'price_asc') {
        return Number(a.pricePerDay || 0) - Number(b.pricePerDay || 0);
      }
      if (sortBy === 'price_desc') {
        return Number(b.pricePerDay || 0) - Number(a.pricePerDay || 0);
      }
      // default newest: higher id or year
      return Number(b.id || 0) - Number(a.id || 0);
    });

  // Unique Categories for dropdown
  const availableCategories = Array.from(
    new Set(
      marketplaceVehicles
        .filter((v) => {
          const isBike =
            v.type === 'Bike' ||
            ['Cruiser', 'Sports', 'Commuter', 'Scooter'].includes(v.category) ||
            v.category === 'Bike';
          if (activeTab === 'cars' && isBike) return false;
          if (activeTab === 'bikes' && !isBike) return false;
          return Boolean(v.category);
        })
        .map((v) => v.category)
    )
  );

  const resetFilters = () => {
    setSearchQuery('');
    setBrandFilter('All');
    setCategoryFilter('All');
    setFuelFilter('All');
    setTransmissionFilter('All');
    setSeatingFilter('All');
    setPriceRangeFilter('All');
    setLocationFilter('All');
    setOwnerFilter('All');
    setSortBy('newest');
  };

  const hasActiveFilters =
    searchQuery ||
    brandFilter !== 'All' ||
    categoryFilter !== 'All' ||
    fuelFilter !== 'All' ||
    transmissionFilter !== 'All' ||
    seatingFilter !== 'All' ||
    priceRangeFilter !== 'All' ||
    locationFilter !== 'All' ||
    ownerFilter !== 'All';

  if (loading) {
    return <LoadingSpinner message="Loading available cars from ATV Tadepalligudem fleet..." />;
  }

  return (
    <div>
      {error && <ErrorBanner message={error} onRetry={fetchData} />}

      {/* 3 & 4. Heading: "Find Your Perfect Car" & Short description */}
      <div
        style={{
          background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #1e3a8a 100%)',
          color: '#ffffff',
          borderRadius: 'var(--radius-lg)',
          padding: '2rem 2.25rem',
          marginBottom: '1.5rem',
          boxShadow: 'var(--shadow-md)',
          position: 'relative',
          overflow: 'hidden',
          border: '1px solid rgba(255, 255, 255, 0.1)',
        }}
      >
        <div style={{ display: 'grid', gridTemplateColumns: '1.25fr 0.75fr', gap: '2rem', alignItems: 'center' }}>
          <div style={{ position: 'relative', zIndex: 2 }}>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.4rem',
                backgroundColor: 'rgba(59, 130, 246, 0.25)',
                color: '#93c5fd',
                padding: '0.35rem 0.8rem',
                borderRadius: 'var(--radius-full)',
                fontSize: '0.78rem',
                fontWeight: '700',
                marginBottom: '0.85rem',
                border: '1px solid rgba(147, 197, 253, 0.3)',
              }}
            >
              <Sparkles size={14} /> Owned by Rayudi Rekha, Kumpatla Reethuka, Shaik Najirin & Sivadalla Praveen • ATV Tadepalligudem
            </div>
            
            <h1 style={{ fontSize: '2.15rem', fontWeight: '800', lineHeight: 1.2, marginBottom: '0.5rem', color: '#ffffff' }}>
              Find Your Perfect Car
            </h1>
            
            <p style={{ fontSize: '1.05rem', color: '#cbd5e1', lineHeight: 1.55, marginBottom: '0.85rem' }}>
              Choose your perfect ride for your next journey.
            </p>

            {/* Simple 3-Step Booking Guide */}
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.65rem',
                fontSize: '0.78rem',
                color: '#e2e8f0',
                marginBottom: '1.25rem',
                backgroundColor: 'rgba(255, 255, 255, 0.08)',
                padding: '0.45rem 0.85rem',
                borderRadius: 'var(--radius-full)',
                border: '1px solid rgba(255, 255, 255, 0.15)',
                flexWrap: 'wrap',
              }}
            >
              <span>1️⃣ <strong>Choose Car</strong></span>
              <span style={{ color: '#94a3b8' }}>•</span>
              <span>2️⃣ <strong>Enter Your Name</strong></span>
              <span style={{ color: '#94a3b8' }}>•</span>
              <span>3️⃣ <strong>Scan PhonePe QR (9492343566)</strong></span>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
              <button
                className={`btn ${activeTab === 'cars' ? 'btn-primary' : 'btn-secondary'}`}
                style={activeTab !== 'cars' ? { backgroundColor: 'rgba(255,255,255,0.15)', color: '#ffffff', borderColor: 'rgba(255,255,255,0.3)' } : {}}
                onClick={() => handleTabChange('cars')}
              >
                <Car size={16} /> Explore Indian Cars ({marketplaceVehicles.filter((v) => v.type === 'Car').length})
              </button>
              <button
                className={`btn ${activeTab === 'bikes' ? 'btn-primary' : 'btn-secondary'}`}
                style={activeTab !== 'bikes' ? { backgroundColor: 'rgba(255,255,255,0.15)', color: '#ffffff', borderColor: 'rgba(255,255,255,0.3)' } : {}}
                onClick={() => handleTabChange('bikes')}
              >
                <Bike size={16} /> Explore Bikes
              </button>
              <button
                className="btn btn-outline"
                style={{ color: '#ffffff', borderColor: 'rgba(255,255,255,0.4)' }}
                onClick={() => navigate('/book')}
              >
                <CalendarCheck size={16} /> Quick Book
              </button>
            </div>

            {/* Quick Brand Badges */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', flexWrap: 'wrap' }}>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8', fontWeight: '600' }}>Popular Brands:</span>
              {['Maruti Suzuki', 'Hyundai', 'Tata', 'Mahindra', 'Toyota', 'Kia'].map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => setBrandFilter(brandFilter === b ? 'All' : b)}
                  style={{
                    backgroundColor: brandFilter === b ? 'var(--primary)' : 'rgba(255, 255, 255, 0.1)',
                    color: '#ffffff',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    borderRadius: 'var(--radius-full)',
                    padding: '0.15rem 0.6rem',
                    fontSize: '0.72rem',
                    fontWeight: '600',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                  }}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: Attractive Indian Car Hero Showcase Card */}
          <div style={{ position: 'relative', zIndex: 2 }}>
            <div
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.08)',
                backdropFilter: 'blur(10px)',
                borderRadius: 'var(--radius-lg)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                padding: '1rem',
                boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5)',
              }}
            >
              <div
                style={{
                  height: '185px',
                  borderRadius: 'var(--radius-md)',
                  overflow: 'hidden',
                  position: 'relative',
                  marginBottom: '0.85rem',
                }}
              >
                <img
                  src="https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80"
                  alt="Featured Indian Car"
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
                <div
                  style={{
                    position: 'absolute',
                    top: '0.6rem',
                    left: '0.6rem',
                    backgroundColor: 'rgba(15, 23, 42, 0.85)',
                    color: '#60a5fa',
                    padding: '0.2rem 0.55rem',
                    borderRadius: 'var(--radius-full)',
                    fontSize: '0.72rem',
                    fontWeight: '700',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.3rem',
                  }}
                >
                  <ShieldCheck size={12} /> Indian Market Favorite
                </div>
                <div
                  style={{
                    position: 'absolute',
                    bottom: 0,
                    left: 0,
                    right: 0,
                    background: 'linear-gradient(to top, rgba(15, 23, 42, 0.95) 0%, rgba(15, 23, 42, 0.4) 60%, transparent 100%)',
                    padding: '1.2rem 0.75rem 0.5rem 0.75rem',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'flex-end',
                  }}
                >
                  <div>
                    <span style={{ fontSize: '0.66rem', color: '#93c5fd', fontWeight: '700', textTransform: 'uppercase' }}>
                      Authentic Indian Fleet
                    </span>
                    <div style={{ fontSize: '0.88rem', fontWeight: '800', color: '#ffffff' }}>
                      Swift • Nexon • Sonet • Classic 350
                    </div>
                  </div>
                  <span
                    style={{
                      backgroundColor: 'rgba(15, 23, 42, 0.9)',
                      color: '#ffffff',
                      padding: '0.2rem 0.5rem',
                      borderRadius: 'var(--radius-sm)',
                      fontSize: '0.72rem',
                      fontWeight: '700',
                    }}
                  >
                    From ₹900 / day
                  </span>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontWeight: '700', fontSize: '0.92rem', color: '#ffffff' }}>
                    Swift • Creta • XUV700 • Innova
                  </div>
                  <div style={{ fontSize: '0.75rem', color: '#94a3b8', display: 'flex', alignItems: 'center', gap: '0.25rem', marginTop: '0.15rem' }}>
                    <MapPin size={11} style={{ color: '#60a5fa' }} /> ATV Tadepalligudem Exclusive Hub
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-primary"
                  onClick={() => handleTabChange('cars')}
                  style={{ fontSize: '0.75rem', padding: '0.35rem 0.75rem' }}
                >
                  View Cars
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Car Search Bar with Pickup Location and Dates */}
      <div
        className="card"
        style={{
          padding: '1.25rem 1.5rem',
          marginBottom: '1.25rem',
          boxShadow: 'var(--shadow-md)',
          border: '1px solid var(--border-color)',
          backgroundColor: '#ffffff',
        }}
      >
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '1rem', alignItems: 'end' }}>
          {/* Pickup Location */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.8rem', fontWeight: '700' }}>
              <MapPin size={15} style={{ color: 'var(--primary)' }} /> Pickup Location
            </label>
            <select
              className="form-select"
              value={pickupLocation}
              onChange={(e) => {
                setPickupLocation(e.target.value);
                setLocationFilter(e.target.value === 'ATV Tadepalligudem' ? 'Tadepalligudem' : e.target.value);
              }}
            >
              <option value="ATV Tadepalligudem">ATV Tadepalligudem (Main Hub)</option>
              <option value="Tadepalligudem Railway Station">Tadepalligudem Railway Station</option>
              <option value="Tadepalligudem Bus Stand">Tadepalligudem Bus Stand</option>
              <option value="Vijayawada">Vijayawada Delivery Point</option>
              <option value="Rajahmundry">Rajahmundry Delivery Point</option>
            </select>
          </div>

          {/* Pickup Date */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.8rem', fontWeight: '700' }}>
              <CalendarCheck size={15} style={{ color: 'var(--primary)' }} /> Pickup Date
            </label>
            <input
              type="date"
              className="form-input"
              value={pickupDate}
              min={getTodayDateString()}
              onChange={(e) => setPickupDate(e.target.value)}
            />
          </div>

          {/* Return Date */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.8rem', fontWeight: '700' }}>
              <CalendarCheck size={15} style={{ color: 'var(--primary)' }} /> Return Date
            </label>
            <input
              type="date"
              className="form-input"
              value={returnDate}
              min={pickupDate || getTodayDateString()}
              onChange={(e) => setReturnDate(e.target.value)}
            />
          </div>

          {/* Car Search input */}
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.8rem', fontWeight: '700' }}>
              <Search size={15} style={{ color: 'var(--primary)' }} /> Search Cars
            </label>
            <div className="search-input-group" style={{ margin: 0 }}>
              <Search size={15} />
              <input
                type="text"
                className="form-input"
                placeholder="e.g. Swift, Creta, Nexon..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* 5. Price, Brand, Fuel Type, Seating and Transmission Filters */}
      <div
        style={{
          backgroundColor: '#ffffff',
          borderRadius: 'var(--radius-md)',
          border: '1px solid var(--border-color)',
          padding: '1.1rem 1.25rem',
          marginBottom: '1.5rem',
          boxShadow: 'var(--shadow-sm)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.85rem', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', fontSize: '0.88rem', fontWeight: '700', color: 'var(--text-main)' }}>
            <SlidersHorizontal size={16} style={{ color: 'var(--primary)' }} />
            <span>Filters: Price, Brand, Fuel Type, Seating & Transmission</span>
          </div>

          {/* Sort By Dropdown */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Sort by:</span>
            <select
              className="form-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              style={{ width: 'auto', padding: '0.35rem 0.75rem', fontSize: '0.82rem' }}
            >
              <option value="newest">Newest Vehicles</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
            </select>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: '0.75rem', alignItems: 'center' }}>
          {/* Price Filter */}
          <div>
            <label style={{ fontSize: '0.72rem', fontWeight: '700', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>
              PRICE (₹ / DAY)
            </label>
            <select
              className="form-select"
              value={priceRangeFilter}
              onChange={(e) => setPriceRangeFilter(e.target.value)}
              style={{ fontSize: '0.82rem' }}
            >
              <option value="All">All Prices</option>
              <option value="under_1500">Under ₹1,500 / day</option>
              <option value="1500_2500">₹1,500 – ₹2,500 / day</option>
              <option value="2500_4000">₹2,500 – ₹4,000 / day</option>
              <option value="above_4000">Above ₹4,000 / day</option>
            </select>
          </div>

          {/* Brand Filter */}
          <div>
            <label style={{ fontSize: '0.72rem', fontWeight: '700', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>
              BRAND
            </label>
            <select
              className="form-select"
              value={brandFilter}
              onChange={(e) => setBrandFilter(e.target.value)}
              style={{ fontSize: '0.82rem' }}
            >
              <option value="All">All Brands</option>
              <option value="Maruti Suzuki">Maruti Suzuki</option>
              <option value="Hyundai">Hyundai</option>
              <option value="Tata">Tata</option>
              <option value="Mahindra">Mahindra</option>
              <option value="Toyota">Toyota</option>
              <option value="Kia">Kia</option>
            </select>
          </div>

          {/* Fuel Type Filter */}
          <div>
            <label style={{ fontSize: '0.72rem', fontWeight: '700', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>
              FUEL TYPE
            </label>
            <select
              className="form-select"
              value={fuelFilter}
              onChange={(e) => setFuelFilter(e.target.value)}
              style={{ fontSize: '0.82rem' }}
            >
              <option value="All">All Fuel Types</option>
              <option value="Petrol">Petrol</option>
              <option value="Diesel">Diesel</option>
              <option value="CNG">CNG</option>
              <option value="Electric">Electric</option>
            </select>
          </div>

          {/* Seating Filter (5 Seater / 7 Seater) */}
          <div>
            <label style={{ fontSize: '0.72rem', fontWeight: '700', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>
              SEATING CAPACITY
            </label>
            <select
              className="form-select"
              value={seatingFilter}
              onChange={(e) => setSeatingFilter(e.target.value)}
              style={{ fontSize: '0.82rem' }}
            >
              <option value="All">All Seating</option>
              <option value="5">5 Seater</option>
              <option value="7">7 Seater</option>
            </select>
          </div>

          {/* Transmission Filter (Manual / Automatic) */}
          <div>
            <label style={{ fontSize: '0.72rem', fontWeight: '700', color: 'var(--text-muted)', display: 'block', marginBottom: '0.25rem' }}>
              TRANSMISSION
            </label>
            <select
              className="form-select"
              value={transmissionFilter}
              onChange={(e) => setTransmissionFilter(e.target.value)}
              style={{ fontSize: '0.82rem' }}
            >
              <option value="All">All Transmissions</option>
              <option value="Manual">Manual</option>
              <option value="Automatic">Automatic</option>
            </select>
          </div>
        </div>

        {hasActiveFilters && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '0.75rem', paddingTop: '0.65rem', borderTop: '1px solid var(--border-color)', fontSize: '0.82rem' }}>
            <span style={{ color: 'var(--text-muted)' }}>
              Showing <strong>{filteredVehicles.length}</strong> matching vehicles
            </span>
            <button
              type="button"
              className="btn btn-sm btn-secondary"
              onClick={resetFilters}
            >
              <X size={13} /> Reset All Filters
            </button>
          </div>
        )}
      </div>

      {/* Website Owners Showcase Strip */}
      <div
        style={{
          backgroundColor: '#ffffff',
          borderRadius: 'var(--radius-md)',
          border: '1px solid var(--border-color)',
          padding: '1rem 1.25rem',
          marginBottom: '1.25rem',
          boxShadow: 'var(--shadow-sm)',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div>
            <div style={{ fontSize: '0.92rem', fontWeight: '800', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Users size={16} style={{ color: 'var(--primary)' }} />
              <span>Website Owners & Host Fleet Partners (ATV Tadepalligudem)</span>
            </div>
            <div style={{ fontSize: '0.76rem', color: 'var(--text-muted)' }}>
              Click any owner to view their vehicles or rent directly:
            </div>
          </div>
          {ownerFilter !== 'All' && (
            <button
              type="button"
              className="btn btn-sm btn-secondary"
              onClick={() => setOwnerFilter('All')}
            >
              <X size={12} /> Show All Owners
            </button>
          )}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '0.75rem' }}>
          {owners.map((owner) => {
            const isSelected = String(ownerFilter) === String(owner.id);
            const ownerCarCount = vehicles.filter((v) => String(v.ownerId) === String(owner.id)).length;
            return (
              <div
                key={owner.id}
                onClick={() => setOwnerFilter(isSelected ? 'All' : String(owner.id))}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.65rem',
                  padding: '0.65rem 0.85rem',
                  borderRadius: 'var(--radius-md)',
                  border: isSelected ? '2px solid var(--primary)' : '1px solid var(--border-color)',
                  backgroundColor: isSelected ? 'var(--primary-light)' : '#f8fafc',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                }}
                title={`Filter vehicles by ${owner.name}`}
              >
                <img
                  src={owner.avatar}
                  alt={owner.name}
                  style={{ width: '42px', height: '42px', borderRadius: '50%', objectFit: 'cover', border: '1px solid var(--border-color)' }}
                />
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ fontWeight: '700', fontSize: '0.85rem', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{owner.name}</span>
                    <CheckCircle2 size={13} style={{ color: 'var(--success)', flexShrink: 0 }} />
                  </div>
                  <div style={{ fontSize: '0.73rem', color: 'var(--text-muted)' }}>
                    {owner.city || 'Tadepalligudem'} • <span style={{ color: 'var(--primary)', fontWeight: '600' }}>{ownerCarCount} Vehicles</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Category Tabs: Cars (Default) | All Vehicles | Bikes */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '1rem',
          marginBottom: '1.25rem',
        }}
      >
        <div className="attachment-tabs" style={{ marginBottom: 0 }}>
          <button
            type="button"
            className={`attachment-tab-btn ${activeTab === 'cars' ? 'active' : ''}`}
            onClick={() => handleTabChange('cars')}
          >
            <Car size={15} /> Cars ({marketplaceVehicles.filter((v) => v.type === 'Car').length})
          </button>
          <button
            type="button"
            className={`attachment-tab-btn ${activeTab === 'all' ? 'active' : ''}`}
            onClick={() => handleTabChange('all')}
          >
            All Vehicles ({marketplaceVehicles.length})
          </button>
          <button
            type="button"
            className={`attachment-tab-btn ${activeTab === 'bikes' ? 'active' : ''}`}
            onClick={() => handleTabChange('bikes')}
          >
            <Bike size={15} /> Bikes ({marketplaceVehicles.filter((v) => v.type === 'Bike').length})
          </button>
        </div>

        <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <MapPin size={13} style={{ color: 'var(--primary)' }} /> Hub Location: <strong>ATV Tadepalligudem</strong>
        </div>
      </div>

      {/* 6. Available Car Catalogue Displayed Immediately */}
      {filteredVehicles.length === 0 ? (
        <EmptyState
          title="No vehicles match your search criteria"
          description="Try broadening your filters, choosing a different price range, or clearing filters."
          action={
            <button className="btn btn-primary" onClick={resetFilters}>
              Clear Filters
            </button>
          }
        />
      ) : (
        <div className="vehicle-grid">
          {filteredVehicles.map((vehicle) => {
            const owner = getOwner(vehicle.ownerId);
            return (
              <VehicleCard
                key={vehicle.id}
                vehicle={vehicle}
                owner={owner}
                onBook={() => navigate(`/book?vehicleId=${vehicle.id}&startDate=${pickupDate}&endDate=${returnDate}`)}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}
