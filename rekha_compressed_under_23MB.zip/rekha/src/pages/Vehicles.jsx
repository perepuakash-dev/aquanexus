import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { vehicleApi, rentalApi, ownerApi } from '../services/api';
import VehicleCard from '../components/VehicleCard';
import VehicleForm from '../components/VehicleForm';
import ConfirmDialog from '../components/ConfirmDialog';
import { LoadingSpinner, ErrorBanner, EmptyState } from '../components/LoadingState';
import { isVehicleRentedToday } from '../utils/dateUtils';
import {
  Plus,
  Search,
  Filter,
  ArrowUpDown,
  LayoutGrid,
  List,
  Car,
  X,
  AlertCircle,
  Check,
} from 'lucide-react';

export default function Vehicles() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const [vehicles, setVehicles] = useState([]);
  const [owners, setOwners] = useState([]);
  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  // Filters & Search & Sort
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [availabilityFilter, setAvailabilityFilter] = useState('All');
  const [attachmentFilter, setAttachmentFilter] = useState('All');
  const [sortByPrice, setSortByPrice] = useState('default');
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'table'

  // Modal for Adding Vehicle
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Deletion state
  const [vehicleToDelete, setVehicleToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteWarning, setDeleteWarning] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [vData, rData, oData] = await Promise.all([
        vehicleApi.getAll(),
        rentalApi.getAll(),
        ownerApi.getAll(),
      ]);
      setVehicles(vData || []);
      setRentals(rData || []);
      setOwners(oData || []);
    } catch (err) {
      setError(err.message || 'Failed to fetch vehicles from JSON Server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Check if URL specifies action=add
  useEffect(() => {
    if (searchParams.get('action') === 'add') {
      setIsAddModalOpen(true);
      searchParams.delete('action');
      setSearchParams(searchParams, { replace: true });
    }
  }, [searchParams]);

  // Handle Add Vehicle
  const handleAddVehicle = async (formData) => {
    setIsSubmitting(true);
    try {
      const created = await vehicleApi.create(formData);
      setVehicles((prev) => [...prev, created]);
      setIsAddModalOpen(false);
      setSuccessMessage(`Vehicle "${created.name}" was successfully added.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      alert(`Error creating vehicle: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Check before deleting: active rentals
  const initiateDelete = (vehicle) => {
    const activeVehicleRentals = rentals.filter(
      (r) =>
        String(r.vehicleId) === String(vehicle.id) &&
        (r.status || '').toLowerCase() === 'active'
    );

    if (activeVehicleRentals.length > 0) {
      setDeleteWarning(
        `Cannot delete "${vehicle.name}" because it currently has ${activeVehicleRentals.length} active rental reservation(s). Please complete or cancel the active rentals first.`
      );
    } else {
      setDeleteWarning(null);
    }
    setVehicleToDelete(vehicle);
  };

  const confirmDelete = async () => {
    if (!vehicleToDelete) return;
    setIsDeleting(true);
    try {
      await vehicleApi.delete(vehicleToDelete.id);
      setVehicles((prev) => prev.filter((v) => v.id !== vehicleToDelete.id));
      setSuccessMessage(`Vehicle "${vehicleToDelete.name}" was successfully deleted.`);
      setTimeout(() => setSuccessMessage(null), 4000);
      setVehicleToDelete(null);
    } catch (err) {
      alert(`Error deleting vehicle: ${err.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Filter & Search & Sort pipeline
  const filteredVehicles = vehicles
    .filter((v) => {
      // Search by vehicle name, brand, or registration number
      const query = searchQuery.trim().toLowerCase();
      if (query) {
        const matchesName = (v.name || '').toLowerCase().includes(query);
        const matchesBrand = (v.brand || '').toLowerCase().includes(query);
        const matchesModel = (v.model || '').toLowerCase().includes(query);
        const matchesReg = (v.registrationNumber || '').toLowerCase().includes(query);
        if (!matchesName && !matchesBrand && !matchesModel && !matchesReg) {
          return false;
        }
      }

      // Filter by category
      if (categoryFilter !== 'All') {
        if ((v.category || '').toLowerCase() !== categoryFilter.toLowerCase()) {
          return false;
        }
      }

      // Filter by availability
      if (availabilityFilter !== 'All') {
        const isRented = isVehicleRentedToday(v.id, rentals);
        const isAvailableNow = v.available && !isRented;
        if (availabilityFilter === 'Available' && !isAvailableNow) return false;
        if (availabilityFilter === 'Unavailable' && isAvailableNow) return false;
      }

      // Filter by attachment / fleet ownership type
      if (attachmentFilter !== 'All') {
        const isAttached = v.ownershipType === 'Attached';
        if (attachmentFilter === 'Attached' && !isAttached) return false;
        if (attachmentFilter === 'Owned' && isAttached) return false;
      }

      return true;
    })
    .sort((a, b) => {
      if (sortByPrice === 'asc') {
        return Number(a.pricePerDay || 0) - Number(b.pricePerDay || 0);
      }
      if (sortByPrice === 'desc') {
        return Number(b.pricePerDay || 0) - Number(a.pricePerDay || 0);
      }
      return 0;
    });

  if (loading) {
    return <LoadingSpinner message="Loading fleet inventory..." />;
  }

  return (
    <div>
      {error && <ErrorBanner message={error} onRetry={fetchData} />}

      {successMessage && (
        <div className="alert alert-success">
          <Check size={18} />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Top action row */}
      <div className="controls-bar">
        <div className="search-input-group">
          <Search size={18} />
          <input
            type="text"
            className="form-input"
            placeholder="Search by name, brand, model, or reg number..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="filter-group">
          {/* Category Filter */}
          <select
            className="form-select"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            style={{ width: 'auto' }}
          >
            <option value="All">All Categories</option>
            <option value="Car">Car</option>
            <option value="Bike">Bike</option>
            <option value="SUV">SUV</option>
            <option value="Van">Van</option>
          </select>

          {/* Availability Filter */}
          <select
            className="form-select"
            value={availabilityFilter}
            onChange={(e) => setAvailabilityFilter(e.target.value)}
            style={{ width: 'auto' }}
          >
            <option value="All">All Availability</option>
            <option value="Available">Available Now</option>
            <option value="Unavailable">Unavailable / Rented</option>
          </select>

          {/* Attachment / Ownership Filter */}
          <select
            className="form-select"
            value={attachmentFilter}
            onChange={(e) => setAttachmentFilter(e.target.value)}
            style={{ width: 'auto' }}
          >
            <option value="All">All Fleet Types</option>
            <option value="Owned">Company Owned</option>
            <option value="Attached">Attached Vehicles</option>
          </select>

          {/* Sort By Price */}
          <select
            className="form-select"
            value={sortByPrice}
            onChange={(e) => setSortByPrice(e.target.value)}
            style={{ width: 'auto' }}
          >
            <option value="default">Sort by Price</option>
            <option value="asc">Price: Low to High</option>
            <option value="desc">Price: High to Low</option>
          </select>

          {/* View toggle */}
          <div style={{ display: 'flex', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', overflow: 'hidden' }}>
            <button
              type="button"
              className={`btn-icon ${viewMode === 'grid' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setViewMode('grid')}
              title="Grid View"
              style={{ borderRadius: 0 }}
            >
              <LayoutGrid size={16} />
            </button>
            <button
              type="button"
              className={`btn-icon ${viewMode === 'table' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setViewMode('table')}
              title="Table View"
              style={{ borderRadius: 0 }}
            >
              <List size={16} />
            </button>
          </div>

          <button
            className="btn btn-primary"
            onClick={() => setIsAddModalOpen(true)}
          >
            <Plus size={16} /> Add Vehicle
          </button>
        </div>
      </div>

      {/* Vehicle List: Grid or Table */}
      {filteredVehicles.length === 0 ? (
        <EmptyState
          title="No vehicles match your search"
          description="Try adjusting your filter options, clearing the search query, or add a new vehicle to the fleet."
          action={
            <button className="btn btn-primary" onClick={() => setIsAddModalOpen(true)}>
              <Plus size={16} /> Add New Vehicle
            </button>
          }
        />
      ) : viewMode === 'grid' ? (
        <div className="vehicle-grid">
          {filteredVehicles.map((vehicle) => (
            <VehicleCard
              key={vehicle.id}
              vehicle={vehicle}
              owner={owners.find((o) => String(o.id) === String(vehicle.ownerId))}
              isCurrentlyRented={isVehicleRentedToday(vehicle.id, rentals)}
              onDelete={initiateDelete}
              showAdminControls={true}
            />
          ))}
        </div>
      ) : (
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Vehicle</th>
                <th>Category</th>
                <th>Registration</th>
                <th>Brand / Model</th>
                <th>Price / Day</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredVehicles.map((vehicle) => {
                const isRented = isVehicleRentedToday(vehicle.id, rentals);
                const isAvail = vehicle.available && !isRented;
                return (
                  <tr key={vehicle.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        <img
                          src={vehicle.imageUrl || 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=150&q=80'}
                          alt={vehicle.name}
                          style={{ width: '48px', height: '36px', objectFit: 'cover', borderRadius: '4px' }}
                        />
                        <div>
                          <strong>{vehicle.name}</strong>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>ID: #{vehicle.id}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className="badge badge-category">{vehicle.category}</span>
                      {vehicle.ownershipType === 'Attached' && (
                        <span className="badge badge-attached" style={{ marginLeft: '0.4rem' }}>
                          Attached
                        </span>
                      )}
                    </td>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontWeight: '600' }}>
                        {vehicle.registrationNumber}
                      </span>
                    </td>
                    <td>{vehicle.brand} {vehicle.model}</td>
                    <td>
                      <strong>₹{Number(vehicle.pricePerDay || 0).toLocaleString('en-IN')}</strong>
                    </td>
                    <td>
                      <span className={`badge ${isAvail ? 'badge-available' : 'badge-unavailable'}`}>
                        {isAvail ? 'Available' : isRented ? 'Rented Today' : 'Unavailable'}
                      </span>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '0.5rem' }}>
                        {isAvail && (
                          <button
                            className="btn btn-sm btn-primary"
                            onClick={() => navigate(`/book?vehicleId=${vehicle.id}`)}
                          >
                            Book
                          </button>
                        )}
                        <button
                          className="btn btn-sm btn-secondary"
                          onClick={() => navigate(`/vehicles/edit/${vehicle.id}`)}
                        >
                          Edit
                        </button>
                        <button
                          className="btn btn-sm btn-danger-light"
                          onClick={() => initiateDelete(vehicle)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Vehicle Modal */}
      {isAddModalOpen && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-content" style={{ maxWidth: '650px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Car size={20} style={{ color: 'var(--primary)' }} />
                <h3>Add New Vehicle to Fleet</h3>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setIsAddModalOpen(false)}
                disabled={isSubmitting}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <VehicleForm
                existingVehicles={vehicles}
                owners={owners}
                onSubmit={handleAddVehicle}
                onCancel={() => setIsAddModalOpen(false)}
                isLoading={isSubmitting}
              />
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={vehicleToDelete !== null}
        title="Delete Vehicle"
        message={
          deleteWarning ||
          `Are you sure you want to permanently delete "${vehicleToDelete?.name}" (${vehicleToDelete?.registrationNumber})? This operation cannot be reversed.`
        }
        confirmText="Yes, Delete Vehicle"
        cancelText="Cancel"
        isDanger={true}
        isLoading={isDeleting}
        onConfirm={deleteWarning ? () => setVehicleToDelete(null) : confirmDelete}
        onCancel={() => setVehicleToDelete(null)}
      />
    </div>
  );
}
