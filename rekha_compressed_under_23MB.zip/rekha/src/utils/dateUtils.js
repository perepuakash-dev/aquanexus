/**
 * Date utilities for date-only calculations and overlap detection.
 * Avoiding timezone bugs by parsing YYYY-MM-DD directly into UTC timestamps.
 */

export function parseDateOnly(dateStr) {
  if (!dateStr || typeof dateStr !== 'string') return null;
  const parts = dateStr.split('-');
  if (parts.length !== 3) return null;
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);
  if (isNaN(year) || isNaN(month) || isNaN(day)) return null;
  return new Date(Date.UTC(year, month, day));
}

export function formatDisplayDate(dateStr) {
  if (!dateStr) return '—';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  const year = parts[0];
  const month = parts[1];
  const day = parts[2];
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  const mIdx = parseInt(month, 10) - 1;
  return `${day} ${months[mIdx] || month} ${year}`;
}

export function getTodayDateString() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getTomorrowDateString() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Calculates number of days between startDate and endDate.
 * Example: 2026-11-01 to 2026-11-04 -> 3 days
 */
export function calculateRentalDays(startDateStr, endDateStr) {
  const d1 = parseDateOnly(startDateStr);
  const d2 = parseDateOnly(endDateStr);
  if (!d1 || !d2) return 0;
  
  const diffTime = d2.getTime() - d1.getTime();
  const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

/**
 * Check if two intervals [startA, endA) and [startB, endB) overlap.
 * In vehicle rentals: startA < endB && endA > startB
 */
export function doDateRangesOverlap(startA, endA, startB, endB) {
  const sA = parseDateOnly(startA);
  const eA = parseDateOnly(endA);
  const sB = parseDateOnly(startB);
  const eB = parseDateOnly(endB);

  if (!sA || !eA || !sB || !eB) return false;
  return sA.getTime() < eB.getTime() && eA.getTime() > sB.getTime();
}

/**
 * Check if a vehicle has any conflicting booking in the proposed date range.
 * Considers rentals where status is 'Active' or 'Booked' (ignores 'Cancelled' and 'Completed').
 * Can exclude a specific rental ID when editing.
 */
export function findConflictingRental(rentals, vehicleId, startDate, endDate, excludeRentalId = null) {
  if (!rentals || !Array.isArray(rentals)) return null;

  return rentals.find((rental) => {
    if (String(rental.vehicleId) !== String(vehicleId)) return false;
    if (excludeRentalId && String(rental.id) === String(excludeRentalId)) return false;
    
    // Ignore cancelled and completed rentals
    const status = (rental.status || '').toLowerCase();
    if (status === 'cancelled' || status === 'completed') {
      return false;
    }

    return doDateRangesOverlap(startDate, endDate, rental.startDate, rental.endDate);
  });
}

/**
 * Check whether a vehicle is currently actively rented right now (today).
 */
export function isVehicleRentedToday(vehicleId, rentals) {
  const today = getTodayDateString();
  const todayDate = parseDateOnly(today);

  return rentals.some((rental) => {
    if (String(rental.vehicleId) !== String(vehicleId)) return false;
    const status = (rental.status || '').toLowerCase();
    if (status === 'cancelled' || status === 'completed') return false;

    const s = parseDateOnly(rental.startDate);
    const e = parseDateOnly(rental.endDate);
    if (!s || !e || !todayDate) return false;

    // Active today if startDate <= today < endDate (or endDate inclusive)
    return s.getTime() <= todayDate.getTime() && todayDate.getTime() <= e.getTime();
  });
}
