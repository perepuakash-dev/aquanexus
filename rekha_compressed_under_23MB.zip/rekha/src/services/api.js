const BASE_URL = 'http://localhost:3000';

/**
 * Generic request helper with error handling
 */
async function request(endpoint, options = {}) {
  const url = `${BASE_URL}${endpoint}`;
  const defaultHeaders = {
    'Content-Type': 'application/json',
  };

  const config = {
    ...options,
    headers: {
      ...defaultHeaders,
      ...options.headers,
    },
  };

  try {
    const response = await fetch(url, config);
    if (!response.ok) {
      const errorText = await response.text();
      let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
      try {
        const errorJson = JSON.parse(errorText);
        if (errorJson.message) errorMessage = errorJson.message;
      } catch {
        if (errorText) errorMessage = errorText;
      }
      throw new Error(errorMessage);
    }

    // For 204 or empty responses
    if (response.status === 204) {
      return null;
    }

    const data = await response.json();
    return data;
  } catch (error) {
    if (error.name === 'TypeError' && error.message.includes('fetch')) {
      throw new Error('Unable to connect to the JSON Server on http://localhost:3000. Please ensure the backend is running.');
    }
    throw error;
  }
}

// ======================== VEHICLES API ========================
export const vehicleApi = {
  getAll: () => request('/vehicles'),
  getById: (id) => request(`/vehicles/${id}`),
  create: (vehicleData) =>
    request('/vehicles', {
      method: 'POST',
      body: JSON.stringify({
        ...vehicleData,
        id: vehicleData.id ? String(vehicleData.id) : String(Date.now()),
      }),
    }),
  update: (id, vehicleData) =>
    request(`/vehicles/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        ...vehicleData,
        id: String(id),
      }),
    }),
  delete: (id) =>
    request(`/vehicles/${id}`, {
      method: 'DELETE',
    }),
};

// ======================== OWNERS API ========================
export const ownerApi = {
  getAll: () => request('/owners'),
  getById: (id) => request(`/owners/${id}`),
  create: (ownerData) =>
    request('/owners', {
      method: 'POST',
      body: JSON.stringify({
        ...ownerData,
        id: ownerData.id ? String(ownerData.id) : String(Date.now()),
        registrationDate: ownerData.registrationDate || new Date().toISOString().split('T')[0],
        verificationStatus: ownerData.verificationStatus || 'Pending',
        accountStatus: ownerData.accountStatus || 'Active',
      }),
    }),
  update: (id, ownerData) =>
    request(`/owners/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        ...ownerData,
        id: String(id),
      }),
    }),
  delete: (id) =>
    request(`/owners/${id}`, {
      method: 'DELETE',
    }),
};

// ======================== CUSTOMERS API ========================
export const customerApi = {
  getAll: () => request('/customers'),
  getById: (id) => request(`/customers/${id}`),
  create: (customerData) =>
    request('/customers', {
      method: 'POST',
      body: JSON.stringify({
        ...customerData,
        id: customerData.id ? String(customerData.id) : String(Date.now()),
      }),
    }),
  update: (id, customerData) =>
    request(`/customers/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        ...customerData,
        id: String(id),
      }),
    }),
  delete: (id) =>
    request(`/customers/${id}`, {
      method: 'DELETE',
    }),
};

// ======================== RENTALS API ========================
export const rentalApi = {
  getAll: () => request('/rentals'),
  getById: (id) => request(`/rentals/${id}`),
  create: (rentalData) =>
    request('/rentals', {
      method: 'POST',
      body: JSON.stringify({
        ...rentalData,
        id: rentalData.id ? String(rentalData.id) : String(Date.now()),
      }),
    }),
  update: (id, rentalData) =>
    request(`/rentals/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        ...rentalData,
        id: String(id),
      }),
    }),
  delete: (id) =>
    request(`/rentals/${id}`, {
      method: 'DELETE',
    }),
};

// ======================== SMS NOTIFICATION API ========================
export const smsApi = {
  getStatus: () => request('/api/sms/status'),
  getLogs: () => request('/api/sms/logs'),
  send: (smsPayload) =>
    request('/api/sms/send', {
      method: 'POST',
      body: JSON.stringify(smsPayload),
    }),
};
