import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Car,
  Bike,
  Users,
  CalendarCheck,
  History,
  ShieldCheck,
  X,
  MapPin,
  Sparkles,
  Building,
} from 'lucide-react';

export default function Sidebar({ mobileOpen, onCloseMobile }) {
  const publicNav = [
    { to: '/', label: 'Find Your Perfect Car', icon: Car },
    { to: '/book', label: 'Book a Vehicle', icon: CalendarCheck },
  ];

  const adminNav = [
    { to: '/admin', label: 'Admin Dashboard', icon: LayoutDashboard },
    { to: '/owners', label: 'Vehicle Owners', icon: Users },
    { to: '/owner-dashboard', label: 'Owner Host Portal', icon: Sparkles },
    { to: '/vehicles', label: 'Fleet Inventory', icon: Bike },
  ];

  const customerNav = [
    { to: '/customers', label: 'Customer Directory', icon: Users },
    { to: '/rentals', label: 'Rental History', icon: History },
  ];

  return (
    <>
      <div
        className={`mobile-backdrop ${mobileOpen ? 'active' : ''}`}
        onClick={onCloseMobile}
        aria-hidden="true"
      />
      <aside className={`sidebar ${mobileOpen ? 'mobile-open' : ''}`}>
        <div className="sidebar-brand">
          <div className="sidebar-logo-icon">
            <Car size={22} />
          </div>
          <div>
            <div className="sidebar-brand-name">DriveEase</div>
            <div style={{ fontSize: '0.68rem', color: 'var(--primary)', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '0.2rem', marginTop: '-2px' }}>
              <MapPin size={10} /> ATV Tadepalligudem
            </div>
          </div>
          <span className="sidebar-brand-badge">PRO</span>
          {mobileOpen && (
            <button
              className="btn-icon mobile-toggle"
              onClick={onCloseMobile}
              style={{ marginLeft: 'auto' }}
              aria-label="Close Navigation Menu"
            >
              <X size={20} />
            </button>
          )}
        </div>

        <nav className="sidebar-nav">
          <div className="nav-section-title">Marketplace</div>
          {publicNav.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                onClick={onCloseMobile}
              >
                <Icon size={19} style={{ color: 'var(--primary)' }} />
                <span style={{ fontWeight: '600' }}>{item.label}</span>
              </NavLink>
            );
          })}

          <div className="nav-section-title" style={{ marginTop: '1rem' }}>Multi-Owner Operations</div>
          {adminNav.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                onClick={onCloseMobile}
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </NavLink>
            );
          })}

          <div className="nav-section-title" style={{ marginTop: '1rem' }}>Customer & Rentals</div>
          {customerNav.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                onClick={onCloseMobile}
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>

        <div className="sidebar-footer" style={{ flexDirection: 'column', gap: '0.45rem', padding: '0.85rem 1rem' }}>
          <div style={{ fontSize: '0.7rem', fontWeight: '800', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--primary)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            <ShieldCheck size={13} /> Website Owners
          </div>
          <div style={{ fontSize: '0.76rem', color: 'var(--text-main)', lineHeight: 1.45, fontWeight: '600' }}>
            Rayudi Rekha • Kumpatla Reethuka • Shaik Najirin • Sivadalla Praveen
          </div>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.25rem', marginTop: '0.1rem' }}>
            <MapPin size={11} style={{ color: 'var(--primary)' }} /> ATV Tadepalligudem
          </div>
        </div>
      </aside>
    </>
  );
}