import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { customerApi } from '../services/api';
import CustomerForm from '../components/CustomerForm';
import { LoadingSpinner, ErrorBanner } from '../components/LoadingState';
import { ArrowLeft, User } from 'lucide-react';

export default function CustomerEdit() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchCustomer = async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await customerApi.getById(id);
        setCustomer(data);
      } catch (err) {
        setError(err.message || 'Customer profile not found.');
      } finally {
        setLoading(false);
      }
    };

    fetchCustomer();
  }, [id]);

  const handleUpdate = async (formData) => {
    setIsSubmitting(true);
    try {
      await customerApi.update(id, formData);
      navigate('/customers');
    } catch (err) {
      alert(`Failed to update customer: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return <LoadingSpinner message="Fetching customer profile..." />;
  }

  if (error) {
    return (
      <div>
        <Link to="/customers" className="btn btn-secondary" style={{ marginBottom: '1rem' }}>
          <ArrowLeft size={16} /> Back to Customers
        </Link>
        <ErrorBanner message={error} />
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '680px', margin: '0 auto' }}>
      <div style={{ marginBottom: '1.25rem' }}>
        <Link to="/customers" className="btn btn-secondary btn-sm" style={{ marginBottom: '0.75rem' }}>
          <ArrowLeft size={14} /> Back to Directory
        </Link>
      </div>

      <div className="card">
        <div className="card-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div className="stat-icon purple" style={{ width: '38px', height: '38px' }}>
              <User size={18} />
            </div>
            <div>
              <div className="card-title">Edit Customer Profile: {customer?.name}</div>
              <div className="card-subtitle">
                ID #{customer?.id} • Licence: {customer?.drivingLicenceNumber}
              </div>
            </div>
          </div>
        </div>
        <div className="card-body">
          <CustomerForm
            initialData={customer}
            onSubmit={handleUpdate}
            onCancel={() => navigate('/customers')}
            isLoading={isSubmitting}
          />
        </div>
      </div>
    </div>
  );
}
