import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Edit2,
  Trash2,
  CalendarCheck,
  Tag,
  Car,
  Bike,
  MapPin,
  CheckCircle2,
  Fuel,
  Users,
  Gauge,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

const FALLBACK_IMAGE = 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=800&q=80';

export default function VehicleCard({
  vehicle,
  owner = null,
  onDelete = null,
  onBook = null,
  isCurrentlyRented = false,
  showAdminControls = false,
}) {
  const navigate = useNavigate();

  const isAvailable = vehicle.available && !isCurrentlyRented;
  const isBike =
    vehicle.type === 'Bike' ||
    ['Cruiser', 'Sports', 'Commuter', 'Scooter'].includes(vehicle.category) ||
    vehicle.category === 'Bike';

  const ownerName = owner?.name || vehicle.ownerName || 'Verified Host';
  const isOwnerVerified = owner ? owner.verificationStatus === 'Verified' : true;

  const handleBookClick = () => {
    if (onBook) {
      onBook(vehicle);
    } else {
      navigate(`/book?vehicleId=${vehicle.id}`);
    }
  };

  const handleViewDetails = () => {
    navigate(`/vehicles/view/${vehicle.id}`);
  };

  return (
    <div className="vehicle-card" style={{ display: 'flex', flexDirection: 'column' }}>
      {/* Image & Badges */}
      <div className="vehicle-card-image-wrap" onClick={handleViewDetails} style={{ cursor: 'pointer' }}>
        <img
          src={vehicle.imageUrl || FALLBACK_IMAGE}
          alt={vehicle.name}
          className="vehicle-card-img"
          onError={(e) => {
            e.currentTarget.onerror = null;
            e.currentTarget.src = FALLBACK_IMAGE;
          }}
        />

        <div className="vehicle-card-badges">
          <span className="badge badge-category">
            {isBike ? <Bike size={12} /> : <Car size={12} />}
            {vehicle.category || (isBike ? 'Bike' : 'Car')}
          </span>

          <span className={`badge ${isAvailable ? 'badge-available' : 'badge-unavailable'}`}>
            {isAvailable ? 'Available Now' : isCurrentlyRented ? 'Rented Today' : 'Unavailable'}
          </span>
        </div>

        {/* Every car name overlay on original image */}
        <div
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            background: 'linear-gradient(to top, rgba(15, 23, 42, 0.95) 0%, rgba(15, 23, 42, 0.6) 60%, transparent 100%)',
            padding: '1.25rem 0.85rem 0.55rem 0.85rem',
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'space-between',
            gap: '0.4rem',
            zIndex: 2,
          }}
        >
          <div style={{ minWidth: 0, flex: 1 }}>
            <span
              style={{
                display: 'block',
                fontSize: '0.66rem',
                fontWeight: '700',
                color: '#93c5fd',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                marginBottom: '0.1rem',
              }}
            >
              Original Indian Model
            </span>
            <div
              style={{
                fontSize: '0.96rem',
                fontWeight: '800',
                color: '#ffffff',
                lineHeight: 1.25,
                textShadow: '0 2px 4px rgba(0, 0, 0, 0.9)',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
              title={vehicle.name}
            >
              {vehicle.name}
            </div>
          </div>
          <span
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.22)',
              backdropFilter: 'blur(4px)',
              border: '1px solid rgba(255, 255, 255, 0.35)',
              color: '#ffffff',
              padding: '0.18rem 0.45rem',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.68rem',
              fontWeight: '700',
              flexShrink: 0,
            }}
          >
            {vehicle.brand}
          </span>
        </div>
      </div>

      {/* Card Body */}
      <div className="vehicle-card-body" style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div>
          {/* Title & Brand */}
          <div className="vehicle-card-header" style={{ marginBottom: '0.4rem' }}>
            <div
              className="vehicle-card-title"
              onClick={handleViewDetails}
              style={{ cursor: 'pointer', fontSize: '1.05rem', fontWeight: '700' }}
            >
              {vehicle.name}
            </div>
            <div className="vehicle-card-brand" style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              {vehicle.brand} • {vehicle.model} {vehicle.manufacturingYear ? `(${vehicle.manufacturingYear})` : ''}
            </div>
          </div>

          {/* Owner Info & Verification Badge */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.4rem',
              fontSize: '0.8rem',
              color: 'var(--text-main)',
              marginBottom: '0.65rem',
              padding: '0.35rem 0.6rem',
              backgroundColor: 'var(--bg-subtle)',
              borderRadius: 'var(--radius-sm)',
            }}
          >
            <span style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>Owner:</span>
            <strong style={{ fontWeight: '600' }}>{ownerName}</strong>
            {isOwnerVerified && (
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.2rem',
                  fontSize: '0.7rem',
                  fontWeight: '600',
                  color: 'var(--success)',
                  marginLeft: 'auto',
                }}
                title="Verified Owner"
              >
                <CheckCircle2 size={12} /> Verified
              </span>
            )}
          </div>

          {/* Specs Highlights Grid */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '0.4rem',
              fontSize: '0.76rem',
              color: 'var(--text-muted)',
              marginBottom: '0.75rem',
              backgroundColor: '#fafafa',
              padding: '0.5rem',
              borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--border-color)',
            }}
          >
            {/* Spec 1: Seating (Car) or Engine CC (Bike) */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              {isBike ? (
                <>
                  <Gauge size={13} style={{ color: 'var(--primary)' }} />
                  <span style={{ fontWeight: '600' }}>{vehicle.engineCapacityCC || '350'} CC</span>
                </>
              ) : (
                <>
                  <Users size={13} style={{ color: 'var(--primary)' }} />
                  <span style={{ fontWeight: '600' }}>{vehicle.seatingCapacity ? `${vehicle.seatingCapacity} Seater` : '5 Seater'}</span>
                </>
              )}
            </div>

            {/* Spec 2: Fuel Type */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              <Fuel size={13} style={{ color: 'var(--primary)' }} />
              <span style={{ fontWeight: '600' }}>{vehicle.fuelType || 'Petrol'}</span>
            </div>

            {/* Spec 3: Transmission */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              <span style={{ fontWeight: '600', color: 'var(--primary)' }}>⚙️</span>
              <span style={{ fontWeight: '600' }}>{vehicle.transmission || 'Manual'}</span>
            </div>

            {/* Spec 4: Location */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              <MapPin size={13} style={{ color: 'var(--primary)', flexShrink: 0 }} />
              <span title={vehicle.pickupLocation || 'ATV Tadepalligudem'}>
                {vehicle.pickupLocation || 'ATV Tadepalligudem'}
              </span>
            </div>
          </div>

          {/* Main Safety Highlights */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              backgroundColor: '#f0fdf4',
              color: '#166534',
              border: '1px solid #bbf7d0',
              borderRadius: 'var(--radius-sm)',
              padding: '0.3rem 0.55rem',
              fontSize: '0.73rem',
              marginBottom: '0.5rem',
              overflow: 'hidden',
            }}
            title="Standard Vehicle Safety Suite"
          >
            <ShieldCheck size={13} style={{ flexShrink: 0, color: '#16a34a' }} />
            <span style={{ fontWeight: '600', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {isBike
                ? (vehicle.features?.filter((f) => ['ABS', 'Disc Brakes'].includes(f)).join(' • ') || 'Front & Rear Disc • ABS')
                : (vehicle.features?.filter((f) => ['Airbags', 'ABS', 'Rear Camera', 'Parking Sensors'].includes(f)).slice(0, 3).join(' • ') || 'Airbags • ABS • Rear Camera')}
            </span>
          </div>
        </div>

        {/* Footer & Actions */}
        <div className="vehicle-card-footer" style={{ marginTop: '0.5rem', borderTop: '1px solid var(--border-color)', paddingTop: '0.75rem' }}>
          <div className="vehicle-price-box">
            <div className="vehicle-price-val">₹{Number(vehicle.pricePerDay || 0).toLocaleString('en-IN')}</div>
            <div className="vehicle-price-unit">per day</div>
          </div>

          <div className="vehicle-actions-row">
            {/* View Details Button */}
            <button
              type="button"
              className="btn btn-sm btn-secondary"
              onClick={handleViewDetails}
              title="View full vehicle specifications & gallery"
            >
              Details
            </button>

            {/* Rent Now Button */}
            {isAvailable && (
              <button
                type="button"
                className="btn btn-sm btn-primary"
                onClick={handleBookClick}
                title="Book this vehicle"
              >
                <CalendarCheck size={14} /> Rent Now
              </button>
            )}

            {/* Admin Controls */}
            {showAdminControls && (
              <>
                <button
                  type="button"
                  className="btn btn-sm btn-secondary btn-icon"
                  onClick={() => navigate(`/vehicles/edit/${vehicle.id}`)}
                  title="Edit Vehicle"
                >
                  <Edit2 size={14} />
                </button>
                {onDelete && (
                  <button
                    type="button"
                    className="btn btn-sm btn-danger-light btn-icon"
                    onClick={() => onDelete(vehicle)}
                    title="Delete Vehicle"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}