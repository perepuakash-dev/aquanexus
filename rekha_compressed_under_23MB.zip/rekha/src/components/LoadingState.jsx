import React from 'react';
import { AlertCircle, Inbox, RefreshCw } from 'lucide-react';

export function LoadingSpinner({ message = 'Loading data from server...' }) {
  return (
    <div className="loading-container">
      <div className="spinner"></div>
      <p>{message}</p>
    </div>
  );
}

export function ErrorBanner({ message, onRetry }) {
  if (!message) return null;
  return (
    <div className="alert alert-error" role="alert">
      <AlertCircle size={20} style={{ flexShrink: 0 }} />
      <div style={{ flex: 1 }}>{message}</div>
      {onRetry && (
        <button
          onClick={onRetry}
          className="btn btn-sm btn-secondary"
          style={{ marginLeft: 'auto', backgroundColor: '#ffffff' }}
        >
          <RefreshCw size={14} /> Retry
        </button>
      )}
    </div>
  );
}

export function EmptyState({ title = 'No records found', description, action }) {
  return (
    <div className="empty-state">
      <div className="empty-icon-wrap">
        <Inbox size={28} />
      </div>
      <h3 className="empty-title">{title}</h3>
      {description && <p className="empty-desc">{description}</p>}
      {action && <div>{action}</div>}
    </div>
  );
}
