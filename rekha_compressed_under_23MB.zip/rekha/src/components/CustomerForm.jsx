import React, { useState, useEffect } from 'react';
import { Save, X } from 'lucide-react';

export default function CustomerForm({
  initialData = null,
  onSubmit,
  onCancel,
  isLoading = false,
}) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    drivingLicenceNumber: '',
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name || '',
        email: initialData.email || '',
        phone: initialData.phone || '',
        address: initialData.address || '',
        drivingLicenceNumber: initialData.drivingLicenceNumber || '',
      });
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Full customer name is required.';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!emailRegex.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address (e.g. name@example.com).';
    }

    // Phone validation: Indian standard or international 10-15 digits
    const cleanedPhone = formData.phone.replace(/[\s\-\+\(\)]/g, '');
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required.';
    } else if (cleanedPhone.length < 10 || isNaN(cleanedPhone)) {
      newErrors.phone = 'Please enter a valid 10-digit phone number.';
    }

    if (!formData.drivingLicenceNumber.trim()) {
      newErrors.drivingLicenceNumber = 'Driving licence number is required.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    onSubmit({
      ...formData,
      name: formData.name.trim(),
      email: formData.email.trim().toLowerCase(),
      phone: formData.phone.trim(),
      address: formData.address.trim(),
      drivingLicenceNumber: formData.drivingLicenceNumber.trim().toUpperCase(),
    });
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <div className="form-group">
        <label className="form-label" htmlFor="customerName">
          Full Name <span className="required">*</span>
        </label>
        <input
          id="customerName"
          name="name"
          type="text"
          className={`form-input ${errors.name ? 'is-invalid' : ''}`}
          placeholder="e.g. Rahul Kumar"
          value={formData.name}
          onChange={handleChange}
          disabled={isLoading}
        />
        {errors.name && <span className="form-error">{errors.name}</span>}
      </div>

      <div className="form-grid-2">
        <div className="form-group">
          <label className="form-label" htmlFor="customerEmail">
            Email Address <span className="required">*</span>
          </label>
          <input
            id="customerEmail"
            name="email"
            type="email"
            className={`form-input ${errors.email ? 'is-invalid' : ''}`}
            placeholder="e.g. rahul@example.com"
            value={formData.email}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.email && <span className="form-error">{errors.email}</span>}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="customerPhone">
            Phone Number <span className="required">*</span>
          </label>
          <input
            id="customerPhone"
            name="phone"
            type="tel"
            className={`form-input ${errors.phone ? 'is-invalid' : ''}`}
            placeholder="e.g. 9876543210"
            value={formData.phone}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.phone && <span className="form-error">{errors.phone}</span>}
        </div>
      </div>

      <div className="form-grid-2">
        <div className="form-group">
          <label className="form-label" htmlFor="drivingLicenceNumber">
            Driving Licence Number <span className="required">*</span>
          </label>
          <input
            id="drivingLicenceNumber"
            name="drivingLicenceNumber"
            type="text"
            className={`form-input ${errors.drivingLicenceNumber ? 'is-invalid' : ''}`}
            placeholder="e.g. DL123456"
            value={formData.drivingLicenceNumber}
            onChange={handleChange}
            disabled={isLoading}
            style={{ textTransform: 'uppercase' }}
          />
          {errors.drivingLicenceNumber && (
            <span className="form-error">{errors.drivingLicenceNumber}</span>
          )}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="customerAddress">
            Address / City
          </label>
          <input
            id="customerAddress"
            name="address"
            type="text"
            className="form-input"
            placeholder="e.g. Tadepalligudem, AP"
            value={formData.address}
            onChange={handleChange}
            disabled={isLoading}
          />
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', borderTop: '1px solid var(--border-color)', paddingTop: '1.25rem' }}>
        {onCancel && (
          <button
            type="button"
            className="btn btn-secondary"
            onClick={onCancel}
            disabled={isLoading}
          >
            <X size={16} /> Cancel
          </button>
        )}
        <button
          type="submit"
          className="btn btn-primary"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <span className="spinner" style={{ width: '14px', height: '14px', borderWidth: '2px' }}></span>
              Saving...
            </>
          ) : (
            <>
              <Save size={16} /> {initialData ? 'Update Customer' : 'Register Customer'}
            </>
          )}
        </button>
      </div>
    </form>
  );
}
