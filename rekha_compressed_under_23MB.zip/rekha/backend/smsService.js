/**
 * Backend SMS Notification Service
 * Supports genuine SMS providers: Twilio, 2Factor (India DLT), MSG91 (India DLT), Fast2SMS
 * Follows strict DLT compliance for Indian mobile numbers (+91).
 */

const DEDUPE_WINDOW_MS = 10 * 60 * 1000; // 10 minutes
const sentNotificationsCache = new Map();

/**
 * Validates and formats Indian mobile numbers
 * Accepts: 9492343566, +919492343566, 09492343566, 919492343566
 * Returns: { valid: boolean, clean10: string, e164: string, error?: string }
 */
export function validateIndianMobile(rawPhone) {
  if (!rawPhone || typeof rawPhone !== 'string') {
    return { valid: false, error: 'Mobile number is required.' };
  }

  // Remove spaces, hyphens, parentheses, etc.
  const cleaned = rawPhone.replace(/[\s\-\(\)\.]/g, '');

  let digits = cleaned;
  if (digits.startsWith('+91')) {
    digits = digits.slice(3);
  } else if (digits.startsWith('91') && digits.length === 12) {
    digits = digits.slice(2);
  } else if (digits.startsWith('0') && digits.length === 11) {
    digits = digits.slice(1);
  }

  // Indian mobile numbers must be exactly 10 digits starting with 6, 7, 8, or 9
  const isIndianMobile = /^[6-9]\d{9}$/.test(digits);
  if (!isIndianMobile) {
    return {
      valid: false,
      raw: rawPhone,
      error: 'Invalid Indian mobile number. Must be a 10-digit number starting with 6, 7, 8, or 9.',
    };
  }

  return {
    valid: true,
    clean10: digits,
    e164: `+91${digits}`,
  };
}

/**
 * Detects configured SMS provider based on backend environment variables
 */
export function detectSmsProvider() {
  const chosen = (process.env.SMS_PROVIDER || 'auto').toLowerCase();

  const twilioConfigured = Boolean(
    process.env.TWILIO_ACCOUNT_SID &&
    process.env.TWILIO_AUTH_TOKEN &&
    process.env.TWILIO_PHONE_NUMBER
  );

  const twoFactorConfigured = Boolean(process.env.TWO_FACTOR_API_KEY);

  const msg91Configured = Boolean(
    process.env.MSG91_AUTH_KEY &&
    process.env.MSG91_TEMPLATE_ID
  );

  const fast2smsConfigured = Boolean(process.env.FAST2SMS_API_KEY);

  if (chosen === 'twilio' && twilioConfigured) return 'Twilio';
  if (chosen === '2factor' && twoFactorConfigured) return '2Factor';
  if (chosen === 'msg91' && msg91Configured) return 'MSG91';
  if (chosen === 'fast2sms' && fast2smsConfigured) return 'Fast2SMS';

  // Auto-detect first configured
  if (twoFactorConfigured) return '2Factor';
  if (twilioConfigured) return 'Twilio';
  if (msg91Configured) return 'MSG91';
  if (fast2smsConfigured) return 'Fast2SMS';

  return null;
}

/**
 * Formats notification message according to user requirements
 */
export function formatSmsMessage(event, details) {
  const businessName = details.businessName || process.env.BUSINESS_NAME || 'DriveEase Tadepalligudem';
  const customerName = details.customerName || 'Customer';
  const bookingId = details.bookingId || details.id || 'N/A';
  const carName = details.vehicleName || details.carName || 'Selected Vehicle';
  const pickupDate = details.startDate || 'N/A';
  const returnDate = details.endDate || 'N/A';
  const totalAmount = details.totalAmount ? Number(details.totalAmount).toLocaleString('en-IN') : '0';

  switch (event) {
    case 'BOOKING_CREATED':
      return `Hello ${customerName}! Your car booking request has been received successfully.\n\nBooking ID: ${bookingId}\nCar: ${carName}\nPickup Date: ${pickupDate}\nReturn Date: ${returnDate}\nTotal Amount: ₹${totalAmount}\n\nBooking Status: Pending Approval.\n\nThank you for choosing ${businessName}!`;

    case 'BOOKING_APPROVED':
      return `Hello ${customerName}! Your car booking has been approved!\n\nBooking ID: ${bookingId}\nCar: ${carName}\nPickup Date: ${pickupDate}\nStatus: Approved\n\nThank you for choosing ${businessName}!`;

    case 'BOOKING_REJECTED':
      return `Hello ${customerName}! Sorry, your car booking request has been rejected. Please contact us at 9492343566.\n\nBooking ID: ${bookingId}\nCar: ${carName}\n\nThank you for choosing ${businessName}!`;

    case 'BOOKING_CANCELLED':
      return `Hello ${customerName}! Your car booking has been cancelled successfully.\n\nBooking ID: ${bookingId}\nCar: ${carName}\n\nThank you for choosing ${businessName}!`;

    case 'BOOKING_COMPLETED':
      return `Hello ${customerName}! Thank you for choosing us. Your rental booking is completed.\n\nBooking ID: ${bookingId}\nCar: ${carName}\nReturn Date: ${returnDate}\n\n${businessName} wishes you a great day ahead!`;

    default:
      return `Hello ${customerName}! Update for Booking ID ${bookingId}: Status is ${details.status || 'Updated'}. Thank you for choosing ${businessName}!`;
  }
}

/**
 * Dispatches SMS via Twilio REST API
 */
async function sendViaTwilio(e164Phone, messageText) {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const fromNumber = process.env.TWILIO_PHONE_NUMBER;

  const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
  const basicAuth = Buffer.from(`${accountSid}:${authToken}`).toString('base64');

  const bodyParams = new URLSearchParams({
    To: e164Phone,
    From: fromNumber,
    Body: messageText,
  });

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basicAuth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: bodyParams.toString(),
  });

  const json = await response.json();

  if (!response.ok) {
    throw new Error(json.message || `Twilio HTTP ${response.status}`);
  }

  return {
    provider: 'Twilio',
    messageId: json.sid,
    status: json.status, // 'queued', 'sent', etc.
    raw: json,
  };
}

/**
 * Dispatches SMS via 2Factor India (DLT Supported)
 */
async function sendVia2Factor(clean10Phone, messageText, details) {
  const apiKey = process.env.TWO_FACTOR_API_KEY;
  const senderId = process.env.TWO_FACTOR_SENDER_ID || 'DRVESE';

  // If DLT template name is specified, use template SMS
  const templateName = process.env.TWO_FACTOR_DLT_TEMPLATE;
  if (templateName) {
    const url = `https://2factor.in/v1/API/V1/${apiKey}/ADDON_SERVICES/SEND/TSMS`;
    const formParams = new URLSearchParams({
      From: senderId,
      To: clean10Phone,
      TemplateName: templateName,
      VAR1: details.customerName || 'Customer',
      VAR2: details.bookingId || 'N/A',
      VAR3: details.vehicleName || 'Vehicle',
      VAR4: details.startDate || 'N/A',
    });

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: formParams.toString(),
    });
    const json = await response.json();
    if (json.Status !== 'Success') {
      throw new Error(json.Details || '2Factor DLT SMS dispatch failed');
    }
    return {
      provider: '2Factor (DLT)',
      messageId: json.Details,
      status: 'SENT',
      raw: json,
    };
  }

  // Direct transactional endpoint
  const url = `https://2factor.in/v1/API/V1/${apiKey}/SMS/${clean10Phone}/${encodeURIComponent(messageText)}/${senderId}`;
  const response = await fetch(url);
  const json = await response.json();

  if (json.Status !== 'Success') {
    throw new Error(json.Details || '2Factor SMS dispatch failed');
  }

  return {
    provider: '2Factor',
    messageId: json.Details,
    status: 'SENT',
    raw: json,
  };
}

/**
 * Dispatches SMS via MSG91 (Flow / DLT API)
 */
async function sendViaMsg91(clean10Phone, messageText, details) {
  const authKey = process.env.MSG91_AUTH_KEY;
  const templateId = process.env.MSG91_TEMPLATE_ID;
  const senderId = process.env.MSG91_SENDER_ID || 'DRVESE';

  const url = 'https://control.msg91.com/api/v5/flow/';
  const payload = {
    template_id: templateId,
    sender: senderId,
    short_url: '0',
    recipients: [
      {
        mobiles: `91${clean10Phone}`,
        name: details.customerName || 'Customer',
        booking_id: details.bookingId || 'N/A',
        vehicle: details.vehicleName || 'Vehicle',
        pickup_date: details.startDate || 'N/A',
      },
    ],
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      authkey: authKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const json = await response.json();
  if (json.type !== 'success') {
    throw new Error(json.message || 'MSG91 dispatch failed');
  }

  return {
    provider: 'MSG91 (DLT)',
    messageId: json.request_id,
    status: 'SENT',
    raw: json,
  };
}

/**
 * Dispatches SMS via Fast2SMS
 */
async function sendViaFast2Sms(clean10Phone, messageText) {
  const apiKey = process.env.FAST2SMS_API_KEY;
  const url = 'https://www.fast2sms.com/dev/bulkV2';

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      authorization: apiKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      route: 'q',
      message: messageText,
      language: 'english',
      flash: 0,
      numbers: clean10Phone,
    }),
  });

  const json = await response.json();
  if (!json.return) {
    throw new Error(json.message ? json.message.join(', ') : 'Fast2SMS dispatch failed');
  }

  return {
    provider: 'Fast2SMS',
    messageId: (json.request_id || json.message?.[0]) || String(Date.now()),
    status: 'SENT',
    raw: json,
  };
}

/**
 * Main function to send booking SMS notifications.
 * Handles validation, deduplication, genuine provider dispatch, and graceful error handling.
 */
export async function sendBookingSms(payload) {
  const {
    to,
    customerPhone,
    event = 'BOOKING_CREATED',
    bookingId,
    customerName,
    vehicleName,
    startDate,
    endDate,
    totalAmount,
    businessName,
  } = payload;

  const rawPhone = to || customerPhone;
  const validation = validateIndianMobile(rawPhone);

  if (!validation.valid) {
    return {
      success: false,
      status: 'INVALID_NUMBER',
      error: validation.error,
      recipient: rawPhone,
      message: null,
      bookingPreserved: true,
    };
  }

  const { clean10, e164 } = validation;
  const messageText = formatSmsMessage(event, {
    customerName,
    bookingId,
    vehicleName,
    startDate,
    endDate,
    totalAmount,
    businessName,
  });

  // Deduplication check: Avoid sending duplicate SMS for the same booking + event within 10 minutes
  const dedupeKey = `${bookingId || 'anon'}_${event}_${clean10}`;
  const now = Date.now();
  const lastSent = sentNotificationsCache.get(dedupeKey);
  if (lastSent && now - lastSent < DEDUPE_WINDOW_MS) {
    return {
      success: true,
      status: 'SKIPPED_DUPLICATE',
      messageText,
      recipient: e164,
      note: 'Notification already sent for this event within the last 10 minutes.',
      sentAt: new Date(lastSent).toISOString(),
    };
  }

  const provider = detectSmsProvider();

  // If no credentials are configured in .env, DO NOT fake a success!
  // Per requirement 5:
  // "Do not display a fake SMS-sent success message.
  // If SMS integration credentials are not configured, save the booking normally and show that SMS notifications are unavailable."
  if (!provider) {
    return {
      success: false,
      status: 'UNAVAILABLE',
      provider: 'None',
      recipient: e164,
      clean10: clean10,
      messageText,
      error: 'SMS credentials not configured in backend .env',
      hint: 'To enable live SMS delivery, set TWILIO, 2FACTOR, or MSG91 credentials in .env file.',
      bookingPreserved: true,
    };
  }

  try {
    let result;
    if (provider === 'Twilio') {
      result = await sendViaTwilio(e164, messageText);
    } else if (provider === '2Factor') {
      result = await sendVia2Factor(clean10, messageText, payload);
    } else if (provider === 'MSG91') {
      result = await sendViaMsg91(clean10, messageText, payload);
    } else if (provider === 'Fast2SMS') {
      result = await sendViaFast2Sms(clean10, messageText);
    } else {
      throw new Error(`Unsupported provider: ${provider}`);
    }

    // Mark as sent in dedupe cache
    sentNotificationsCache.set(dedupeKey, now);

    return {
      success: true,
      status: 'SENT',
      provider: result.provider,
      providerMessageId: result.messageId,
      recipient: e164,
      clean10: clean10,
      messageText,
      sentAt: new Date().toISOString(),
      raw: result.raw,
    };
  } catch (err) {
    console.error(`[SMS Service] Dispatch failed via ${provider}:`, err.message);
    return {
      success: false,
      status: 'FAILED',
      provider,
      recipient: e164,
      messageText,
      error: err.message,
      bookingPreserved: true,
    };
  }
}

