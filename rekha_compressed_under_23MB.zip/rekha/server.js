import jsonServer from 'json-server';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  sendBookingSms,
  detectSmsProvider,
  validateIndianMobile,
  formatSmsMessage,
} from './backend/smsService.js';

// Load .env if present
try {
  if (process.loadEnvFile) {
    process.loadEnvFile('.env');
  }
} catch (e) {
  // .env may not exist yet or have comments; continue gracefully
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbFilePath = path.join(__dirname, 'db.json');

const server = jsonServer.create();
const router = jsonServer.router(dbFilePath);
const middlewares = jsonServer.defaults();

const PORT = process.env.PORT || 3000;

// Apply default middlewares (logger, static, cors, no-cache)
server.use(middlewares);
server.use(jsonServer.bodyParser);

// Helper to safely read db.json
function readDb() {
  try {
    const raw = fs.readFileSync(dbFilePath, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading db.json:', err.message);
    return null;
  }
}

// Helper to safely write db.json
function writeDb(data) {
  try {
    fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing db.json:', err.message);
    return false;
  }
}

// Ensure db.json has sms_logs collection
const currentDb = readDb();
if (currentDb && !Array.isArray(currentDb.sms_logs)) {
  currentDb.sms_logs = [];
  writeDb(currentDb);
}

// ============================================================
// SMS API Endpoints
// ============================================================

/**
 * GET /api/sms/status
 * Public status metadata (never reveals API secrets)
 */
server.get('/api/sms/status', (req, res) => {
  const provider = detectSmsProvider();
  const configured = Boolean(provider);

  res.json({
    configured,
    provider: provider || 'None (Unconfigured)',
    businessName: process.env.BUSINESS_NAME || 'DriveEase Tadepalligudem',
    supportPhone: process.env.SUPPORT_PHONE || '9492343566',
    dltCompliant: provider === '2Factor' || provider === 'MSG91',
    instructions: configured
      ? `SMS service active via ${provider}. Live notifications enabled.`
      : 'SMS gateway credentials not configured in backend .env file. Booking will save normally, and user will see SMS unavailable notice.',
  });
});

/**
 * GET /api/sms/logs
 * Retrieve all logged SMS notification dispatches
 */
server.get('/api/sms/logs', (req, res) => {
  const db = readDb();
  const logs = (db && Array.isArray(db.sms_logs)) ? db.sms_logs : [];
  res.json(logs.slice().reverse());
});

/**
 * POST /api/sms/send
 * Validates mobile number, formats message, calls genuine provider,
 * and records notification status in database.
 */
server.post('/api/sms/send', async (req, res) => {
  const payload = req.body || {};
  const {
    bookingId,
    rentalId,
    customerName,
    customerPhone,
    to,
    vehicleName,
    startDate,
    endDate,
    totalAmount,
    event = 'BOOKING_CREATED',
  } = payload;

  const recipientPhone = to || customerPhone;

  // Validate phone format first
  const validation = validateIndianMobile(recipientPhone);
  if (!validation.valid) {
    return res.status(400).json({
      success: false,
      status: 'INVALID_NUMBER',
      error: validation.error,
      recipient: recipientPhone,
      bookingPreserved: true,
    });
  }

  // Attempt SMS dispatch via backend smsService
  const result = await sendBookingSms({
    ...payload,
    to: recipientPhone,
    businessName: process.env.BUSINESS_NAME || 'DriveEase Tadepalligudem',
  });

  // Prepare notification audit log entry
  const notificationRecord = {
    id: `sms-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    event,
    bookingId: bookingId || 'N/A',
    rentalId: rentalId || null,
    recipient: result.recipient || recipientPhone,
    customerName: customerName || 'Customer',
    vehicleName: vehicleName || 'Vehicle',
    status: result.status, // 'SENT' | 'UNAVAILABLE' | 'FAILED' | 'SKIPPED_DUPLICATE'
    provider: result.provider || 'None',
    providerMessageId: result.providerMessageId || null,
    message: result.messageText,
    error: result.error || null,
    timestamp: new Date().toISOString(),
  };

  // Persist notification log to db.json
  const db = readDb();
  if (db) {
    if (!Array.isArray(db.sms_logs)) {
      db.sms_logs = [];
    }
    db.sms_logs.push(notificationRecord);

    // If rentalId is provided, also attach notification to the rental record
    if (rentalId && Array.isArray(db.rentals)) {
      const rental = db.rentals.find((r) => String(r.id) === String(rentalId));
      if (rental) {
        if (!Array.isArray(rental.smsNotifications)) {
          rental.smsNotifications = [];
        }
        rental.smsNotifications.push(notificationRecord);
        rental.lastSmsStatus = result.status;
        rental.lastSmsTimestamp = notificationRecord.timestamp;
      }
    }

    writeDb(db);
  }

  // Return realistic result
  res.json({
    success: result.success,
    status: result.status,
    provider: result.provider,
    providerMessageId: result.providerMessageId,
    recipient: result.recipient,
    message: result.messageText,
    error: result.error || null,
    hint: result.hint || null,
    notificationRecord,
  });
});

// Mount JSON Server router for all standard resources (/vehicles, /owners, /customers, /rentals)
server.use(router);

server.listen(PORT, () => {
  console.log(`\n======================================================`);
  console.log(`🚗 DriveEase Backend API & SMS Gateway Server Running`);
  console.log(`📡 URL: http://localhost:${PORT}`);
  console.log(`📱 SMS Provider Status: ${detectSmsProvider() || 'None (Unconfigured in .env)'}`);
  console.log(`📋 SMS Status Endpoint: http://localhost:${PORT}/api/sms/status`);
  console.log(`✉️ SMS Dispatch Endpoint: http://localhost:${PORT}/api/sms/send`);
  console.log(`======================================================\n`);
});

