import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ownerApi, vehicleApi, customerApi, rentalApi, smsApi } from '../services/api';
import VehicleForm from '../components/VehicleForm';
import ConfirmDialog from '../components/ConfirmDialog';
import { LoadingSpinner, ErrorBanner, EmptyState } from '../components/LoadingState';
import { formatDisplayDate } from '../utils/dateUtils';
import {
  Car,
  Bike,
  Plus,
  CheckCircle2,
  XCircle,
  Clock,
  IndianRupee,
  CalendarCheck,
  Users,
  Search,
  Filter,
  Eye,
  Edit2,
  Trash2,
  Check,
  X,
  MapPin,
  Phone,
  Mail,
  ShieldCheck,
  ArrowRight,
  TrendingUp,
  FileText,
} from 'lucide-react';

export default function OwnerDashboard() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [owners, setOwners] = useState([]);
  const [selectedOwnerId, setSelectedOwnerId] = useState('');
  const [vehicles, setVehicles] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  // Active Tab: 'overview' | 'bookings' | 'vehicles' | 'earnings'
  const [activeTab, setActiveTab] = useState('overview');

  // Modals
  const [isAddVehicleOpen, setIsAddVehicleOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState(null);
  const [vehicleToDelete, setVehicleToDelete] = useState(null);
  const [viewRentalDetails, setViewRentalDetails] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [oData, vData, cData, rData] = await Promise.all([
        ownerApi.getAll(),
        vehicleApi.getAll(),
        customerApi.getAll(),
        rentalApi.getAll(),
      ]);
      const ownerList = oData || [];
      setOwners(ownerList);
      setVehicles(vData || []);
      setCustomers(cData || []);
      setRentals(rData || []);

      // Default to URL param or first owner
      const requestedId = searchParams.get('ownerId');
      if (requestedId && ownerList.some((o) => String(o.id) === String(requestedId))) {
        setSelectedOwnerId(String(requestedId));
      } else if (ownerList.length > 0) {
        setSelectedOwnerId(String(ownerList[0].id));
      }
    } catch (err) {
      setError(err.message || 'Failed to load owner dashboard.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const currentOwner = owners.find((o) => String(o.id) === String(selectedOwnerId));

  // Switch owner in URL & state
  const handleOwnerSelect = (newId) => {
    setSelectedOwnerId(newId);
    setSearchParams({ ownerId: newId });
  };

  // Filter ONLY vehicles and bookings belonging to this owner
  const ownerVehicles = vehicles.filter((v) => String(v.ownerId) === String(selectedOwnerId));
  const ownerRentals = rentals.filter((r) => String(r.ownerId) === String(selectedOwnerId));

  // Booking metrics
  const pendingRequests = ownerRentals.filter(
    (r) => (r.bookingStatus || r.status || '').toLowerCase() === 'pending'
  );
  const approvedBookings = ownerRentals.filter(
    (r) => (r.bookingStatus || r.status || '').toLowerCase() === 'approved'
  );
  const completedRentals = ownerRentals.filter(
    (r) => (r.bookingStatus || r.status || '').toLowerCase() === 'completed'
  );

  const availableVehiclesCount = ownerVehicles.filter((v) => v.available).length;
  const rentedVehiclesCount = ownerVehicles.length - availableVehiclesCount;

  // Earnings calculation
  const totalEarnings = ownerRentals
    .filter((r) => {
      const s = (r.bookingStatus || r.status || '').toLowerCase();
      return s === 'completed' || s === 'approved' || s === 'ongoing';
    })
    .reduce((sum, r) => sum + Number(r.totalAmount || 0), 0);

  // Approve Booking Request
  const handleApproveBooking = async (rental) => {
    setIsSubmitting(true);
    try {
      const vehicle = vehicles.find((v) => String(v.id) === String(rental.vehicleId));
      const customer = customers.find((c) => String(c.id) === String(rental.customerId));
      const phone = rental.customerPhone || customer?.phone || '';

      const updated = await rentalApi.update(rental.id, {
        ...rental,
        bookingStatus: 'Approved',
        status: 'Approved',
      });
      setRentals((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));

      // Trigger SMS notification for Approved booking
      let smsNotice = '';
      try {
        const smsRes = await smsApi.send({
          bookingId: rental.bookingId || `BK-2026-${rental.id}`,
          rentalId: rental.id,
          customerName: rental.customerName || customer?.name,
          customerPhone: phone,
          vehicleName: vehicle?.name,
          startDate: rental.startDate,
          endDate: rental.endDate,
          totalAmount: rental.totalAmount,
          event: 'BOOKING_APPROVED',
        });
        if (smsRes.status === 'SENT') {
          smsNotice = ` (SMS confirmation sent via ${smsRes.provider})`;
        } else if (smsRes.status === 'UNAVAILABLE') {
          smsNotice = ` (SMS service unconfigured in .env)`;
        }
      } catch (smsErr) {
        console.warn('SMS approval dispatch note:', smsErr);
      }

      setSuccessMessage(`Booking #${rental.bookingId || rental.id} has been Approved.${smsNotice}`);
      setTimeout(() => setSuccessMessage(null), 5000);
    } catch (err) {
      alert(`Approval failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Reject Booking Request
  const handleRejectBooking = async (rental) => {
    const reason = prompt('Optional: Reason for rejecting this booking request:');
    setIsSubmitting(true);
    try {
      const vehicle = vehicles.find((v) => String(v.id) === String(rental.vehicleId));
      const customer = customers.find((c) => String(c.id) === String(rental.customerId));
      const phone = rental.customerPhone || customer?.phone || '';

      const updated = await rentalApi.update(rental.id, {
        ...rental,
        bookingStatus: 'Rejected',
        status: 'Rejected',
        rejectionReason: reason || 'Not available for requested dates',
      });
      setRentals((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));

      // Trigger SMS notification for Rejected booking
      let smsNotice = '';
      try {
        const smsRes = await smsApi.send({
          bookingId: rental.bookingId || `BK-2026-${rental.id}`,
          rentalId: rental.id,
          customerName: rental.customerName || customer?.name,
          customerPhone: phone,
          vehicleName: vehicle?.name,
          event: 'BOOKING_REJECTED',
        });
        if (smsRes.status === 'SENT') {
          smsNotice = ` (Rejection SMS sent via ${smsRes.provider})`;
        } else if (smsRes.status === 'UNAVAILABLE') {
          smsNotice = ` (SMS service unconfigured in .env)`;
        }
      } catch (smsErr) {
        console.warn('SMS reject dispatch note:', smsErr);
      }

      setSuccessMessage(`Booking #${rental.bookingId || rental.id} has been Rejected.${smsNotice}`);
      setTimeout(() => setSuccessMessage(null), 5000);
    } catch (err) {
      alert(`Rejection failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Toggle vehicle availability
  const handleToggleVehicleAvailability = async (vehicle) => {
    try {
      const updated = await vehicleApi.update(vehicle.id, {
        ...vehicle,
        available: !vehicle.available,
      });
      setVehicles((prev) => prev.map((v) => (v.id === updated.id ? updated : v)));
      setSuccessMessage(
        `"${vehicle.name}" is now marked as ${!vehicle.available ? 'Available' : 'Unavailable'}.`
      );
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      alert(`Status update failed: ${err.message}`);
    }
  };

  // Add vehicle by owner
  const handleAddVehicleSubmit = async (formData) => {
    setIsSubmitting(true);
    try {
      const created = await vehicleApi.create({
        ...formData,
        ownerId: selectedOwnerId,
      });
      setVehicles((prev) => [...prev, created]);
      setIsAddVehicleOpen(false);
      setSuccessMessage(`Vehicle "${created.name}" published to your fleet.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      alert(`Failed to add vehicle: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Edit vehicle by owner
  const handleUpdateVehicleSubmit = async (formData) => {
    if (!editingVehicle) return;
    setIsSubmitting(true);
    try {
      const updated = await vehicleApi.update(editingVehicle.id, {
        ...formData,
        ownerId: selectedOwnerId,
      });
      setVehicles((prev) => prev.map((v) => (v.id === updated.id ? updated : v)));
      setEditingVehicle(null);
      setSuccessMessage(`Vehicle "${updated.name}" updated successfully.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      alert(`Failed to update vehicle: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Delete vehicle by owner
  const handleDeleteVehicleConfirm = async () => {
    if (!vehicleToDelete) return;
    setIsSubmitting(true);
    try {
      await vehicleApi.delete(vehicleToDelete.id);
      setVehicles((prev) => prev.filter((v) => v.id !== vehicleToDelete.id));
      setSuccessMessage(`Vehicle "${vehicleToDelete.name}" deleted.`);
      setTimeout(() => setSuccessMessage(null), 3000);
      setVehicleToDelete(null);
    } catch (err) {
      alert(`Deletion failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Customer & Vehicle helper lookups
  const getCustomer = (id) => customers.find((c) => String(c.id) === String(id));
  const getVehicle = (id) => vehicles.find((v) => String(v.id) === String(id));

  if (loading) {
    return <LoadingSpinner message="Loading owner portal..." />;
  }

  return (
    <div>
      {error && <ErrorBanner message={error} onRetry={fetchData} />}

      {successMessage && (
        <div className="alert alert-success">
          <Check size={18} />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Owner Profile Banner & Persona Switcher */}
      <div
        style={{
          backgroundColor: '#ffffff',
          borderRadius: 'var(--radius-lg)',
          border: '1px solid var(--border-color)',
          padding: '1.25rem 1.5rem',
          marginBottom: '1.5rem',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '1.25rem',
          boxShadow: 'var(--shadow-sm)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <img
            src={
              currentOwner?.avatar ||
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
            }
            alt={currentOwner?.name}
            style={{
              width: '60px',
              height: '60px',
              borderRadius: '50%',
              objectFit: 'cover',
              border: '3px solid var(--primary-light)',
            }}
          />
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <h2 style={{ fontSize: '1.3rem', fontWeight: '800', color: 'var(--text-main)', margin: 0 }}>
                {currentOwner ? currentOwner.name : 'Select Owner'}
              </h2>
              {currentOwner?.verificationStatus === 'Verified' ? (
                <span className="badge badge-available" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                  <CheckCircle2 size={13} /> Verified Host
                </span>
              ) : (
                <span className="badge badge-warning">Verification Pending</span>
              )}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginTop: '0.3rem', fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              <span>
                <MapPin size={13} style={{ display: 'inline', color: 'var(--primary)' }} /> {currentOwner?.city || 'Tadepalligudem'}, {currentOwner?.state || 'AP'}
              </span>
              <span>•</span>
              <span>Phone: {currentOwner?.phone}</span>
              <span>•</span>
              <span>Email: {currentOwner?.email}</span>
            </div>
          </div>
        </div>

        {/* Persona Switcher Selector */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{ textAlign: 'right' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block' }}>
              Active Owner Account:
            </span>
            <select
              className="form-select"
              value={selectedOwnerId}
              onChange={(e) => handleOwnerSelect(e.target.value)}
              style={{ width: 'auto', fontWeight: '600', padding: '0.4rem 0.75rem' }}
            >
              {owners.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.name} ({o.city})
                </option>
              ))}
            </select>
          </div>

          <button
            className="btn btn-primary"
            onClick={() => setIsAddVehicleOpen(true)}
          >
            <Plus size={16} /> Add Vehicle
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="stats-grid" style={{ marginBottom: '1.5rem' }}>
        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Listed Fleet</span>
            <span className="stat-value">{ownerVehicles.length}</span>
            <span className="stat-subtext">Cars & bikes listed</span>
          </div>
          <div className="stat-icon blue">
            <Car size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Available Vehicles</span>
            <span className="stat-value" style={{ color: 'var(--success)' }}>
              {availableVehiclesCount}
            </span>
            <span className="stat-subtext">{rentedVehiclesCount} currently booked</span>
          </div>
          <div className="stat-icon green">
            <CheckCircle2 size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Pending Requests</span>
            <span className="stat-value" style={{ color: pendingRequests.length > 0 ? 'var(--warning)' : 'var(--text-muted)' }}>
              {pendingRequests.length}
            </span>
            <span className="stat-subtext">Need your approval</span>
          </div>
          <div className="stat-icon amber">
            <Clock size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Approved & Completed</span>
            <span className="stat-value">{approvedBookings.length + completedRentals.length}</span>
            <span className="stat-subtext">Successful bookings</span>
          </div>
          <div className="stat-icon purple">
            <CalendarCheck size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Rental Income</span>
            <span className="stat-value" style={{ color: 'var(--success)' }}>
              ₹{totalEarnings.toLocaleString('en-IN')}
            </span>
            <span className="stat-subtext">Direct owner revenue</span>
          </div>
          <div className="stat-icon green">
            <IndianRupee size={22} />
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="attachment-tabs" style={{ marginBottom: '1.5rem' }}>
        <button
          type="button"
          className={`attachment-tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          <TrendingUp size={15} /> Overview & Pending Requests ({pendingRequests.length})
        </button>
        <button
          type="button"
          className={`attachment-tab-btn ${activeTab === 'vehicles' ? 'active' : ''}`}
          onClick={() => setActiveTab('vehicles')}
        >
          <Car size={15} /> My Fleet Inventory ({ownerVehicles.length})
        </button>
        <button
          type="button"
          className={`attachment-tab-btn ${activeTab === 'bookings' ? 'active' : ''}`}
          onClick={() => setActiveTab('bookings')}
        >
          <CalendarCheck size={15} /> All Booking Requests ({ownerRentals.length})
        </button>
        <button
          type="button"
          className={`attachment-tab-btn ${activeTab === 'earnings' ? 'active' : ''}`}
          onClick={() => setActiveTab('earnings')}
        >
          <IndianRupee size={15} /> Earnings Breakdown
        </button>
      </div>

      {/* TAB 1: OVERVIEW & PENDING BOOKING REQUESTS */}
      {activeTab === 'overview' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Pending Booking Requests Section */}
          <div className="card">
            <div className="card-header">
              <div>
                <div className="card-title" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Clock size={18} style={{ color: 'var(--warning)' }} />
                  Pending Customer Booking Requests ({pendingRequests.length})
                </div>
                <div className="card-subtitle">
                  Review customer details and approve or reject incoming reservations
                </div>
              </div>
            </div>

            <div className="card-body" style={{ padding: 0 }}>
              {pendingRequests.length === 0 ? (
                <div style={{ padding: '2.5rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                  <CheckCircle2 size={36} style={{ color: 'var(--success)', margin: '0 auto 0.75rem auto', display: 'block' }} />
                  <strong>All caught up!</strong> No pending booking requests at this time.
                </div>
              ) : (
                <div className="table-container" style={{ border: 'none', borderRadius: 0 }}>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Booking ID</th>
                        <th>Customer</th>
                        <th>Vehicle</th>
                        <th>Rental Period</th>
                        <th>Days</th>
                        <th>Total Amount</th>
                        <th style={{ textAlign: 'right' }}>Decision Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pendingRequests.map((rental) => {
                        const cust = getCustomer(rental.customerId);
                        const veh = getVehicle(rental.vehicleId);
                        return (
                          <tr key={rental.id}>
                            <td>
                              <span style={{ fontFamily: 'monospace', fontWeight: '700', color: 'var(--primary)' }}>
                                #{rental.id}
                              </span>
                            </td>
                            <td>
                              <div>
                                <strong>{cust ? cust.name : (rental.customerName || `Customer #${rental.customerId}`)}</strong>
                                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                  {cust ? cust.phone : (rental.customerPhone || '')} • DL: {cust ? cust.drivingLicenceNumber : '—'}
                                </div>
                              </div>
                            </td>
                            <td>
                              <div>
                                <strong>{veh ? veh.name : `Vehicle #${rental.vehicleId}`}</strong>
                                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                  {veh ? `Reg: ${veh.registrationNumber}` : ''}
                                </div>
                              </div>
                            </td>
                            <td>
                              <div>
                                {formatDisplayDate(rental.startDate)} → {formatDisplayDate(rental.endDate)}
                              </div>
                            </td>
                            <td>{rental.numberOfDays || rental.days} days</td>
                            <td>
                              <strong style={{ color: 'var(--primary)', fontSize: '0.95rem' }}>
                                ₹{Number(rental.totalAmount || 0).toLocaleString('en-IN')}
                              </strong>
                            </td>
                            <td style={{ textAlign: 'right' }}>
                              <div style={{ display: 'inline-flex', gap: '0.5rem' }}>
                                <button
                                  type="button"
                                  className="btn btn-sm btn-primary"
                                  onClick={() => handleApproveBooking(rental)}
                                  disabled={isSubmitting}
                                >
                                  <Check size={14} /> Approve
                                </button>
                                <button
                                  type="button"
                                  className="btn btn-sm btn-danger-light"
                                  onClick={() => handleRejectBooking(rental)}
                                  disabled={isSubmitting}
                                >
                                  <X size={14} /> Reject
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Quick Fleet Snapshot */}
          <div className="card">
            <div className="card-header">
              <div>
                <div className="card-title">My Fleet Quick Status</div>
                <div className="card-subtitle">Manage availability or modify vehicle specifications</div>
              </div>
              <button
                className="btn btn-sm btn-secondary"
                onClick={() => setActiveTab('vehicles')}
              >
                View Full Fleet ({ownerVehicles.length}) <ArrowRight size={14} />
              </button>
            </div>
            <div className="card-body">
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '1rem' }}>
                {ownerVehicles.map((v) => (
                  <div
                    key={v.id}
                    style={{
                      border: '1px solid var(--border-color)',
                      borderRadius: 'var(--radius-md)',
                      padding: '1rem',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      backgroundColor: 'var(--bg-card)',
                    }}
                  >
                    <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '0.75rem' }}>
                      <img
                        src={v.imageUrl || (v.type === 'Bike' ? '/classic-350.avif' : '/front-left-side-47.avif')}
                        alt={v.name}
                        style={{ width: '70px', height: '52px', objectFit: 'cover', borderRadius: '4px' }}
                      />
                      <div>
                        <strong style={{ fontSize: '0.92rem', color: 'var(--text-main)', display: 'block' }}>
                          {v.name}
                        </strong>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {v.registrationNumber} • {v.category}
                        </span>
                        <div style={{ fontSize: '0.85rem', fontWeight: '700', color: 'var(--primary)', marginTop: '0.2rem' }}>
                          ₹{v.pricePerDay}/day
                        </div>
                      </div>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid var(--border-color)', paddingTop: '0.65rem' }}>
                      <button
                        type="button"
                        className={`btn btn-sm ${v.available ? 'btn-secondary' : 'btn-primary'}`}
                        style={{ fontSize: '0.75rem', padding: '0.25rem 0.5rem' }}
                        onClick={() => handleToggleVehicleAvailability(v)}
                      >
                        {v.available ? 'Mark Unavailable' : 'Mark Available'}
                      </button>

                      <div style={{ display: 'flex', gap: '0.35rem' }}>
                        <button
                          type="button"
                          className="btn btn-sm btn-secondary btn-icon"
                          onClick={() => setEditingVehicle(v)}
                          title="Edit vehicle"
                        >
                          <Edit2 size={13} />
                        </button>
                        <button
                          type="button"
                          className="btn btn-sm btn-danger-light btn-icon"
                          onClick={() => setVehicleToDelete(v)}
                          title="Delete vehicle"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MY FLEET INVENTORY */}
      {activeTab === 'vehicles' && (
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">My Fleet Inventory ({ownerVehicles.length})</div>
              <div className="card-subtitle">
                Cars and bikes registered under host account: <strong>{currentOwner?.name}</strong>
              </div>
            </div>
            <button
              className="btn btn-primary"
              onClick={() => setIsAddVehicleOpen(true)}
            >
              <Plus size={16} /> Add New Car / Bike
            </button>
          </div>

          <div className="card-body" style={{ padding: 0 }}>
            {ownerVehicles.length === 0 ? (
              <EmptyState
                title="No vehicles in your fleet yet"
                description="List your first car or bike to start receiving customer rental bookings."
                action={
                  <button className="btn btn-primary" onClick={() => setIsAddVehicleOpen(true)}>
                    <Plus size={16} /> Add First Vehicle
                  </button>
                }
              />
            ) : (
              <div className="table-container" style={{ border: 'none', borderRadius: 0 }}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Vehicle</th>
                      <th>Category & Type</th>
                      <th>Reg Number</th>
                      <th>Specs</th>
                      <th>Daily Rate</th>
                      <th>Availability</th>
                      <th style={{ textAlign: 'right' }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ownerVehicles.map((v) => (
                      <tr key={v.id}>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                            <img
                              src={v.imageUrl || (v.type === 'Bike' ? '/classic-350.avif' : '/front-left-side-47.avif')}
                              alt={v.name}
                              style={{ width: '48px', height: '36px', objectFit: 'cover', borderRadius: '4px' }}
                            />
                            <div>
                              <strong>{v.name}</strong>
                              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                {v.brand} {v.model} ({v.manufacturingYear})
                              </div>
                            </div>
                          </div>
                        </td>
                        <td>
                          <span className="badge badge-category">
                            {v.type === 'Bike' ? '🏍️ Bike' : '🚗 Car'} • {v.category}
                          </span>
                        </td>
                        <td>
                          <span style={{ fontFamily: 'monospace', fontWeight: '600' }}>
                            {v.registrationNumber}
                          </span>
                        </td>
                        <td>
                          <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                            {v.type === 'Car' ? (
                              <span>{v.seatingCapacity || 5} Seats • {v.fuelType} • {v.transmission}</span>
                            ) : (
                              <span>{v.engineCapacityCC} CC • {v.fuelType} • {v.mileageKmpl} km/l</span>
                            )}
                          </div>
                        </td>
                        <td>
                          <strong>₹{Number(v.pricePerDay || 0).toLocaleString('en-IN')}</strong> / day
                        </td>
                        <td>
                          <span className={`badge ${v.available ? 'badge-available' : 'badge-unavailable'}`}>
                            {v.available ? 'Available' : 'Rented / Unavailable'}
                          </span>
                        </td>
                        <td style={{ textAlign: 'right' }}>
                          <div style={{ display: 'inline-flex', gap: '0.4rem' }}>
                            <button
                              type="button"
                              className="btn btn-sm btn-secondary"
                              onClick={() => handleToggleVehicleAvailability(v)}
                              title="Toggle Availability"
                            >
                              {v.available ? 'Pause' : 'Activate'}
                            </button>
                            <button
                              type="button"
                              className="btn btn-sm btn-secondary btn-icon"
                              onClick={() => setEditingVehicle(v)}
                              title="Edit Vehicle Specs"
                            >
                              <Edit2 size={14} />
                            </button>
                            <button
                              type="button"
                              className="btn btn-sm btn-danger-light btn-icon"
                              onClick={() => setVehicleToDelete(v)}
                              title="Delete Vehicle"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: ALL BOOKINGS & REQUESTS */}
      {activeTab === 'bookings' && (
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">All Rental Bookings & Requests ({ownerRentals.length})</div>
              <div className="card-subtitle">
                Complete history of reservations for {currentOwner?.name}'s vehicles
              </div>
            </div>
          </div>

          <div className="card-body" style={{ padding: 0 }}>
            {ownerRentals.length === 0 ? (
              <EmptyState
                title="No bookings recorded yet"
                description="When customers book your vehicles from the marketplace, reservations will appear here."
              />
            ) : (
              <div className="table-container" style={{ border: 'none', borderRadius: 0 }}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Rental ID</th>
                      <th>Customer Details</th>
                      <th>Vehicle</th>
                      <th>Dates & Duration</th>
                      <th>Amount & Deposit</th>
                      <th>Status</th>
                      <th style={{ textAlign: 'right' }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ownerRentals.map((rental) => {
                      const cust = getCustomer(rental.customerId);
                      const veh = getVehicle(rental.vehicleId);
                      const s = (rental.bookingStatus || rental.status || '').toLowerCase();

                      return (
                        <tr key={rental.id}>
                          <td>
                            <span style={{ fontFamily: 'monospace', fontWeight: '700', color: 'var(--primary)' }}>
                              #{rental.id}
                            </span>
                          </td>
                          <td>
                            <div>
                              <strong>{cust ? cust.name : (rental.customerName || `Customer #${rental.customerId}`)}</strong>
                              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                {cust ? `${cust.phone} • ${cust.email}` : (rental.customerPhone || '')}
                              </div>
                            </div>
                          </td>
                          <td>
                            <div>
                              <strong>{veh ? veh.name : `Vehicle #${rental.vehicleId}`}</strong>
                              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                {veh ? veh.registrationNumber : ''}
                              </div>
                            </div>
                          </td>
                          <td>
                            <div>
                              {formatDisplayDate(rental.startDate)} → {formatDisplayDate(rental.endDate)}
                              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                {rental.numberOfDays || rental.days} days
                              </div>
                            </div>
                          </td>
                          <td>
                            <div>
                              <strong>₹{Number(rental.totalAmount || 0).toLocaleString('en-IN')}</strong>
                              {rental.securityDeposit && (
                                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                                  Deposit: ₹{rental.securityDeposit}
                                </div>
                              )}
                            </div>
                          </td>
                          <td>
                            <span className={`badge badge-${s === 'approved' ? 'available' : s === 'pending' ? 'warning' : s === 'rejected' ? 'danger' : s}`}>
                              {rental.bookingStatus || rental.status || 'Active'}
                            </span>
                          </td>
                          <td style={{ textAlign: 'right' }}>
                            <div style={{ display: 'inline-flex', gap: '0.4rem' }}>
                              <button
                                type="button"
                                className="btn btn-sm btn-secondary btn-icon"
                                onClick={() => setViewRentalDetails(rental)}
                                title="View Customer Rental Details"
                              >
                                <Eye size={14} />
                              </button>
                              {s === 'pending' && (
                                <>
                                  <button
                                    type="button"
                                    className="btn btn-sm btn-primary"
                                    onClick={() => handleApproveBooking(rental)}
                                    disabled={isSubmitting}
                                  >
                                    Approve
                                  </button>
                                  <button
                                    type="button"
                                    className="btn btn-sm btn-danger-light"
                                    onClick={() => handleRejectBooking(rental)}
                                    disabled={isSubmitting}
                                  >
                                    Reject
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: EARNINGS BREAKDOWN */}
      {activeTab === 'earnings' && (
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Rental Income & Financial Summary</div>
              <div className="card-subtitle">
                Total earnings collected from completed and approved customer reservations
              </div>
            </div>
            <div style={{ fontSize: '1.25rem', fontWeight: '800', color: 'var(--success)' }}>
              Total: ₹{totalEarnings.toLocaleString('en-IN')}
            </div>
          </div>
          <div className="card-body">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem', marginBottom: '1.5rem' }}>
              <div style={{ backgroundColor: 'var(--success-bg)', padding: '1.25rem', borderRadius: 'var(--radius-md)', border: '1px solid #bbf7d0' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--success-text)', fontWeight: '600' }}>
                  COMPLETED CONTRACTS REVENUE
                </div>
                <div style={{ fontSize: '1.6rem', fontWeight: '800', color: 'var(--success-text)', marginTop: '0.25rem' }}>
                  ₹{completedRentals.reduce((sum, r) => sum + Number(r.totalAmount || 0), 0).toLocaleString('en-IN')}
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--success-text)', marginTop: '0.25rem' }}>
                  From {completedRentals.length} completed returns
                </div>
              </div>

              <div style={{ backgroundColor: 'var(--info-bg)', padding: '1.25rem', borderRadius: 'var(--radius-md)', border: '1px solid #bae6fd' }}>
                <div style={{ fontSize: '0.8rem', color: 'var(--info-text)', fontWeight: '600' }}>
                  APPROVED & UPCOMING PIPELINE
                </div>
                <div style={{ fontSize: '1.6rem', fontWeight: '800', color: 'var(--info-text)', marginTop: '0.25rem' }}>
                  ₹{approvedBookings.reduce((sum, r) => sum + Number(r.totalAmount || 0), 0).toLocaleString('en-IN')}
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--info-text)', marginTop: '0.25rem' }}>
                  From {approvedBookings.length} confirmed bookings
                </div>
              </div>
            </div>

            <h4 style={{ fontSize: '0.92rem', fontWeight: '700', marginBottom: '0.75rem' }}>
              Transaction Log
            </h4>
            <div className="table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Transaction #</th>
                    <th>Vehicle</th>
                    <th>Customer</th>
                    <th>Duration</th>
                    <th>Daily Rate</th>
                    <th>Deposit</th>
                    <th>Net Amount</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {ownerRentals.map((r) => {
                    const c = getCustomer(r.customerId);
                    const v = getVehicle(r.vehicleId);
                    return (
                      <tr key={r.id}>
                        <td>#{r.id}</td>
                        <td>{v ? v.name : `Vehicle #${r.vehicleId}`}</td>
                        <td>{c ? c.name : `Customer #${r.customerId}`}</td>
                        <td>{r.numberOfDays || r.days} days</td>
                        <td>₹{r.pricePerDay || r.dailyPrice}/day</td>
                        <td>₹{r.securityDeposit || 0}</td>
                        <td><strong>₹{Number(r.totalAmount || 0).toLocaleString('en-IN')}</strong></td>
                        <td>
                          <span className="badge badge-category">{r.bookingStatus || r.status}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Add Vehicle Modal */}
      {isAddVehicleOpen && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-content" style={{ maxWidth: '850px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Car size={20} style={{ color: 'var(--primary)' }} />
                <h3>Add New Vehicle to {currentOwner?.name}'s Fleet</h3>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setIsAddVehicleOpen(false)}
                disabled={isSubmitting}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <VehicleForm
                defaultOwnerId={selectedOwnerId}
                existingVehicles={vehicles}
                onSubmit={handleAddVehicleSubmit}
                onCancel={() => setIsAddVehicleOpen(false)}
                isLoading={isSubmitting}
              />
            </div>
          </div>
        </div>
      )}

      {/* Edit Vehicle Modal */}
      {editingVehicle && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-content" style={{ maxWidth: '850px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Edit2 size={20} style={{ color: 'var(--primary)' }} />
                <h3>Edit Vehicle: {editingVehicle.name}</h3>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setEditingVehicle(null)}
                disabled={isSubmitting}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <VehicleForm
                initialData={editingVehicle}
                defaultOwnerId={selectedOwnerId}
                existingVehicles={vehicles}
                onSubmit={handleUpdateVehicleSubmit}
                onCancel={() => setEditingVehicle(null)}
                isLoading={isSubmitting}
              />
            </div>
          </div>
        </div>
      )}

      {/* View Customer Rental Details Modal */}
      {viewRentalDetails && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-content" style={{ maxWidth: '540px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <FileText size={20} style={{ color: 'var(--primary)' }} />
                <h3>Customer Rental Details #{viewRentalDetails.id}</h3>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setViewRentalDetails(null)}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              {(() => {
                const c = getCustomer(viewRentalDetails.customerId);
                const v = getVehicle(viewRentalDetails.vehicleId);
                return (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem', fontSize: '0.9rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Status:</span>
                      <span className="badge badge-available">
                        {viewRentalDetails.bookingStatus || viewRentalDetails.status}
                      </span>
                    </div>

                    <div>
                      <h4 style={{ fontSize: '0.85rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '0.4rem' }}>
                        Customer Profile
                      </h4>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Name:</span> <strong>{c?.name || viewRentalDetails.customerName || 'Customer'}</strong>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Phone:</span> <span>{c?.phone || viewRentalDetails.customerPhone || '—'}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Email:</span> <span>{c?.email || '—'}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Licence Number:</span> <span style={{ fontFamily: 'monospace' }}>{c?.drivingLicenceNumber || '—'}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Address:</span> <span>{c?.address || '—'}</span>
                        </div>
                      </div>
                    </div>

                    <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '0.65rem' }}>
                      <h4 style={{ fontSize: '0.85rem', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '0.4rem' }}>
                        Rental Details
                      </h4>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Vehicle:</span> <strong>{v?.name || '—'}</strong>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Registration:</span> <span style={{ fontFamily: 'monospace' }}>{v?.registrationNumber}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Period:</span> <span>{formatDisplayDate(viewRentalDetails.startDate)} → {formatDisplayDate(viewRentalDetails.endDate)}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Duration:</span> <span>{viewRentalDetails.numberOfDays || viewRentalDetails.days} days</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>Daily Rate:</span> <span>₹{viewRentalDetails.dailyPrice || viewRentalDetails.pricePerDay}/day</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid var(--border-color)', paddingTop: '0.5rem', fontWeight: '700', color: 'var(--primary)', fontSize: '1.05rem' }}>
                          <span>Total Amount:</span> <span>₹{Number(viewRentalDetails.totalAmount || 0).toLocaleString('en-IN')}</span>
                        </div>
                      </div>
                    </div>

                    {Array.isArray(viewRentalDetails.smsNotifications) && viewRentalDetails.smsNotifications.length > 0 && (
                      <div style={{ marginTop: '1rem', padding: '0.75rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                        <div style={{ fontWeight: '700', fontSize: '0.8rem', marginBottom: '0.4rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                          <FileText size={13} style={{ color: 'var(--primary)' }} /> Customer SMS Dispatch Audit
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                          {viewRentalDetails.smsNotifications.map((s, i) => (
                            <div key={i} style={{ padding: '0.35rem 0.5rem', backgroundColor: 'var(--card-bg)', borderRadius: '4px', border: '1px solid var(--border-color)', fontSize: '0.75rem' }}>
                              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.15rem' }}>
                                <strong>{s.event}</strong>
                                <span className={`badge badge-${s.status === 'SENT' ? 'success' : s.status === 'UNAVAILABLE' ? 'warning' : 'danger'}`}>
                                  {s.status} {s.provider !== 'None' ? `(${s.provider})` : ''}
                                </span>
                              </div>
                              <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>
                                To: {s.recipient} • {new Date(s.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setViewRentalDetails(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Vehicle Confirmation */}
      <ConfirmDialog
        isOpen={vehicleToDelete !== null}
        title="Delete Vehicle Listing"
        message={`Are you sure you want to remove "${vehicleToDelete?.name}" from your fleet?`}
        confirmText="Yes, Delete Vehicle"
        cancelText="Cancel"
        isDanger={true}
        isLoading={isSubmitting}
        onConfirm={handleDeleteVehicleConfirm}
        onCancel={() => setVehicleToDelete(null)}
      />
    </div>
  );
}
