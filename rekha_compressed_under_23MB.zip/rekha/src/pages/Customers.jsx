import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { customerApi, rentalApi } from '../services/api';
import CustomerForm from '../components/CustomerForm';
import ConfirmDialog from '../components/ConfirmDialog';
import { LoadingSpinner, ErrorBanner, EmptyState } from '../components/LoadingState';
import {
  UserPlus,
  Search,
  Users,
  Edit2,
  Trash2,
  Phone,
  Mail,
  CreditCard,
  MapPin,
  X,
  Check,
} from 'lucide-react';

export default function Customers() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const [customers, setCustomers] = useState([]);
  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  const [searchQuery, setSearchQuery] = useState('');

  // Add modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Deletion state
  const [customerToDelete, setCustomerToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteWarning, setDeleteWarning] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [cData, rData] = await Promise.all([
        customerApi.getAll(),
        rentalApi.getAll(),
      ]);
      setCustomers(cData || []);
      setRentals(rData || []);
    } catch (err) {
      setError(err.message || 'Failed to load customer list.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Check URL action
  useEffect(() => {
    if (searchParams.get('action') === 'add') {
      setIsAddModalOpen(true);
      searchParams.delete('action');
      setSearchParams(searchParams, { replace: true });
    }
  }, [searchParams]);

  const handleRegisterCustomer = async (formData) => {
    setIsSubmitting(true);
    try {
      const created = await customerApi.create(formData);
      setCustomers((prev) => [...prev, created]);
      setIsAddModalOpen(false);
      setSuccessMessage(`Customer "${created.name}" was successfully registered.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      alert(`Error registering customer: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Prevent deletion of customers with rental records
  const initiateDelete = (customer) => {
    const customerRentals = rentals.filter(
      (r) => String(r.customerId) === String(customer.id)
    );

    if (customerRentals.length > 0) {
      setDeleteWarning(
        `Cannot delete "${customer.name}" because this customer is referenced in ${customerRentals.length} rental record(s). Removing this customer would cause orphaned rental records. You must first delete or resolve their rental records.`
      );
    } else {
      setDeleteWarning(null);
    }
    setCustomerToDelete(customer);
  };

  const confirmDelete = async () => {
    if (!customerToDelete) return;
    setIsDeleting(true);
    try {
      await customerApi.delete(customerToDelete.id);
      setCustomers((prev) => prev.filter((c) => c.id !== customerToDelete.id));
      setSuccessMessage(`Customer "${customerToDelete.name}" was successfully deleted.`);
      setTimeout(() => setSuccessMessage(null), 4000);
      setCustomerToDelete(null);
    } catch (err) {
      alert(`Error deleting customer: ${err.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Search filter
  const filteredCustomers = customers.filter((c) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
    const matchesName = (c.name || '').toLowerCase().includes(query);
    const matchesEmail = (c.email || '').toLowerCase().includes(query);
    const matchesPhone = (c.phone || '').toLowerCase().includes(query);
    const matchesDL = (c.drivingLicenceNumber || '').toLowerCase().includes(query);
    return matchesName || matchesEmail || matchesPhone || matchesDL;
  });

  if (loading) {
    return <LoadingSpinner message="Loading customer directory..." />;
  }

  return (
    <div>
      {error && <ErrorBanner message={error} onRetry={fetchData} />}

      {successMessage && (
        <div className="alert alert-success">
          <Check size={18} />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Top action bar */}
      <div className="controls-bar">
        <div className="search-input-group">
          <Search size={18} />
          <input
            type="text"
            className="form-input"
            placeholder="Search customers by name, email, phone, or licence..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <button
          className="btn btn-primary"
          onClick={() => setIsAddModalOpen(true)}
        >
          <UserPlus size={16} /> Register Customer
        </button>
      </div>

      {/* Customers Table */}
      {filteredCustomers.length === 0 ? (
        <EmptyState
          title="No customers found"
          description="Try modifying your search or register a new customer profile."
          action={
            <button className="btn btn-primary" onClick={() => setIsAddModalOpen(true)}>
              <UserPlus size={16} /> Register First Customer
            </button>
          }
        />
      ) : (
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Customer Name</th>
                <th>Contact Details</th>
                <th>Driving Licence</th>
                <th>Address</th>
                <th>Rentals Count</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map((customer) => {
                const count = rentals.filter((r) => String(r.customerId) === String(customer.id)).length;
                return (
                  <tr key={customer.id}>
                    <td>
                      <div>
                        <strong>{customer.name}</strong>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          ID: #{customer.id}
                        </div>
                      </div>
                    </td>
                    <td>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.2rem', fontSize: '0.82rem' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                          <Mail size={13} style={{ color: 'var(--text-light)' }} /> {customer.email}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                          <Phone size={13} style={{ color: 'var(--text-light)' }} /> {customer.phone}
                        </span>
                      </div>
                    </td>
                    <td>
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '0.35rem',
                          fontFamily: 'monospace',
                          fontWeight: '600',
                          backgroundColor: 'var(--bg-subtle)',
                          padding: '0.2rem 0.5rem',
                          borderRadius: 'var(--radius-sm)',
                        }}
                      >
                        <CreditCard size={13} /> {customer.drivingLicenceNumber}
                      </span>
                    </td>
                    <td>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: 'var(--text-muted)', fontSize: '0.84rem' }}>
                        <MapPin size={13} /> {customer.address || '—'}
                      </span>
                    </td>
                    <td>
                      <span className="badge badge-category">
                        {count} {count === 1 ? 'rental' : 'rentals'}
                      </span>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '0.5rem' }}>
                        <button
                          type="button"
                          className="btn btn-sm btn-secondary btn-icon"
                          onClick={() => navigate(`/customers/edit/${customer.id}`)}
                          title="Edit Customer"
                          aria-label="Edit Customer"
                        >
                          <Edit2 size={15} />
                        </button>
                        <button
                          type="button"
                          className="btn btn-sm btn-danger-light btn-icon"
                          onClick={() => initiateDelete(customer)}
                          title="Delete Customer"
                          aria-label="Delete Customer"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Customer Modal */}
      {isAddModalOpen && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-content" style={{ maxWidth: '600px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Users size={20} style={{ color: 'var(--primary)' }} />
                <h3>Register New Customer</h3>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setIsAddModalOpen(false)}
                disabled={isSubmitting}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <CustomerForm
                onSubmit={handleRegisterCustomer}
                onCancel={() => setIsAddModalOpen(false)}
                isLoading={isSubmitting}
              />
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={customerToDelete !== null}
        title="Delete Customer"
        message={
          deleteWarning ||
          `Are you sure you want to remove customer "${customerToDelete?.name}"? This operation cannot be reversed.`
        }
        confirmText="Yes, Delete Customer"
        cancelText="Cancel"
        isDanger={true}
        isLoading={isDeleting}
        onConfirm={deleteWarning ? () => setCustomerToDelete(null) : confirmDelete}
        onCancel={() => setCustomerToDelete(null)}
      />
    </div>
  );
}
