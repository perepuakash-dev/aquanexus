import React, { useState, useEffect, useRef } from 'react';
import {
  Save,
  X,
  Upload,
  User,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  ShieldCheck,
  Building,
  FileCheck,
  Trash2,
} from 'lucide-react';

export default function OwnerForm({
  initialData = null,
  onSubmit,
  onCancel,
  isLoading = false,
  isAdmin = true,
}) {
  const fileInputRef = useRef(null);

  const [formData, setFormData] = useState({
    name: '',
    avatar: '',
    phone: '',
    email: '',
    address: '',
    city: 'Tadepalligudem',
    state: 'Andhra Pradesh',
    drivingLicenceNumber: '',
    governmentIdNumber: '',
    verificationStatus: 'Pending',
    accountStatus: 'Active',
    bio: '',
  });

  const [avatarMode, setAvatarMode] = useState('url'); // 'url' | 'upload'
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name || '',
        avatar: initialData.avatar || '',
        phone: initialData.phone || '',
        email: initialData.email || '',
        address: initialData.address || '',
        city: initialData.city || 'Tadepalligudem',
        state: initialData.state || 'Andhra Pradesh',
        drivingLicenceNumber: initialData.drivingLicenceNumber || '',
        governmentIdNumber: initialData.governmentIdNumber || '',
        verificationStatus: initialData.verificationStatus || 'Pending',
        accountStatus: initialData.accountStatus || 'Active',
        bio: initialData.bio || '',
      });
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const handleAvatarFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrors((prev) => ({ ...prev, avatar: 'Please select a valid image file.' }));
      return;
    }

    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      setFormData((prev) => ({
        ...prev,
        avatar: uploadEvent.target.result,
      }));
      if (errors.avatar) {
        setErrors((prev) => ({ ...prev, avatar: null }));
      }
    };
    reader.readAsDataURL(file);
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Full name is required.';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!emailRegex.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }

    const cleanedPhone = formData.phone.replace(/[\s\-\+\(\)]/g, '');
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required.';
    } else if (cleanedPhone.length < 10 || isNaN(cleanedPhone)) {
      newErrors.phone = 'Please enter a valid 10-digit phone number.';
    }

    if (!formData.city.trim()) {
      newErrors.city = 'City is required.';
    }

    if (!formData.drivingLicenceNumber.trim()) {
      newErrors.drivingLicenceNumber = 'Driving licence number is required.';
    }

    if (!formData.governmentIdNumber.trim()) {
      newErrors.governmentIdNumber = 'Government ID (Aadhaar / PAN / Voter ID) is required.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    onSubmit({
      ...formData,
      name: formData.name.trim(),
      email: formData.email.trim().toLowerCase(),
      phone: formData.phone.trim(),
      address: formData.address.trim(),
      city: formData.city.trim(),
      state: formData.state.trim(),
      drivingLicenceNumber: formData.drivingLicenceNumber.trim().toUpperCase(),
      governmentIdNumber: formData.governmentIdNumber.trim().toUpperCase(),
    });
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {/* Profile Photo Upload / URL */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', marginBottom: '1.25rem', padding: '1rem', backgroundColor: 'var(--bg-subtle)', borderRadius: 'var(--radius-md)' }}>
        <div style={{ position: 'relative' }}>
          <img
            src={
              formData.avatar ||
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80'
            }
            alt="Owner Avatar"
            style={{
              width: '72px',
              height: '72px',
              borderRadius: '50%',
              objectFit: 'cover',
              border: '3px solid #ffffff',
              boxShadow: 'var(--shadow-sm)',
            }}
          />
        </div>

        <div style={{ flex: 1 }}>
          <label className="form-label" style={{ marginBottom: '0.35rem' }}>
            Owner Profile Photo
          </label>
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.4rem' }}>
            <button
              type="button"
              className={`btn btn-sm ${avatarMode === 'url' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setAvatarMode('url')}
            >
              Image URL
            </button>
            <button
              type="button"
              className={`btn btn-sm ${avatarMode === 'upload' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setAvatarMode('upload')}
            >
              <Upload size={14} /> Upload Photo
            </button>
          </div>

          {avatarMode === 'url' ? (
            <input
              type="text"
              name="avatar"
              className="form-input"
              placeholder="e.g. https://images.unsplash.com/photo-..."
              value={formData.avatar}
              onChange={handleChange}
              disabled={isLoading}
              style={{ fontSize: '0.85rem' }}
            />
          ) : (
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                style={{ display: 'none' }}
                onChange={handleAvatarFileChange}
                disabled={isLoading}
              />
              <button
                type="button"
                className="btn btn-sm btn-secondary"
                onClick={() => fileInputRef.current?.click()}
                disabled={isLoading}
              >
                Choose Photo from Computer
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Basic Contact Info */}
      <div className="form-grid-2">
        <div className="form-group">
          <label className="form-label" htmlFor="ownerName">
            Full Name <span className="required">*</span>
          </label>
          <input
            id="ownerName"
            name="name"
            type="text"
            className={`form-input ${errors.name ? 'is-invalid' : ''}`}
            placeholder="e.g. Ramesh Varma"
            value={formData.name}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.name && <span className="form-error">{errors.name}</span>}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="ownerPhone">
            Phone Number <span className="required">*</span>
          </label>
          <input
            id="ownerPhone"
            name="phone"
            type="tel"
            className={`form-input ${errors.phone ? 'is-invalid' : ''}`}
            placeholder="e.g. 9848022338"
            value={formData.phone}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.phone && <span className="form-error">{errors.phone}</span>}
        </div>
      </div>

      <div className="form-grid-2">
        <div className="form-group">
          <label className="form-label" htmlFor="ownerEmail">
            Email Address <span className="required">*</span>
          </label>
          <input
            id="ownerEmail"
            name="email"
            type="email"
            className={`form-input ${errors.email ? 'is-invalid' : ''}`}
            placeholder="e.g. ramesh.varma@gmail.com"
            value={formData.email}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.email && <span className="form-error">{errors.email}</span>}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="ownerAddress">
            Street Address
          </label>
          <input
            id="ownerAddress"
            name="address"
            type="text"
            className="form-input"
            placeholder="e.g. 4-12, Main Road, Near Old Bus Stand"
            value={formData.address}
            onChange={handleChange}
            disabled={isLoading}
          />
        </div>
      </div>

      <div className="form-grid-2">
        <div className="form-group">
          <label className="form-label" htmlFor="ownerCity">
            City <span className="required">*</span>
          </label>
          <input
            id="ownerCity"
            name="city"
            type="text"
            className={`form-input ${errors.city ? 'is-invalid' : ''}`}
            placeholder="e.g. Tadepalligudem"
            value={formData.city}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.city && <span className="form-error">{errors.city}</span>}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="ownerState">
            State
          </label>
          <input
            id="ownerState"
            name="state"
            type="text"
            className="form-input"
            placeholder="e.g. Andhra Pradesh"
            value={formData.state}
            onChange={handleChange}
            disabled={isLoading}
          />
        </div>
      </div>

      {/* Identity & Legal Information */}
      <div style={{ backgroundColor: '#fff', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)', padding: '1rem', marginBottom: '1.25rem' }}>
        <div style={{ fontSize: '0.85rem', fontWeight: '700', color: 'var(--text-main)', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <FileCheck size={16} style={{ color: 'var(--primary)' }} />
          Owner Verification & Government Identity Records
        </div>

        <div className="form-grid-2">
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" htmlFor="drivingLicenceNumber">
              Driving Licence Number <span className="required">*</span>
            </label>
            <input
              id="drivingLicenceNumber"
              name="drivingLicenceNumber"
              type="text"
              className={`form-input ${errors.drivingLicenceNumber ? 'is-invalid' : ''}`}
              placeholder="e.g. AP3720150001234"
              value={formData.drivingLicenceNumber}
              onChange={handleChange}
              disabled={isLoading}
              style={{ textTransform: 'uppercase' }}
            />
            {errors.drivingLicenceNumber && (
              <span className="form-error">{errors.drivingLicenceNumber}</span>
            )}
          </div>

          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label" htmlFor="governmentIdNumber">
              Government ID Number (Aadhaar / PAN) <span className="required">*</span>
            </label>
            <input
              id="governmentIdNumber"
              name="governmentIdNumber"
              type="text"
              className={`form-input ${errors.governmentIdNumber ? 'is-invalid' : ''}`}
              placeholder="e.g. AADHAAR-8921-4321-7789"
              value={formData.governmentIdNumber}
              onChange={handleChange}
              disabled={isLoading}
              style={{ textTransform: 'uppercase' }}
            />
            {errors.governmentIdNumber && (
              <span className="form-error">{errors.governmentIdNumber}</span>
            )}
          </div>
        </div>
      </div>

      {/* Verification & Account Status (Admin Controls) */}
      {isAdmin && (
        <div className="form-grid-2">
          <div className="form-group">
            <label className="form-label" htmlFor="verificationStatus">
              Verification Status
            </label>
            <select
              id="verificationStatus"
              name="verificationStatus"
              className="form-select"
              value={formData.verificationStatus}
              onChange={handleChange}
              disabled={isLoading}
            >
              <option value="Pending">Pending Review</option>
              <option value="Verified">Verified (Approved)</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="accountStatus">
              Account Status
            </label>
            <select
              id="accountStatus"
              name="accountStatus"
              className="form-select"
              value={formData.accountStatus}
              onChange={handleChange}
              disabled={isLoading}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive / Suspended</option>
            </select>
          </div>
        </div>
      )}

      {/* Bio / Fleet Notes */}
      <div className="form-group" style={{ marginBottom: '1.25rem' }}>
        <label className="form-label" htmlFor="bio">
          Owner Bio & Description
        </label>
        <textarea
          id="bio"
          name="bio"
          rows="2"
          className="form-textarea"
          placeholder="Brief background about fleet management experience, vehicle standards, or services offered."
          value={formData.bio}
          onChange={handleChange}
          disabled={isLoading}
        />
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', borderTop: '1px solid var(--border-color)', paddingTop: '1.25rem' }}>
        {onCancel && (
          <button
            type="button"
            className="btn btn-secondary"
            onClick={onCancel}
            disabled={isLoading}
          >
            <X size={16} /> Cancel
          </button>
        )}
        <button
          type="submit"
          className="btn btn-primary"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <span className="spinner" style={{ width: '14px', height: '14px', borderWidth: '2px' }}></span>
              Saving Owner...
            </>
          ) : (
            <>
              <Save size={16} /> {initialData ? 'Update Owner Profile' : 'Register Vehicle Owner'}
            </>
          )}
        </button>
      </div>
    </form>
  );
}
