import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { vehicleApi, customerApi, rentalApi, ownerApi, smsApi } from '../services/api';
import RentalForm from '../components/RentalForm';
import OwnerForm from '../components/OwnerForm';
import { LoadingSpinner, ErrorBanner } from '../components/LoadingState';
import PhonePePaymentModal from '../components/PhonePePaymentModal';
import {
  CalendarCheck,
  ArrowLeft,
  CheckCircle2,
  UserPlus,
  Car,
  MapPin,
  Smartphone,
  Sparkles,
  Building,
  ShieldCheck,
  Check,
  X,
  Clock,
  Users,
  MessageSquare,
  AlertCircle,
  Info,
  Send,
} from 'lucide-react';

export default function BookVehicle() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const preselectedVehicleId = searchParams.get('vehicleId');
  const preselectedStartDate = searchParams.get('startDate');
  const preselectedEndDate = searchParams.get('endDate');

  const [vehicles, setVehicles] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [rentals, setRentals] = useState([]);
  const [owners, setOwners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [pendingPayload, setPendingPayload] = useState(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isOwnerModalOpen, setIsOwnerModalOpen] = useState(false);
  const [ownerRegisterSuccess, setOwnerRegisterSuccess] = useState(null);
  const [successData, setSuccessData] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [vData, cData, rData, oData] = await Promise.all([
        vehicleApi.getAll(),
        customerApi.getAll(),
        rentalApi.getAll(),
        ownerApi.getAll(),
      ]);
      setVehicles(vData || []);
      setCustomers(cData || []);
      setRentals(rData || []);
      setOwners(oData || []);
    } catch (err) {
      setError(err.message || 'Failed to initialize booking system.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleRegisterOwner = async (ownerFormData) => {
    setIsSubmitting(true);
    try {
      const createdOwner = await ownerApi.create({
        ...ownerFormData,
        city: ownerFormData.city || 'Tadepalligudem',
        state: ownerFormData.state || 'Andhra Pradesh',
        registrationDate: new Date().toISOString(),
        verificationStatus: 'Verified',
        accountStatus: 'Active',
      });
      setOwners((prev) => [...prev, createdOwner]);
      setIsOwnerModalOpen(false);
      setOwnerRegisterSuccess(
        `Vehicle Owner "${createdOwner.name}" successfully registered! You can now list cars & bikes in the Owner Dashboard.`
      );
      setTimeout(() => setOwnerRegisterSuccess(null), 6000);
    } catch (err) {
      alert(`Owner registration failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleBookingSubmit = (rentalPayload) => {
    setPendingPayload(rentalPayload);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentSuccess = async (paymentDetails) => {
    if (!pendingPayload) return;
    setIsSubmitting(true);
    try {
      let finalCustomerId = pendingPayload.customerId;
      const cleanName = (pendingPayload.customerName || '').trim();
      const existingCust = customers.find(
        (c) =>
          c.name?.toLowerCase() === cleanName.toLowerCase() ||
          (pendingPayload.customerPhone && c.phone === pendingPayload.customerPhone.trim())
      );

      if (existingCust) {
        finalCustomerId = String(existingCust.id);
      } else if (cleanName) {
        try {
          const newCust = await customerApi.create({
            name: cleanName,
            phone: pendingPayload.customerPhone || '9876543210',
            email: `${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '')}@gmail.com`,
            city: 'Tadepalligudem',
            address: 'Tadepalligudem, AP',
            drivingLicenceNumber: `AP${Math.floor(100000 + Math.random() * 900000)}`,
            createdAt: new Date().toISOString(),
          });
          finalCustomerId = String(newCust.id);
          setCustomers((prev) => [...prev, newCust]);
        } catch (custErr) {
          console.warn('Customer auto-create note:', custErr);
          finalCustomerId = String(Date.now());
        }
      }

      const vehicle = vehicles.find((v) => String(v.id) === String(pendingPayload.vehicleId));
      const targetOwnerId = String(vehicle?.ownerId || pendingPayload.ownerId || '1');
      const uniqueBookingId = `BK-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;

      const fullPayload = {
        ...pendingPayload,
        bookingId: uniqueBookingId,
        customerId: finalCustomerId || '1',
        customerName: cleanName,
        customerPhone: pendingPayload.customerPhone || '',
        ownerId: targetOwnerId,
        paymentMethod: paymentDetails.paymentMethod,
        paymentNumber: paymentDetails.paymentNumber || '9492343566',
        upiId: paymentDetails.upiId || '9492343566@ybl',
        transactionId: paymentDetails.transactionId,
        paymentStatus: paymentDetails.paymentStatus,
        bookingStatus: 'Pending',
        status: 'Pending',
        createdAt: new Date().toISOString(),
      };

      const createdRental = await rentalApi.create(fullPayload);

      // Trigger automatic SMS notification via genuine backend provider
      let smsResult = null;
      try {
        smsResult = await smsApi.send({
          bookingId: uniqueBookingId,
          rentalId: createdRental.id,
          customerName: cleanName,
          customerPhone: pendingPayload.customerPhone,
          vehicleName: vehicle?.name || 'Selected Vehicle',
          startDate: pendingPayload.startDate,
          endDate: pendingPayload.endDate,
          totalAmount: pendingPayload.totalAmount,
          event: 'BOOKING_CREATED',
          businessName: 'DriveEase Tadepalligudem',
        });
      } catch (smsErr) {
        console.warn('SMS dispatch error:', smsErr);
        smsResult = {
          success: false,
          status: 'UNAVAILABLE',
          error: smsErr.message || 'SMS service unavailable',
          message: null,
        };
      }

      setSuccessData({
        ...createdRental,
        bookingId: uniqueBookingId,
        vehicleName: vehicle?.name,
        smsResult,
      });
      setIsPaymentModalOpen(false);
    } catch (err) {
      alert(`Booking failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getOwner = (id) => owners.find((o) => String(o.id) === String(id));

  if (loading) {
    return <LoadingSpinner message="Preparing reservation console..." />;
  }

  if (error) {
    return <ErrorBanner message={error} onRetry={fetchData} />;
  }

  if (successData) {
    const assignedOwner = getOwner(successData.ownerId);

    return (
      <div style={{ maxWidth: '640px', margin: '2rem auto' }}>
        <div className="card" style={{ textAlign: 'center', padding: '2.5rem 1.5rem' }}>
          <div
            style={{
              width: '64px',
              height: '64px',
              borderRadius: '50%',
              backgroundColor: 'var(--success-bg)',
              color: 'var(--success)',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: '1rem',
            }}
          >
            <CheckCircle2 size={36} />
          </div>
          <h2 style={{ fontSize: '1.4rem', fontWeight: '700', marginBottom: '0.4rem' }}>
            Reservation Request Submitted!
          </h2>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', marginBottom: '1.25rem' }}>
            <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>Booking ID:</span>
            <span
              style={{
                fontFamily: 'monospace',
                fontWeight: '700',
                fontSize: '1rem',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                color: 'var(--primary)',
                padding: '0.2rem 0.6rem',
                borderRadius: 'var(--radius-sm)',
                border: '1px solid rgba(37, 99, 235, 0.25)',
              }}
            >
              {successData.bookingId || `BK-2026-${successData.id}`}
            </span>
          </div>

          {/* Genuine SMS Notification System Status Box */}
          {successData.smsResult && successData.smsResult.status === 'SENT' && (
            <div
              style={{
                backgroundColor: 'rgba(34, 197, 94, 0.08)',
                border: '1px solid var(--success)',
                borderRadius: 'var(--radius-md)',
                padding: '1rem',
                marginBottom: '1.5rem',
                textAlign: 'left',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
                <strong style={{ color: 'var(--success)', display: 'inline-flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.9rem' }}>
                  <CheckCircle2 size={16} /> SMS Notification Sent Successfully
                </strong>
                <span className="badge badge-success" style={{ fontSize: '0.72rem' }}>
                  {successData.smsResult.provider}
                </span>
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-main)', margin: '0 0 0.5rem 0' }}>
                Live SMS notification was successfully dispatched to <strong>{successData.smsResult.recipient}</strong>.
                {successData.smsResult.providerMessageId && (
                  <span style={{ display: 'block', fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.15rem' }}>
                    Provider Ref ID: <code>{successData.smsResult.providerMessageId}</code>
                  </span>
                )}
              </p>
              <div
                style={{
                  backgroundColor: 'var(--card-bg)',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-sm)',
                  padding: '0.6rem 0.75rem',
                  fontSize: '0.78rem',
                  fontFamily: 'monospace',
                  whiteSpace: 'pre-wrap',
                  lineHeight: '1.4',
                  color: 'var(--text-main)',
                }}
              >
                {successData.smsResult.message}
              </div>
            </div>
          )}

          {successData.smsResult && successData.smsResult.status === 'UNAVAILABLE' && (
            <div
              style={{
                backgroundColor: 'rgba(234, 179, 8, 0.08)',
                border: '1px solid #eab308',
                borderRadius: 'var(--radius-md)',
                padding: '1rem',
                marginBottom: '1.5rem',
                textAlign: 'left',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#b45309', fontWeight: '700', fontSize: '0.9rem', marginBottom: '0.35rem' }}>
                <Info size={16} /> SMS Gateway Notice: Service Unavailable
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-main)', margin: '0 0 0.5rem 0' }}>
                Your booking is safely registered in the database with ID <strong>{successData.bookingId || successData.id}</strong>. Live SMS notification was not dispatched because SMS gateway credentials (Twilio, 2Factor, or MSG91) are not configured in the backend <code>.env</code> file.
              </p>
              <details style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                <summary style={{ cursor: 'pointer', fontWeight: '600' }}>View prepared SMS message</summary>
                <div
                  style={{
                    marginTop: '0.4rem',
                    backgroundColor: 'var(--card-bg)',
                    border: '1px solid var(--border-color)',
                    borderRadius: 'var(--radius-sm)',
                    padding: '0.6rem 0.75rem',
                    fontFamily: 'monospace',
                    whiteSpace: 'pre-wrap',
                    lineHeight: '1.4',
                    color: 'var(--text-main)',
                  }}
                >
                  {successData.smsResult.message || `Hello ${successData.customerName || 'Customer'}! Your car booking request has been received successfully.\n\nBooking ID: ${successData.bookingId || successData.id}\nCar: ${successData.vehicleName || 'Vehicle'}\nPickup Date: ${successData.startDate}\nReturn Date: ${successData.endDate}\nTotal Amount: ₹${successData.totalAmount}\n\nBooking Status: Pending Approval.\n\nThank you for choosing DriveEase Tadepalligudem!`}
                </div>
              </details>
            </div>
          )}

          {successData.smsResult && (successData.smsResult.status === 'FAILED' || successData.smsResult.status === 'INVALID_NUMBER') && (
            <div
              style={{
                backgroundColor: 'rgba(239, 68, 68, 0.08)',
                border: '1px solid var(--danger)',
                borderRadius: 'var(--radius-md)',
                padding: '1rem',
                marginBottom: '1.5rem',
                textAlign: 'left',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: 'var(--danger)', fontWeight: '700', fontSize: '0.9rem', marginBottom: '0.35rem' }}>
                <AlertCircle size={16} /> SMS Notification Status: Delivery Issue
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-main)', margin: 0 }}>
                {successData.smsResult.error || 'SMS delivery failed. Your reservation has been recorded safely in the database.'}
              </p>
            </div>
          )}

          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '1.5rem' }}>
            Submitted with PhonePe payment for host verification and vehicle preparation.
          </p>

          <div
            style={{
              backgroundColor: 'var(--bg-subtle)',
              borderRadius: 'var(--radius-md)',
              padding: '1.25rem',
              textAlign: 'left',
              marginBottom: '1.75rem',
              fontSize: '0.88rem',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span>Booking Status:</span>
              <span className="badge badge-warning" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
                <Clock size={12} /> Pending Owner Approval
              </span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span>Vehicle Host / Owner:</span>
              <strong style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem' }}>
                <ShieldCheck size={14} style={{ color: 'var(--success)' }} />
                {assignedOwner ? assignedOwner.name : 'Verified Owner'}
              </strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span>Customer Name:</span>
              <strong>{successData.customerName || 'Customer'}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span>Duration:</span>
              <strong>{successData.days} days</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span>Rental Location:</span>
              <strong style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', color: 'var(--primary)' }}>
                <MapPin size={14} /> {successData.location || 'ATV Tadepalligudem'}
              </strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span>Payment Method:</span>
              <strong style={{ color: '#5f259f' }}>{successData.paymentMethod || 'PhonePe UPI'}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span>PhonePe Account:</span>
              <strong>9492343566</strong>
            </div>
            {successData.transactionId && (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
                <span>Transaction Ref / UTR:</span>
                <span style={{ fontFamily: 'monospace', fontWeight: '600', color: 'var(--primary)' }}>
                  {successData.transactionId}
                </span>
              </div>
            )}
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span>Rental Period:</span>
              <strong>{successData.startDate} to {successData.endDate}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span>Daily Rate:</span>
              <span>₹{Number(successData.dailyPrice).toLocaleString('en-IN')} / day</span>
            </div>
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                paddingTop: '0.5rem',
                borderTop: '1px dashed var(--border-color)',
                fontSize: '1.05rem',
                fontWeight: '700',
                color: 'var(--primary)',
              }}
            >
              <span>Total Amount:</span>
              <span>₹{Number(successData.totalAmount).toLocaleString('en-IN')}</span>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
              <button
                className="btn btn-primary"
                onClick={() => navigate('/owner-dashboard')}
                title="Go to Owner Dashboard to view & approve this reservation"
              >
                <Building size={15} /> Open Owner Dashboard (Approve Request)
              </button>
              <button
                className="btn btn-secondary"
                onClick={() => navigate('/rentals')}
              >
                View in Rental History
              </button>
            </div>
            <button
              className="btn btn-outline btn-sm"
              style={{ margin: '0.5rem auto 0 auto' }}
              onClick={() => {
                setSuccessData(null);
                fetchData();
              }}
            >
              Book Another Vehicle
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '820px', margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '0.75rem' }}>
        <Link to="/vehicles" className="btn btn-secondary btn-sm">
          <ArrowLeft size={14} /> Back to Vehicles
        </Link>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button
            type="button"
            className="btn btn-outline btn-sm"
            onClick={() => setIsOwnerModalOpen(true)}
            style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: 'var(--primary)', borderColor: 'var(--primary)' }}
          >
            <UserPlus size={14} /> Register as Vehicle Owner
          </button>
          <Link to="/owner-dashboard" className="btn btn-secondary btn-sm" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem' }}>
            <Car size={14} /> Owner Portal
          </Link>
        </div>
      </div>

      {ownerRegisterSuccess && (
        <div className="alert alert-success" style={{ marginBottom: '1.25rem' }}>
          <CheckCircle2 size={18} />
          <span>{ownerRegisterSuccess}</span>
        </div>
      )}

      {/* Multi-Owner Vehicle Marketplace & Host Registration Header */}
      <div
        className="card"
        style={{
          background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
          color: '#ffffff',
          padding: '1.5rem',
          marginBottom: '1.5rem',
          borderRadius: 'var(--radius-lg)',
          border: '1px solid rgba(255,255,255,0.1)',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div style={{ maxWidth: '580px' }}>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.4rem',
                backgroundColor: 'rgba(59, 130, 246, 0.2)',
                color: '#60a5fa',
                padding: '0.2rem 0.6rem',
                borderRadius: '100px',
                fontSize: '0.75rem',
                fontWeight: '700',
                marginBottom: '0.5rem',
                border: '1px solid rgba(59, 130, 246, 0.3)',
              }}
            >
              <Sparkles size={12} /> Multi-Owner Vehicle Rental Marketplace
            </div>
            <h2 style={{ fontSize: '1.25rem', fontWeight: '800', color: '#ffffff', marginBottom: '0.35rem' }}>
              Vehicle Owner Registration & Multi-Owner Marketplace
            </h2>
            <p style={{ fontSize: '0.85rem', color: '#94a3b8', lineHeight: 1.5, margin: 0 }}>
              Rent cars and bikes listed by verified independent vehicle owners at <strong>ATV Tadepalligudem</strong>. Every booking request is verified and approved directly by the vehicle owner.
            </p>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            <button
              type="button"
              className="btn btn-primary btn-sm"
              onClick={() => setIsOwnerModalOpen(true)}
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', whiteSpace: 'nowrap' }}
            >
              <UserPlus size={14} /> Register as Vehicle Owner
            </button>
            <Link
              to="/owner-dashboard"
              className="btn btn-secondary btn-sm"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', justifyContent: 'center', whiteSpace: 'nowrap' }}
            >
              <Building size={14} /> Manage Owner Fleet
            </Link>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div className="stat-icon blue" style={{ width: '38px', height: '38px' }}>
              <CalendarCheck size={18} />
            </div>
            <div>
              <div className="card-title">Book a Vehicle</div>
              <div className="card-subtitle">
                Exclusive rental hub: <strong>ATV Tadepalligudem</strong> • Instant fee calculation & owner approval
              </div>
            </div>
          </div>
        </div>

        <div className="card-body">
          <RentalForm
            vehicles={vehicles}
            customers={customers}
            rentals={rentals}
            owners={owners}
            preselectedVehicleId={preselectedVehicleId}
            preselectedStartDate={preselectedStartDate}
            preselectedEndDate={preselectedEndDate}
            onSubmit={handleBookingSubmit}
            onCancel={() => navigate('/rentals')}
            isLoading={isSubmitting}
          />
        </div>
      </div>

      {/* PhonePe UPI QR Payment Modal */}
      <PhonePePaymentModal
        isOpen={isPaymentModalOpen}
        amount={pendingPayload?.totalAmount || 0}
        vehicleName={
          vehicles.find((v) => String(v.id) === String(pendingPayload?.vehicleId))?.name ||
          'Rental Vehicle'
        }
        rentalDays={pendingPayload?.numberOfDays || pendingPayload?.days || 1}
        onPaymentSuccess={handlePaymentSuccess}
        onCancel={() => setIsPaymentModalOpen(false)}
        isProcessing={isSubmitting}
      />

      {/* Vehicle Owner Registration Modal */}
      {isOwnerModalOpen && (
        <div className="modal-overlay" role="dialog" aria-modal="true" style={{ zIndex: 110 }}>
          <div className="modal-content" style={{ maxWidth: '680px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <UserPlus size={20} style={{ color: 'var(--primary)' }} />
                <h3>Register as Vehicle Owner</h3>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setIsOwnerModalOpen(false)}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '1.25rem' }}>
                Join the DriveEase multi-owner rental network in <strong>Tadepalligudem</strong>. Register your profile to list your cars or bikes, receive booking requests, and earn rental income.
              </p>
              <OwnerForm
                onSubmit={handleRegisterOwner}
                onCancel={() => setIsOwnerModalOpen(false)}
                isLoading={isSubmitting}
                isAdmin={false}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
