import React, { useState, useEffect } from 'react';
import { Menu, Radio, MapPin, MessageSquare } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { smsApi } from '../services/api';

const PAGE_TITLES = {
  '/': { title: 'Find Your Perfect Car', desc: 'Choose your perfect ride for your next journey.' },
  '/marketplace': { title: 'Find Your Perfect Car', desc: 'Choose your perfect ride for your next journey.' },
  '/admin': { title: 'Admin Dashboard', desc: 'Real-time performance metrics and quick operations' },
  '/dashboard': { title: 'Admin Dashboard', desc: 'Real-time performance metrics and quick operations' },
  '/owners': { title: 'Vehicle Owner Management', desc: 'Manage host registrations, verifications, and fleet listings' },
  '/owner-dashboard': { title: 'Vehicle Owner Portal', desc: 'Host dashboard to manage your fleet, bookings, and earnings' },
  '/vehicles': { title: 'Fleet Inventory', desc: 'Manage vehicle inventory, pricing, and availability' },
  '/customers': { title: 'Customer Directory', desc: 'View, register, and update customer profiles' },
  '/book': { title: 'Book a Vehicle', desc: 'Create vehicle reservation with automatic fee calculation' },
  '/rentals': { title: 'Rental Transaction History', desc: 'Manage reservations, statuses, and return processing' },
};

export default function Header({ onToggleMobile }) {
  const location = useLocation();
  const currentPath = location.pathname;
  const [smsStatus, setSmsStatus] = useState(null);

  useEffect(() => {
    smsApi.getStatus()
      .then(setSmsStatus)
      .catch(() => setSmsStatus({ configured: false, provider: 'Gateway Ready' }));
  }, [location.pathname]);

  // Match title or provide fallback for edit screens
  let titleInfo = PAGE_TITLES[currentPath];
  if (!titleInfo) {
    if (currentPath.startsWith('/vehicles/view')) {
      titleInfo = { title: 'Vehicle Specifications', desc: 'Complete gallery, owner verification, and instant booking' };
    } else if (currentPath.startsWith('/vehicles/edit')) {
      titleInfo = { title: 'Edit Vehicle', desc: 'Update vehicle specifications and availability' };
    } else if (currentPath.startsWith('/customers/edit')) {
      titleInfo = { title: 'Edit Customer', desc: 'Update customer contact and license information' };
    } else if (currentPath.startsWith('/rentals/edit')) {
      titleInfo = { title: 'Edit Rental Record', desc: 'Update rental dates and booking details' };
    } else {
      titleInfo = { title: 'Vehicle Rental Marketplace', desc: 'Multi-owner vehicle fleet platform' };
    }
  }

  return (
    <header className="header">
      <div className="header-left">
        <button
          className="mobile-toggle"
          onClick={onToggleMobile}
          aria-label="Open Navigation Menu"
        >
          <Menu size={22} />
        </button>
        <div className="header-title-container">
          <h1>{titleInfo.title}</h1>
          <p>{titleInfo.desc}</p>
        </div>
      </div>

      <div className="header-right">
        <div
          className="header-status-badge"
          style={{
            backgroundColor: 'var(--primary-light)',
            color: 'var(--primary)',
            borderColor: 'var(--primary-border)',
            gap: '0.35rem',
          }}
          title="Exclusive Rental Service Hub"
        >
          <MapPin size={13} />
          <span>Hub: ATV Tadepalligudem</span>
        </div>
        <div className="header-status-badge">
          <span className="status-dot"></span>
          <span>API Server :3000</span>
        </div>
        <div
          className="header-status-badge"
          title={smsStatus?.instructions || 'SMS Notification Gateway via Backend (.env)'}
          style={{
            borderColor: smsStatus?.configured ? 'rgba(34, 197, 94, 0.4)' : 'var(--border-color)',
            color: smsStatus?.configured ? 'var(--success)' : 'var(--text-muted)',
            backgroundColor: smsStatus?.configured ? 'rgba(34, 197, 94, 0.08)' : 'transparent',
          }}
        >
          <MessageSquare size={12} />
          <span>SMS: {smsStatus?.configured ? `${smsStatus.provider} Active` : 'Gateway Ready (.env)'}</span>
        </div>
      </div>
    </header>
  );
}
