import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { ownerApi, vehicleApi, rentalApi } from '../services/api';
import OwnerForm from '../components/OwnerForm';
import ConfirmDialog from '../components/ConfirmDialog';
import { LoadingSpinner, ErrorBanner, EmptyState } from '../components/LoadingState';
import {
  Users,
  UserPlus,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Car,
  Bike,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  Edit2,
  Trash2,
  Eye,
  ShieldCheck,
  ShieldAlert,
  IndianRupee,
  X,
  Check,
  Building,
  Calendar,
  AlertTriangle,
} from 'lucide-react';

export default function Owners() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const [owners, setOwners] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All'); // All | Pending | Verified | Rejected
  const [accountFilter, setAccountFilter] = useState('All'); // All | Active | Inactive

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingOwner, setEditingOwner] = useState(null);
  const [viewingOwner, setViewingOwner] = useState(null);
  const [ownerToDelete, setOwnerToDelete] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showGovernmentId, setShowGovernmentId] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [oData, vData, rData] = await Promise.all([
        ownerApi.getAll(),
        vehicleApi.getAll(),
        rentalApi.getAll(),
      ]);
      setOwners(oData || []);
      setVehicles(vData || []);
      setRentals(rData || []);
    } catch (err) {
      setError(err.message || 'Failed to fetch vehicle owners.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Check URL action
  useEffect(() => {
    if (searchParams.get('action') === 'add') {
      setIsAddModalOpen(true);
      searchParams.delete('action');
      setSearchParams(searchParams, { replace: true });
    }
  }, [searchParams]);

  // Handle Register
  const handleRegisterOwner = async (formData) => {
    setIsSubmitting(true);
    try {
      const created = await ownerApi.create(formData);
      setOwners((prev) => [...prev, created]);
      setIsAddModalOpen(false);
      setSuccessMessage(`Vehicle owner "${created.name}" registered successfully.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      alert(`Registration failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Edit
  const handleUpdateOwner = async (formData) => {
    if (!editingOwner) return;
    setIsSubmitting(true);
    try {
      const updated = await ownerApi.update(editingOwner.id, formData);
      setOwners((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
      setEditingOwner(null);
      if (viewingOwner && viewingOwner.id === updated.id) {
        setViewingOwner(updated);
      }
      setSuccessMessage(`Owner profile for "${updated.name}" updated successfully.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      alert(`Update failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Quick Verification Toggle (Verify / Reject)
  const handleVerificationStatusChange = async (owner, newStatus) => {
    try {
      const updated = await ownerApi.update(owner.id, {
        ...owner,
        verificationStatus: newStatus,
      });
      setOwners((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
      if (viewingOwner && viewingOwner.id === owner.id) {
        setViewingOwner(updated);
      }
      setSuccessMessage(`Owner "${owner.name}" verification status set to ${newStatus}.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      alert(`Status update failed: ${err.message}`);
    }
  };

  // Quick Account Toggle (Active / Inactive)
  const handleToggleAccountStatus = async (owner) => {
    const nextStatus = owner.accountStatus === 'Active' ? 'Inactive' : 'Active';
    try {
      const updated = await ownerApi.update(owner.id, {
        ...owner,
        accountStatus: nextStatus,
      });
      setOwners((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
      if (viewingOwner && viewingOwner.id === owner.id) {
        setViewingOwner(updated);
      }
      setSuccessMessage(`Owner "${owner.name}" account marked ${nextStatus}.`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err) {
      alert(`Account status toggle failed: ${err.message}`);
    }
  };

  // Delete Confirmation
  const handleDeleteOwner = async () => {
    if (!ownerToDelete) return;
    setIsSubmitting(true);
    try {
      await ownerApi.delete(ownerToDelete.id);
      setOwners((prev) => prev.filter((o) => o.id !== ownerToDelete.id));
      setSuccessMessage(`Owner "${ownerToDelete.name}" permanently removed.`);
      setTimeout(() => setSuccessMessage(null), 4000);
      setOwnerToDelete(null);
      if (viewingOwner && viewingOwner.id === ownerToDelete.id) {
        setViewingOwner(null);
      }
    } catch (err) {
      alert(`Deletion failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Helper Stats per Owner
  const getOwnerVehicles = (ownerId) =>
    vehicles.filter((v) => String(v.ownerId) === String(ownerId));

  const getOwnerRentals = (ownerId) =>
    rentals.filter((r) => String(r.ownerId) === String(ownerId));

  const getOwnerEarnings = (ownerId) => {
    const ownerRentalsList = getOwnerRentals(ownerId);
    return ownerRentalsList
      .filter((r) => {
        const s = (r.bookingStatus || r.status || '').toLowerCase();
        return s === 'completed' || s === 'approved' || s === 'ongoing';
      })
      .reduce((sum, r) => sum + Number(r.totalAmount || 0), 0);
  };

  // Filter Owners
  const filteredOwners = owners.filter((owner) => {
    const query = searchQuery.trim().toLowerCase();
    if (query) {
      const matchesName = (owner.name || '').toLowerCase().includes(query);
      const matchesPhone = (owner.phone || '').toLowerCase().includes(query);
      const matchesCity = (owner.city || '').toLowerCase().includes(query);
      const matchesEmail = (owner.email || '').toLowerCase().includes(query);
      if (!matchesName && !matchesPhone && !matchesCity && !matchesEmail) {
        return false;
      }
    }

    if (statusFilter !== 'All') {
      if ((owner.verificationStatus || '').toLowerCase() !== statusFilter.toLowerCase()) {
        return false;
      }
    }

    if (accountFilter !== 'All') {
      if ((owner.accountStatus || 'Active').toLowerCase() !== accountFilter.toLowerCase()) {
        return false;
      }
    }

    return true;
  });

  // Overall Owner Metrics
  const totalOwners = owners.length;
  const verifiedCount = owners.filter((o) => o.verificationStatus === 'Verified').length;
  const pendingCount = owners.filter((o) => o.verificationStatus === 'Pending').length;
  const totalVehiclesListed = vehicles.length;
  const totalMarketplaceEarnings = rentals
    .filter((r) => {
      const s = (r.bookingStatus || r.status || '').toLowerCase();
      return s === 'completed' || s === 'approved' || s === 'ongoing';
    })
    .reduce((sum, r) => sum + Number(r.totalAmount || 0), 0);

  if (loading) {
    return <LoadingSpinner message="Loading registered vehicle owners..." />;
  }

  return (
    <div>
      {error && <ErrorBanner message={error} onRetry={fetchData} />}

      {successMessage && (
        <div className="alert alert-success">
          <Check size={18} />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Website Owners & Founders Header */}
      <div
        style={{
          background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
          color: '#ffffff',
          padding: '1.25rem 1.5rem',
          borderRadius: 'var(--radius-lg)',
          marginBottom: '1.5rem',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '1rem',
        }}
      >
        <div>
          <div style={{ fontSize: '0.78rem', color: '#93c5fd', fontWeight: '700', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.25rem' }}>
            DriveEase • ATV Tadepalligudem
          </div>
          <h2 style={{ fontSize: '1.35rem', fontWeight: '800', color: '#ffffff', margin: '0 0 0.35rem 0' }}>
            Rental Website Owners & Host Management
          </h2>
          <div style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>
            Founders & Platform Owners: <strong>Rayudi Rekha</strong> • <strong>Kumpatla Reethuka</strong> • <strong>Shaik Najirin</strong> • <strong>Sivadalla Praveen</strong>
          </div>
        </div>

        <button
          className="btn btn-primary btn-sm"
          onClick={() => setIsAddModalOpen(true)}
          style={{ whiteSpace: 'nowrap' }}
        >
          <UserPlus size={15} /> Register New Owner
        </button>
      </div>

      {/* Top Banner KPI Cards */}
      <div className="stats-grid" style={{ marginBottom: '1.5rem' }}>
        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Vehicle Owners</span>
            <span className="stat-value">{totalOwners}</span>
            <span className="stat-subtext">Registered host partners</span>
          </div>
          <div className="stat-icon blue">
            <Users size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Verified Owners</span>
            <span className="stat-value" style={{ color: 'var(--success)' }}>
              {verifiedCount}
            </span>
            <span className="stat-subtext">Active on marketplace</span>
          </div>
          <div className="stat-icon green">
            <CheckCircle2 size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Pending Verification</span>
            <span className="stat-value" style={{ color: pendingCount > 0 ? 'var(--warning)' : 'var(--text-muted)' }}>
              {pendingCount}
            </span>
            <span className="stat-subtext">Awaiting admin review</span>
          </div>
          <div className="stat-icon amber">
            <Clock size={22} />
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-info">
            <span className="stat-label">Total Owner Earnings</span>
            <span className="stat-value" style={{ color: 'var(--primary)' }}>
              ₹{totalMarketplaceEarnings.toLocaleString('en-IN')}
            </span>
            <span className="stat-subtext">Across {totalVehiclesListed} listed vehicles</span>
          </div>
          <div className="stat-icon blue">
            <IndianRupee size={22} />
          </div>
        </div>
      </div>

      {/* Action and Filter Controls Bar */}
      <div className="controls-bar">
        <div className="search-input-group">
          <Search size={18} />
          <input
            type="text"
            className="form-input"
            placeholder="Search owners by name, phone, email, or city..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="filter-group">
          {/* Verification Status Filter */}
          <select
            className="form-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ width: 'auto' }}
          >
            <option value="All">All Verification Statuses</option>
            <option value="Verified">Verified Only</option>
            <option value="Pending">Pending Review</option>
            <option value="Rejected">Rejected</option>
          </select>

          {/* Account Status Filter */}
          <select
            className="form-select"
            value={accountFilter}
            onChange={(e) => setAccountFilter(e.target.value)}
            style={{ width: 'auto' }}
          >
            <option value="All">All Accounts</option>
            <option value="Active">Active Accounts</option>
            <option value="Inactive">Inactive / Suspended</option>
          </select>

          <button
            className="btn btn-primary"
            onClick={() => setIsAddModalOpen(true)}
          >
            <UserPlus size={16} /> Register New Owner
          </button>
        </div>
      </div>

      {/* Owners Table */}
      {filteredOwners.length === 0 ? (
        <EmptyState
          title="No vehicle owners found"
          description="Try clearing your search query or registering a new vehicle owner to the platform."
          action={
            <button className="btn btn-primary" onClick={() => setIsAddModalOpen(true)}>
              <UserPlus size={16} /> Register First Owner
            </button>
          }
        />
      ) : (
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Owner Details</th>
                <th>Contact</th>
                <th>Location</th>
                <th>Verification</th>
                <th>Listed Fleet</th>
                <th>Total Earnings</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredOwners.map((owner) => {
                const ownerVehicles = getOwnerVehicles(owner.id);
                const ownerEarnings = getOwnerEarnings(owner.id);
                const isVerified = owner.verificationStatus === 'Verified';
                const isPending = owner.verificationStatus === 'Pending';
                const isRejected = owner.verificationStatus === 'Rejected';

                return (
                  <tr key={owner.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                        <img
                          src={
                            owner.avatar ||
                            'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
                          }
                          alt={owner.name}
                          style={{
                            width: '44px',
                            height: '44px',
                            borderRadius: '50%',
                            objectFit: 'cover',
                            border: '2px solid var(--border-color)',
                          }}
                        />
                        <div>
                          <div style={{ fontWeight: '700', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                            {owner.name}
                            {isVerified && (
                              <CheckCircle2 size={15} style={{ color: 'var(--success)' }} title="Verified Owner" />
                            )}
                          </div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                            ID: #{owner.id} • Registered {owner.registrationDate || '2026'}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.2rem', fontSize: '0.82rem' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                          <Phone size={13} style={{ color: 'var(--text-light)' }} /> {owner.phone}
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                          <Mail size={13} style={{ color: 'var(--text-light)' }} /> {owner.email}
                        </span>
                      </div>
                    </td>

                    <td>
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: 'var(--text-muted)', fontSize: '0.84rem' }}>
                        <MapPin size={13} style={{ color: 'var(--primary)' }} />
                        <strong>{owner.city || 'Tadepalligudem'}</strong>, {owner.state || 'AP'}
                      </span>
                    </td>

                    <td>
                      <span
                        className={`badge ${
                          isVerified
                            ? 'badge-available'
                            : isPending
                            ? 'badge-warning'
                            : 'badge-danger'
                        }`}
                        style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}
                      >
                        {isVerified && <CheckCircle2 size={12} />}
                        {isPending && <Clock size={12} />}
                        {isRejected && <XCircle size={12} />}
                        {owner.verificationStatus || 'Pending'}
                      </span>
                    </td>

                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <span className="badge badge-category" style={{ fontWeight: '600' }}>
                          {ownerVehicles.length} {ownerVehicles.length === 1 ? 'vehicle' : 'vehicles'}
                        </span>
                      </div>
                    </td>

                    <td>
                      <strong style={{ color: 'var(--success)', fontSize: '0.92rem' }}>
                        ₹{ownerEarnings.toLocaleString('en-IN')}
                      </strong>
                    </td>

                    <td>
                      <span
                        className={`badge ${
                          owner.accountStatus === 'Active' ? 'badge-available' : 'badge-unavailable'
                        }`}
                      >
                        {owner.accountStatus || 'Active'}
                      </span>
                    </td>

                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '0.4rem' }}>
                        {/* View Full Profile */}
                        <button
                          type="button"
                          className="btn btn-sm btn-secondary btn-icon"
                          onClick={() => {
                            setViewingOwner(owner);
                            setShowGovernmentId(false);
                          }}
                          title="View Owner Profile & Fleet"
                          aria-label="View Owner Profile"
                        >
                          <Eye size={15} />
                        </button>

                        {/* Quick Verify/Reject for Admin */}
                        {isPending && (
                          <button
                            type="button"
                            className="btn btn-sm btn-secondary btn-icon"
                            style={{ color: 'var(--success)' }}
                            onClick={() => handleVerificationStatusChange(owner, 'Verified')}
                            title="Verify Owner"
                            aria-label="Verify Owner"
                          >
                            <CheckCircle2 size={15} />
                          </button>
                        )}

                        {/* Edit Owner */}
                        <button
                          type="button"
                          className="btn btn-sm btn-secondary btn-icon"
                          onClick={() => setEditingOwner(owner)}
                          title="Edit Owner Details"
                          aria-label="Edit Owner"
                        >
                          <Edit2 size={15} />
                        </button>

                        {/* Delete Owner */}
                        <button
                          type="button"
                          className="btn btn-sm btn-danger-light btn-icon"
                          onClick={() => setOwnerToDelete(owner)}
                          title="Delete Owner"
                          aria-label="Delete Owner"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Register Owner Modal */}
      {isAddModalOpen && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-content" style={{ maxWidth: '680px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <UserPlus size={20} style={{ color: 'var(--primary)' }} />
                <h3>Register New Vehicle Owner</h3>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setIsAddModalOpen(false)}
                disabled={isSubmitting}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <OwnerForm
                onSubmit={handleRegisterOwner}
                onCancel={() => setIsAddModalOpen(false)}
                isLoading={isSubmitting}
                isAdmin={true}
              />
            </div>
          </div>
        </div>
      )}

      {/* Edit Owner Modal */}
      {editingOwner && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-content" style={{ maxWidth: '680px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Edit2 size={20} style={{ color: 'var(--primary)' }} />
                <h3>Edit Owner Profile: {editingOwner.name}</h3>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setEditingOwner(null)}
                disabled={isSubmitting}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <OwnerForm
                initialData={editingOwner}
                onSubmit={handleUpdateOwner}
                onCancel={() => setEditingOwner(null)}
                isLoading={isSubmitting}
                isAdmin={true}
              />
            </div>
          </div>
        </div>
      )}

      {/* View Owner Complete Profile & Fleet Modal */}
      {viewingOwner && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-content" style={{ maxWidth: '680px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <img
                  src={
                    viewingOwner.avatar ||
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
                  }
                  alt={viewingOwner.name}
                  style={{ width: '48px', height: '48px', borderRadius: '50%', objectFit: 'cover' }}
                />
                <div>
                  <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    {viewingOwner.name}
                    {viewingOwner.verificationStatus === 'Verified' && (
                      <CheckCircle2 size={18} style={{ color: 'var(--success)' }} />
                    )}
                  </h3>
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    Host Partner • ID #{viewingOwner.id} • Registered {viewingOwner.registrationDate || '2026'}
                  </div>
                </div>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setViewingOwner(null)}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>

            <div className="modal-body">
              {/* Quick Status Bar */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: 'var(--bg-subtle)', padding: '0.85rem 1rem', borderRadius: 'var(--radius-md)', marginBottom: '1.25rem' }}>
                <div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Verification Status: </span>
                  <strong style={{ color: viewingOwner.verificationStatus === 'Verified' ? 'var(--success)' : 'var(--warning)' }}>
                    {viewingOwner.verificationStatus || 'Pending'}
                  </strong>
                </div>

                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  {viewingOwner.verificationStatus !== 'Verified' && (
                    <button
                      className="btn btn-sm btn-primary"
                      onClick={() => handleVerificationStatusChange(viewingOwner, 'Verified')}
                    >
                      <Check size={14} /> Mark as Verified
                    </button>
                  )}
                  {viewingOwner.verificationStatus !== 'Rejected' && (
                    <button
                      className="btn btn-sm btn-secondary"
                      style={{ color: 'var(--danger)' }}
                      onClick={() => handleVerificationStatusChange(viewingOwner, 'Rejected')}
                    >
                      <X size={14} /> Reject
                    </button>
                  )}
                  <button
                    className="btn btn-sm btn-secondary"
                    onClick={() => handleToggleAccountStatus(viewingOwner)}
                  >
                    {viewingOwner.accountStatus === 'Active' ? 'Deactivate' : 'Activate'}
                  </button>
                </div>
              </div>

              {/* Bio */}
              {viewingOwner.bio && (
                <div style={{ marginBottom: '1.25rem', fontSize: '0.88rem', color: 'var(--text-main)', fontStyle: 'italic', backgroundColor: '#fcfcfc', borderLeft: '3px solid var(--primary)', padding: '0.6rem 0.85rem' }}>
                  "{viewingOwner.bio}"
                </div>
              )}

              {/* Contact and Legal Info */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', fontSize: '0.88rem', marginBottom: '1.5rem' }}>
                <div>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>Phone:</span>
                  <div><strong>{viewingOwner.phone}</strong></div>
                </div>
                <div>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>Email:</span>
                  <div><strong>{viewingOwner.email}</strong></div>
                </div>
                <div>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>Address:</span>
                  <div>{viewingOwner.address || '—'}</div>
                </div>
                <div>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>City / State:</span>
                  <div>{viewingOwner.city}, {viewingOwner.state}</div>
                </div>
                <div>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>Driving Licence:</span>
                  <div><span style={{ fontFamily: 'monospace', fontWeight: '600' }}>{viewingOwner.drivingLicenceNumber}</span></div>
                </div>
                <div>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>Government ID:</span>
                  <div>
                    {showGovernmentId ? (
                      <span style={{ fontFamily: 'monospace', fontWeight: '600', color: 'var(--primary)' }}>
                        {viewingOwner.governmentIdNumber}
                      </span>
                    ) : (
                      <span style={{ fontFamily: 'monospace', color: 'var(--text-muted)' }}>
                        ••••-••••-•••• (Protected)
                      </span>
                    )}
                    <button
                      type="button"
                      style={{ background: 'none', border: 'none', color: 'var(--primary)', cursor: 'pointer', fontSize: '0.75rem', marginLeft: '0.5rem', textDecoration: 'underline' }}
                      onClick={() => setShowGovernmentId(!showGovernmentId)}
                    >
                      {showGovernmentId ? 'Hide' : 'Reveal'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Owner's Listed Vehicles */}
              <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                  <h4 style={{ fontSize: '0.95rem', fontWeight: '700', color: 'var(--text-main)' }}>
                    Owner's Listed Fleet ({getOwnerVehicles(viewingOwner.id).length})
                  </h4>
                  <span style={{ fontSize: '0.8rem', color: 'var(--success)', fontWeight: '600' }}>
                    Total Earnings: ₹{getOwnerEarnings(viewingOwner.id).toLocaleString('en-IN')}
                  </span>
                </div>

                {getOwnerVehicles(viewingOwner.id).length === 0 ? (
                  <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                    This owner has not added any vehicles to the fleet yet.
                  </p>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {getOwnerVehicles(viewingOwner.id).map((v) => (
                      <div
                        key={v.id}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '0.65rem 0.85rem',
                          backgroundColor: 'var(--bg-subtle)',
                          borderRadius: 'var(--radius-sm)',
                          fontSize: '0.85rem',
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                          {v.type === 'Bike' ? (
                            <Bike size={16} style={{ color: 'var(--primary)' }} />
                          ) : (
                            <Car size={16} style={{ color: 'var(--primary)' }} />
                          )}
                          <div>
                            <strong>{v.name}</strong>
                            <span style={{ color: 'var(--text-muted)', marginLeft: '0.4rem', fontSize: '0.78rem' }}>
                              [{v.registrationNumber}] • {v.category}
                            </span>
                          </div>
                        </div>

                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                          <span style={{ fontWeight: '600', color: 'var(--text-main)' }}>
                            ₹{v.pricePerDay}/day
                          </span>
                          <span className={`badge ${v.available ? 'badge-available' : 'badge-unavailable'}`} style={{ fontSize: '0.72rem' }}>
                            {v.available ? 'Available' : 'Rented'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                onClick={() => setViewingOwner(null)}
              >
                Close
              </button>
              <button
                className="btn btn-primary"
                onClick={() => {
                  setEditingOwner(viewingOwner);
                  setViewingOwner(null);
                }}
              >
                <Edit2 size={14} /> Edit Profile
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={ownerToDelete !== null}
        title="Delete Vehicle Owner"
        message={`Are you sure you want to permanently delete owner "${ownerToDelete?.name}"? All associated fleet records should be reviewed first.`}
        confirmText="Yes, Delete Owner"
        cancelText="Cancel"
        isDanger={true}
        isLoading={isSubmitting}
        onConfirm={handleDeleteOwner}
        onCancel={() => setOwnerToDelete(null)}
      />
    </div>
  );
}
