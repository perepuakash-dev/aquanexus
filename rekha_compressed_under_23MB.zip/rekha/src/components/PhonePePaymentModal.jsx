import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  CheckCircle2,
  Copy,
  Check,
  ShieldCheck,
  Smartphone,
  X,
  CreditCard,
  AlertCircle,
  QrCode,
  ArrowRight,
} from 'lucide-react';

const PHONEPE_NUMBER = '9492343566';
const PHONEPE_UPI_ID = '9492343566@ybl';
const PAYEE_NAME = 'Rayudi Rekha - DriveEase Rentals';

export default function PhonePePaymentModal({
  isOpen,
  amount,
  vehicleName = 'Vehicle Rental',
  rentalDays = 1,
  onPaymentSuccess,
  onCancel,
  isProcessing = false,
}) {
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [utrNumber, setUtrNumber] = useState('');
  const [paymentOption, setPaymentOption] = useState('phonepe_qr'); // 'phonepe_qr' | 'pay_at_hub'
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const formattedAmount = Number(amount || 0).toLocaleString('en-IN');
  const upiUri = `upi://pay?pa=${PHONEPE_UPI_ID}&pn=${encodeURIComponent(
    PAYEE_NAME
  )}&am=${amount}&cu=INR&tn=${encodeURIComponent(`Booking for ${vehicleName}`)}`;

  const fallbackQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(
    upiUri
  )}`;

  const handleCopyNumber = () => {
    navigator.clipboard.writeText(PHONEPE_NUMBER);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(PHONEPE_UPI_ID);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleConfirmPayment = (e) => {
    e.preventDefault();
    setError('');

    if (paymentOption === 'phonepe_qr') {
      const cleanUtr = utrNumber.trim();
      if (!cleanUtr) {
        setError('Please enter the 12-digit PhonePe / UPI Transaction Reference (UTR) number after paying.');
        return;
      }
      if (cleanUtr.length < 6) {
        setError('Please enter a valid Transaction ID / UTR received from your payment receipt.');
        return;
      }

      onPaymentSuccess({
        paymentMethod: 'PhonePe UPI QR',
        paymentNumber: PHONEPE_NUMBER,
        upiId: PHONEPE_UPI_ID,
        transactionId: cleanUtr,
        paymentStatus: 'Paid (Pending Verification)',
        paidAmount: amount,
      });
    } else {
      // Pay on pickup at ATV Tadepalligudem
      onPaymentSuccess({
        paymentMethod: 'Pay on Pickup (PhonePe QR / Cash)',
        paymentNumber: PHONEPE_NUMBER,
        upiId: PHONEPE_UPI_ID,
        transactionId: 'PAY-ON-PICKUP',
        paymentStatus: 'Pay on Vehicle Collection',
        paidAmount: amount,
      });
    }
  };

  return (
    <div className="modal-overlay" role="dialog" aria-modal="true" style={{ zIndex: 120 }}>
      <div
        className="modal-content"
        style={{
          maxWidth: '520px',
          padding: 0,
          overflow: 'hidden',
          borderRadius: 'var(--radius-lg)',
          boxShadow: '0 25px 50px -12px rgba(95, 37, 159, 0.35)',
        }}
      >
        {/* PhonePe Branded Header */}
        <div
          style={{
            background: 'linear-gradient(135deg, #5f259f 0%, #7b1fa2 100%)',
            color: '#ffffff',
            padding: '1.25rem 1.5rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div
              style={{
                width: '42px',
                height: '42px',
                borderRadius: '50%',
                backgroundColor: '#ffffff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              }}
            >
              {/* PhonePe Iconic 'Pe' / UPI symbol */}
              <span style={{ color: '#5f259f', fontWeight: '900', fontSize: '1.4rem', fontFamily: 'system-ui' }}>
                पे
              </span>
            </div>
            <div>
              <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em', opacity: 0.9 }}>
                PhonePe UPI Payment Gateway
              </div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '800', margin: 0, color: '#ffffff' }}>
                Scan QR & Complete Booking
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onCancel}
            disabled={isProcessing}
            style={{
              background: 'rgba(255, 255, 255, 0.2)',
              border: 'none',
              borderRadius: '50%',
              width: '32px',
              height: '32px',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
            }}
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div style={{ padding: '1.25rem 1.5rem' }}>
          {/* Amount Badge */}
          <div
            style={{
              backgroundColor: '#f5f3ff',
              border: '1px solid #ddd6fe',
              borderRadius: 'var(--radius-md)',
              padding: '0.85rem 1rem',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '1.25rem',
            }}
          >
            <div>
              <span style={{ fontSize: '0.75rem', color: '#6d28d9', fontWeight: '600', textTransform: 'uppercase' }}>
                Total Payable Amount
              </span>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                {vehicleName} ({rentalDays} {rentalDays === 1 ? 'day' : 'days'})
              </div>
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#5f259f' }}>
              ₹{formattedAmount}
            </div>
          </div>

          {/* Payment Method Selector Tabs */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', marginBottom: '1.25rem' }}>
            <button
              type="button"
              className={`btn btn-sm ${paymentOption === 'phonepe_qr' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setPaymentOption('phonepe_qr')}
              style={{
                backgroundColor: paymentOption === 'phonepe_qr' ? '#5f259f' : '',
                borderColor: paymentOption === 'phonepe_qr' ? '#5f259f' : '',
                padding: '0.55rem',
                fontSize: '0.82rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.35rem',
              }}
            >
              <QrCode size={15} /> Instant PhonePe QR
            </button>
            <button
              type="button"
              className={`btn btn-sm ${paymentOption === 'pay_at_hub' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setPaymentOption('pay_at_hub')}
              style={{
                backgroundColor: paymentOption === 'pay_at_hub' ? '#5f259f' : '',
                borderColor: paymentOption === 'pay_at_hub' ? '#5f259f' : '',
                padding: '0.55rem',
                fontSize: '0.82rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.35rem',
              }}
            >
              <Smartphone size={15} /> Pay on Pickup (Hub)
            </button>
          </div>

          {paymentOption === 'phonepe_qr' ? (
            <div>
              {/* QR Code Container */}
              <div
                style={{
                  textAlign: 'center',
                  backgroundColor: '#ffffff',
                  border: '2px dashed #c4b5fd',
                  borderRadius: 'var(--radius-lg)',
                  padding: '1.25rem 1rem 1rem 1rem',
                  marginBottom: '1.25rem',
                }}
              >
                <div style={{ display: 'inline-block', padding: '0.75rem', backgroundColor: '#ffffff', borderRadius: 'var(--radius-md)', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }}>
                  <QRCodeSVG
                    value={upiUri}
                    size={190}
                    level="H"
                    includeMargin={true}
                    imageSettings={{
                      src: 'https://images.unsplash.com/photo-1614680376593-902f749f7ffc?auto=format&fit=crop&w=48&q=80',
                      x: undefined,
                      y: undefined,
                      height: 36,
                      width: 36,
                      excavate: true,
                    }}
                  />
                </div>

                <div style={{ marginTop: '0.75rem' }}>
                  <span
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                      fontSize: '0.75rem',
                      fontWeight: '700',
                      color: '#5f259f',
                      backgroundColor: '#f5f3ff',
                      padding: '0.2rem 0.6rem',
                      borderRadius: 'var(--radius-full)',
                    }}
                  >
                    Scan with PhonePe / GPay / Paytm
                  </span>
                </div>
              </div>

              {/* Verified PhonePe Number & UPI Details */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1.25rem' }}>
                {/* Account Owner */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '0.55rem 0.85rem',
                    backgroundColor: '#faf5ff',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid #e9d5ff',
                    fontSize: '0.82rem',
                  }}
                >
                  <span style={{ color: '#6b21a8', fontWeight: '600' }}>PhonePe Account Holder:</span>
                  <strong style={{ color: '#5f259f' }}>Rayudi Rekha (Platform Owner)</strong>
                </div>

                {/* PhonePe Number */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '0.65rem 0.85rem',
                    backgroundColor: 'var(--bg-subtle)',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--border-color)',
                  }}
                >
                  <div>
                    <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block' }}>
                      PhonePe Registered Mobile Number:
                    </span>
                    <strong style={{ fontSize: '0.98rem', letterSpacing: '0.04em', color: 'var(--text-main)' }}>
                      {PHONEPE_NUMBER}
                    </strong>
                  </div>
                  <button
                    type="button"
                    className="btn btn-sm btn-secondary"
                    onClick={handleCopyNumber}
                    style={{ padding: '0.3rem 0.65rem', fontSize: '0.75rem' }}
                  >
                    {copiedNumber ? <Check size={13} style={{ color: 'var(--success)' }} /> : <Copy size={13} />}
                    {copiedNumber ? 'Copied' : 'Copy'}
                  </button>
                </div>

                {/* UPI ID */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '0.65rem 0.85rem',
                    backgroundColor: 'var(--bg-subtle)',
                    borderRadius: 'var(--radius-sm)',
                    border: '1px solid var(--border-color)',
                  }}
                >
                  <div>
                    <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block' }}>
                      PhonePe UPI ID:
                    </span>
                    <strong style={{ fontSize: '0.92rem', color: '#5f259f' }}>
                      {PHONEPE_UPI_ID}
                    </strong>
                  </div>
                  <button
                    type="button"
                    className="btn btn-sm btn-secondary"
                    onClick={handleCopyUpi}
                    style={{ padding: '0.3rem 0.65rem', fontSize: '0.75rem' }}
                  >
                    {copiedUpi ? <Check size={13} style={{ color: 'var(--success)' }} /> : <Copy size={13} />}
                    {copiedUpi ? 'Copied' : 'Copy'}
                  </button>
                </div>
              </div>

              {/* UTR Input Form */}
              <form onSubmit={handleConfirmPayment}>
                {error && (
                  <div className="alert alert-error" style={{ marginBottom: '0.85rem', padding: '0.65rem 0.85rem', fontSize: '0.82rem' }}>
                    <AlertCircle size={15} style={{ flexShrink: 0 }} />
                    <span>{error}</span>
                  </div>
                )}

                <div className="form-group" style={{ marginBottom: '1rem' }}>
                  <label className="form-label" htmlFor="utrInput" style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span>UPI Transaction ID / UTR Number <span className="required">*</span></span>
                    <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Found in PhonePe receipt</span>
                  </label>
                  <input
                    id="utrInput"
                    type="text"
                    className="form-input"
                    placeholder="e.g. 430987654321 (12 digits)"
                    value={utrNumber}
                    onChange={(e) => setUtrNumber(e.target.value)}
                    disabled={isProcessing}
                    style={{ fontFamily: 'monospace', fontWeight: '600' }}
                  />
                  <span className="form-helper" style={{ fontSize: '0.73rem', marginTop: '0.25rem' }}>
                    After paying ₹{formattedAmount} via PhonePe to <strong>{PHONEPE_NUMBER}</strong>, paste the UTR here to confirm your reservation.
                  </span>
                </div>

                <div style={{ display: 'flex', gap: '0.75rem' }}>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={onCancel}
                    disabled={isProcessing}
                    style={{ flex: 1 }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn"
                    style={{
                      flex: 2,
                      backgroundColor: '#5f259f',
                      color: '#ffffff',
                      fontWeight: '700',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.4rem',
                    }}
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <span className="spinner" style={{ width: '14px', height: '14px', borderWidth: '2px' }}></span>
                        Verifying...
                      </>
                    ) : (
                      <>
                        <CheckCircle2 size={16} /> Confirm & Reserve
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          ) : (
            /* Pay on Pickup Option */
            <div>
              <div
                style={{
                  padding: '1.25rem',
                  backgroundColor: 'var(--bg-subtle)',
                  borderRadius: 'var(--radius-md)',
                  marginBottom: '1.25rem',
                  fontSize: '0.88rem',
                  lineHeight: 1.5,
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontWeight: '700', color: 'var(--text-main)', marginBottom: '0.4rem' }}>
                  <MapPin size={16} style={{ color: 'var(--primary)' }} />
                  Vehicle Pickup Hub: ATV Tadepalligudem
                </div>
                <p style={{ color: 'var(--text-muted)', margin: 0 }}>
                  You can inspect the vehicle first at <strong>ATV Tadepalligudem</strong> and complete the PhonePe payment to <strong>{PHONEPE_NUMBER}</strong> or pay cash directly during vehicle key handover.
                </p>
              </div>

              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={onCancel}
                  disabled={isProcessing}
                  style={{ flex: 1 }}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleConfirmPayment}
                  disabled={isProcessing}
                  style={{ flex: 2, fontWeight: '700' }}
                >
                  Reserve Now (Pay at Hub) <ArrowRight size={15} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
