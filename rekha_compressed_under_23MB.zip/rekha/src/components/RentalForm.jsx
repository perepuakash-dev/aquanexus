import React, { useState, useEffect } from 'react';
import { calculateRentalDays, findConflictingRental, formatDisplayDate, getTodayDateString } from '../utils/dateUtils';
import {
  Calendar,
  AlertCircle,
  Save,
  X,
  Car,
  Bike,
  User,
  Users,
  Clock,
  DollarSign,
  Paperclip,
  ShieldCheck,
  Navigation,
  HardHat,
  Package,
  MapPin,
  Lock,
  Fuel,
  Gauge,
  CheckCircle2,
  Sparkles,
  Building,
  Info,
} from 'lucide-react';

export const VEHICLE_ATTACHMENT_OPTIONS = [
  {
    id: 'insurance',
    name: 'Comprehensive Damage Insurance',
    price: 200,
    icon: ShieldCheck,
    description: 'Zero excess coverage against road accidents & theft',
  },
  {
    id: 'gps',
    name: 'GPS Live Navigation Device',
    price: 150,
    icon: Navigation,
    description: 'Turn-by-turn Indian highway navigation & emergency tracker',
  },
  {
    id: 'helmet_seat',
    name: 'Safety Helmet / Child Seat',
    price: 100,
    icon: HardHat,
    description: 'ISI certified safety helmet or infant protective booster seat',
  },
  {
    id: 'carrier',
    name: 'Luggage / Rooftop Carrier',
    price: 200,
    icon: Package,
    description: 'Heavy-duty rooftop luggage carrier with rain cover straps',
  },
];

export default function RentalForm({
  initialData = null,
  vehicles = [],
  customers = [],
  rentals = [],
  owners = [],
  preselectedVehicleId = null,
  preselectedStartDate = null,
  preselectedEndDate = null,
  onSubmit,
  onCancel,
  isLoading = false,
}) {
  const [formData, setFormData] = useState({
    customerId: '',
    customerName: '',
    customerPhone: '',
    vehicleId: '',
    startDate: '',
    endDate: '',
    status: 'Pending',
    location: 'ATV Tadepalligudem',
    attachments: [],
  });

  const [errors, setErrors] = useState({});
  const [dateConflict, setDateConflict] = useState(null);

  // Initialize or populate data
  useEffect(() => {
    if (initialData) {
      const existingCust = customers.find((c) => String(c.id) === String(initialData.customerId));
      setFormData({
        customerId: String(initialData.customerId || ''),
        customerName: existingCust?.name || initialData.customerName || '',
        customerPhone: existingCust?.phone || initialData.customerPhone || '',
        vehicleId: String(initialData.vehicleId || ''),
        startDate: initialData.startDate || '',
        endDate: initialData.endDate || '',
        status: initialData.status || 'Active',
        location: initialData.location || 'ATV Tadepalligudem',
        attachments: Array.isArray(initialData.attachments) ? initialData.attachments : [],
      });
    } else {
      const today = getTodayDateString();
      setFormData((prev) => ({
        ...prev,
        vehicleId: preselectedVehicleId ? String(preselectedVehicleId) : prev.vehicleId,
        startDate: preselectedStartDate || prev.startDate || today,
        endDate: preselectedEndDate || prev.endDate || '',
        location: 'ATV Tadepalligudem',
      }));
    }
  }, [initialData, preselectedVehicleId, preselectedStartDate, preselectedEndDate, customers]);

  // Selected vehicle details & owner
  const selectedVehicle = vehicles.find((v) => String(v.id) === String(formData.vehicleId));
  const selectedCustomer = customers.find((c) => String(c.id) === String(formData.customerId));
  const selectedOwner = owners.find((o) => String(o.id) === String(selectedVehicle?.ownerId));

  // Calculations
  const rentalDays = (formData.startDate && formData.endDate)
    ? calculateRentalDays(formData.startDate, formData.endDate)
    : 0;

  const baseDailyPrice = selectedVehicle ? Number(selectedVehicle.pricePerDay || 0) : 0;

  const attachmentsDailyPrice = (formData.attachments || []).reduce((sum, id) => {
    const opt = VEHICLE_ATTACHMENT_OPTIONS.find((a) => a.id === id);
    return sum + (opt ? opt.price : 0);
  }, 0);

  const effectiveDailyRate = baseDailyPrice + attachmentsDailyPrice;
  const totalAmount = rentalDays > 0 ? rentalDays * effectiveDailyRate : 0;

  // Real-time conflict checking when vehicle or dates change
  useEffect(() => {
    if (formData.vehicleId && formData.startDate && formData.endDate && rentalDays > 0) {
      const conflict = findConflictingRental(
        rentals,
        formData.vehicleId,
        formData.startDate,
        formData.endDate,
        initialData ? initialData.id : null
      );
      setDateConflict(conflict || null);
    } else {
      setDateConflict(null);
    }
  }, [formData.vehicleId, formData.startDate, formData.endDate, rentalDays, rentals, initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const handleCustomerNameChange = (e) => {
    const enteredName = e.target.value;
    const matched = customers.find(
      (c) => c.name.toLowerCase() === enteredName.trim().toLowerCase()
    );

    setFormData((prev) => ({
      ...prev,
      customerName: enteredName,
      customerId: matched ? String(matched.id) : prev.customerId,
      customerPhone: matched ? matched.phone : prev.customerPhone,
    }));

    if (errors.customerName) {
      setErrors((prev) => ({ ...prev, customerName: null }));
    }
  };

  const toggleAttachment = (attachmentId) => {
    setFormData((prev) => {
      const exists = prev.attachments.includes(attachmentId);
      return {
        ...prev,
        attachments: exists
          ? prev.attachments.filter((id) => id !== attachmentId)
          : [...prev.attachments, attachmentId],
      };
    });
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.customerName || !formData.customerName.trim()) {
      newErrors.customerName = 'Please enter your name.';
    }

    const cleanPhone = (formData.customerPhone || '').replace(/[\s\-\(\)\.]/g, '');
    let digits = cleanPhone;
    if (digits.startsWith('+91')) digits = digits.slice(3);
    else if (digits.startsWith('91') && digits.length === 12) digits = digits.slice(2);
    else if (digits.startsWith('0') && digits.length === 11) digits = digits.slice(1);

    if (!cleanPhone) {
      newErrors.customerPhone = 'Mobile number is required for SMS booking notifications.';
    } else if (!/^[6-9]\d{9}$/.test(digits)) {
      newErrors.customerPhone = 'Enter a valid 10-digit Indian mobile number (e.g. 9492343566).';
    }

    if (!formData.vehicleId) {
      newErrors.vehicleId = 'Please select a vehicle.';
    } else if (selectedVehicle && !selectedVehicle.available && (!initialData || String(initialData.vehicleId) !== String(selectedVehicle.id))) {
      newErrors.vehicleId = 'This vehicle is currently marked as unavailable for rent.';
    }

    if (!formData.startDate) {
      newErrors.startDate = 'Rental start date is required.';
    }

    if (!formData.endDate) {
      newErrors.endDate = 'Rental end date is required.';
    }

    if (formData.startDate && formData.endDate) {
      if (rentalDays <= 0) {
        newErrors.endDate = 'End date must be strictly after the start date (at least 1 day rental).';
      }
    }

    // Overlapping booking check
    if (formData.vehicleId && formData.startDate && formData.endDate && rentalDays > 0) {
      const conflict = findConflictingRental(
        rentals,
        formData.vehicleId,
        formData.startDate,
        formData.endDate,
        initialData ? initialData.id : null
      );
      if (conflict) {
        newErrors.dateConflict = `Vehicle is already booked for an overlapping period (${formatDisplayDate(conflict.startDate)} to ${formatDisplayDate(conflict.endDate)}). Two bookings for the same vehicle must not overlap.`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    onSubmit({
      ...formData,
      customerName: formData.customerName.trim(),
      customerPhone: formData.customerPhone ? formData.customerPhone.trim() : '',
      ownerId: selectedVehicle?.ownerId || '1',
      securityDeposit: selectedVehicle?.securityDeposit || 3000,
      numberOfDays: rentalDays,
      bookingStatus: formData.status || 'Pending',
      status: formData.status || 'Pending',
      location: formData.location || 'ATV Tadepalligudem',
      pickupLocation: selectedVehicle?.pickupLocation || 'ATV Tadepalligudem',
      days: rentalDays,
      dailyPrice: baseDailyPrice,
      pricePerDay: baseDailyPrice,
      attachmentsDailyPrice: attachmentsDailyPrice,
      effectiveDailyRate: effectiveDailyRate,
      totalAmount: totalAmount,
      createdAt: new Date().toISOString(),
    });
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {errors.dateConflict && (
        <div className="alert alert-error" style={{ marginBottom: '1.25rem' }}>
          <AlertCircle size={20} style={{ flexShrink: 0 }} />
          <span>{errors.dateConflict}</span>
        </div>
      )}

      {dateConflict && !errors.dateConflict && (
        <div className="alert alert-error" style={{ marginBottom: '1.25rem' }}>
          <AlertCircle size={20} style={{ flexShrink: 0 }} />
          <span>
            Conflict Detected: Vehicle already booked from {formatDisplayDate(dateConflict.startDate)} to {formatDisplayDate(dateConflict.endDate)}.
          </span>
        </div>
      )}

      <div className="form-grid-2">
        <div className="form-group">
          <label className="form-label" htmlFor="customerName">
            Enter Your Name <span className="required">*</span>
          </label>
          <input
            id="customerName"
            name="customerName"
            type="text"
            list="customerDatalist"
            className={`form-input ${errors.customerName ? 'is-invalid' : ''}`}
            placeholder="Enter your full name"
            value={formData.customerName}
            onChange={handleCustomerNameChange}
            disabled={isLoading}
            autoComplete="name"
          />
          {customers && customers.length > 0 && (
            <datalist id="customerDatalist">
              {customers.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name} ({c.phone})
                </option>
              ))}
            </datalist>
          )}
          {errors.customerName && <span className="form-error">{errors.customerName}</span>}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="customerPhone">
            Mobile Number (for SMS Confirmation) <span className="required">*</span>
          </label>
          <div style={{ position: 'relative' }}>
            <span
              style={{
                position: 'absolute',
                left: '0.75rem',
                top: '50%',
                transform: 'translateY(-50%)',
                color: 'var(--text-muted)',
                fontWeight: '600',
                fontSize: '0.85rem',
                pointerEvents: 'none',
              }}
            >
              +91
            </span>
            <input
              id="customerPhone"
              name="customerPhone"
              type="tel"
              maxLength={14}
              className={`form-input ${errors.customerPhone ? 'is-invalid' : ''}`}
              style={{ paddingLeft: '2.5rem' }}
              placeholder="e.g. 9492343566"
              value={formData.customerPhone}
              onChange={handleChange}
              disabled={isLoading}
              autoComplete="tel"
            />
          </div>
          {errors.customerPhone ? (
            <span className="form-error">{errors.customerPhone}</span>
          ) : (
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block', marginTop: '0.25rem' }}>
              Instant SMS confirmation with your Booking ID will be dispatched to this number.
            </span>
          )}
        </div>
      </div>

      <div className="form-group" style={{ marginBottom: '1rem' }}>
        <label className="form-label" htmlFor="vehicleSelect">
          Select Vehicle <span className="required">*</span>
        </label>
        <select
          id="vehicleSelect"
          name="vehicleId"
          className={`form-select ${errors.vehicleId ? 'is-invalid' : ''}`}
          value={formData.vehicleId}
          onChange={handleChange}
          disabled={isLoading}
        >
          <option value="">-- Choose Vehicle --</option>
          {vehicles.map((v) => {
            const vOwner = owners.find((o) => String(o.id) === String(v.ownerId));
            return (
              <option
                key={v.id}
                value={v.id}
                disabled={!v.available && (!initialData || String(initialData.vehicleId) !== String(v.id))}
              >
                {v.name} - {v.category} (₹{v.pricePerDay}/day) [Owner: {vOwner ? vOwner.name : 'Host'}] [Reg: {v.registrationNumber}] {!v.available ? '(Unavailable)' : ''}
              </option>
            );
          })}
        </select>
        {errors.vehicleId && <span className="form-error">{errors.vehicleId}</span>}
      </div>

      {/* Complete Vehicle Specifications & Vehicle Owner Information */}
      {selectedVehicle && (
        <div
          style={{
            backgroundColor: 'var(--bg-subtle)',
            border: '1px solid var(--border-color)',
            borderRadius: 'var(--radius-md)',
            padding: '1.1rem',
            marginBottom: '1.25rem',
          }}
        >
          {/* Owner Details Card */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingBottom: '0.85rem',
              marginBottom: '0.85rem',
              borderBottom: '1px solid var(--border-color)',
              flexWrap: 'wrap',
              gap: '0.75rem',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div
                style={{
                  width: '42px',
                  height: '42px',
                  borderRadius: '50%',
                  backgroundColor: 'var(--primary-light)',
                  color: 'var(--primary)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: '700',
                  fontSize: '1rem',
                  overflow: 'hidden',
                  border: '2px solid var(--primary-border)',
                }}
              >
                {selectedOwner?.avatar ? (
                  <img
                    src={selectedOwner.avatar}
                    alt={selectedOwner.name}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                ) : (
                  (selectedOwner?.name || 'O').charAt(0).toUpperCase()
                )}
              </div>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <strong style={{ fontSize: '0.95rem' }}>
                    {selectedOwner ? selectedOwner.name : 'Verified Vehicle Host'}
                  </strong>
                  <span
                    className="badge badge-verified"
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '0.2rem',
                      fontSize: '0.7rem',
                      padding: '0.15rem 0.45rem',
                    }}
                  >
                    <ShieldCheck size={11} /> Verified Owner
                  </span>
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.15rem' }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.2rem' }}>
                    <MapPin size={11} /> {selectedOwner?.city || 'Tadepalligudem'}
                  </span>
                  <span>•</span>
                  <span>Owner ID: #{selectedVehicle.ownerId || selectedOwner?.id || '1'}</span>
                </div>
              </div>
            </div>

            <div style={{ textAlign: 'right', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem', color: 'var(--primary)', fontWeight: '600' }}>
                <Clock size={12} /> Instant Owner Notification
              </div>
              <div>Requests reviewed in Owner Dashboard</div>
            </div>
          </div>

          {/* Vehicle Specifications Grid */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
              <strong style={{ fontSize: '0.88rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                {selectedVehicle.category === 'Car' ? <Car size={15} /> : <Bike size={15} />}
                {selectedVehicle.name} Specifications
              </strong>
              <span className="badge badge-category" style={{ fontSize: '0.72rem' }}>
                {selectedVehicle.category} • {selectedVehicle.brand || selectedVehicle.model || 'Standard'}
              </span>
            </div>

            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
                gap: '0.6rem',
                fontSize: '0.8rem',
              }}
            >
              <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Registration No</div>
                <strong style={{ fontFamily: 'monospace' }}>{selectedVehicle.registrationNumber}</strong>
              </div>

              {selectedVehicle.category === 'Car' ? (
                <>
                  <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Seating Capacity</div>
                    <strong>{selectedVehicle.seatingCapacity || 5} Seats</strong>
                  </div>
                  <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Air Conditioning</div>
                    <strong>{selectedVehicle.ac !== false ? 'AC Included' : 'Non-AC'}</strong>
                  </div>
                  <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Luggage Capacity</div>
                    <strong>{selectedVehicle.luggageCapacity || '3 Bags'}</strong>
                  </div>
                </>
              ) : (
                <>
                  <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Engine CC</div>
                    <strong>{selectedVehicle.engineCapacityCC || selectedVehicle.engineCapacity || '150'} CC</strong>
                  </div>
                  <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Bike Category</div>
                    <strong>{selectedVehicle.bikeCategory || 'Standard'}</strong>
                  </div>
                  <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Fuel Tank</div>
                    <strong>{selectedVehicle.fuelTankCapacity || '12'} L</strong>
                  </div>
                </>
              )}

              <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Fuel Type</div>
                <strong>{selectedVehicle.fuelType || 'Petrol'}</strong>
              </div>
              <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Transmission</div>
                <strong>{selectedVehicle.transmission || 'Manual'}</strong>
              </div>
              <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Mileage</div>
                <strong>{selectedVehicle.mileageKmpl || selectedVehicle.mileage || (selectedVehicle.category === 'Car' ? '18' : '45')} KM/L</strong>
              </div>
              <div style={{ backgroundColor: 'var(--card-bg)', padding: '0.5rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Security Deposit</div>
                <strong style={{ color: 'var(--primary)' }}>₹{Number(selectedVehicle.securityDeposit || 3000).toLocaleString('en-IN')}</strong>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="form-grid-2">
        <div className="form-group">
          <label className="form-label" htmlFor="startDate">
            Rental Start Date <span className="required">*</span>
          </label>
          <input
            id="startDate"
            name="startDate"
            type="date"
            className={`form-input ${errors.startDate ? 'is-invalid' : ''}`}
            value={formData.startDate}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.startDate && <span className="form-error">{errors.startDate}</span>}
        </div>

        <div className="form-group">
          <label className="form-label" htmlFor="endDate">
            Rental End Date <span className="required">*</span>
          </label>
          <input
            id="endDate"
            name="endDate"
            type="date"
            className={`form-input ${errors.endDate ? 'is-invalid' : ''}`}
            value={formData.endDate}
            min={formData.startDate || undefined}
            onChange={handleChange}
            disabled={isLoading}
          />
          {errors.endDate && <span className="form-error">{errors.endDate}</span>}
        </div>
      </div>

      {/* Rental Location (Only at ATV Tadepalligudem) */}
      <div className="form-group" style={{ marginBottom: '1.25rem' }}>
        <label className="form-label" htmlFor="rentalLocation" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <MapPin size={16} style={{ color: 'var(--primary)' }} />
          Rental Pickup & Return Location <span className="required">*</span>
        </label>
        <div style={{ position: 'relative' }}>
          <input
            id="rentalLocation"
            name="location"
            type="text"
            className="form-input"
            value={formData.location}
            readOnly
            style={{
              backgroundColor: 'var(--bg-subtle)',
              cursor: 'not-allowed',
              fontWeight: '600',
              paddingLeft: '2.5rem',
            }}
          />
          <MapPin
            size={18}
            style={{
              position: 'absolute',
              left: '0.85rem',
              top: '50%',
              transform: 'translateY(-50%)',
              color: 'var(--primary)',
            }}
          />
          <span
            style={{
              position: 'absolute',
              right: '0.85rem',
              top: '50%',
              transform: 'translateY(-50%)',
              fontSize: '0.75rem',
              fontWeight: '600',
              color: 'var(--primary)',
              backgroundColor: 'var(--primary-light)',
              padding: '0.2rem 0.5rem',
              borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--primary-border)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.25rem',
            }}
          >
            <Lock size={12} /> Only at ATV Tadepalligudem
          </span>
        </div>
        <span className="form-helper" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', marginTop: '0.35rem' }}>
          Vehicle pickups and returns for this rental service are located only at <strong>ATV Tadepalligudem</strong>.
        </span>
      </div>

      <div className="form-group">
        <label className="form-label" htmlFor="status">
          Rental Status
        </label>
        <select
          id="status"
          name="status"
          className="form-select"
          value={formData.status}
          onChange={handleChange}
          disabled={isLoading}
        >
          <option value="Active">Active (Ongoing Rental)</option>
          <option value="Booked">Booked (Reserved Future Booking)</option>
          <option value="Completed">Completed (Returned)</option>
          <option value="Cancelled">Cancelled</option>
        </select>
      </div>

      {/* Vehicle Add-on Attachments / Equipment Options */}
      <div className="form-group" style={{ marginBottom: '1.25rem' }}>
        <label className="form-label" style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
          <Paperclip size={16} style={{ color: 'var(--primary)' }} />
          Vehicle Add-ons & Equipment Attachments
        </label>
        <span className="form-helper" style={{ display: 'block', marginBottom: '0.65rem' }}>
          Select optional vehicle equipment and accessories for this rental.
        </span>

        <div className="addons-grid">
          {VEHICLE_ATTACHMENT_OPTIONS.map((opt) => {
            const isSelected = formData.attachments.includes(opt.id);
            const Icon = opt.icon;
            return (
              <label
                key={opt.id}
                className={`addon-card ${isSelected ? 'selected' : ''}`}
              >
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => toggleAttachment(opt.id)}
                  disabled={isLoading}
                />
                <div className="addon-card-info">
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <Icon size={15} style={{ color: isSelected ? 'var(--primary)' : 'var(--text-muted)' }} />
                    <span className="addon-card-title">{opt.name}</span>
                  </div>
                  <div className="addon-card-price">+₹{opt.price} / day</div>
                  <div className="addon-card-desc">{opt.description}</div>
                </div>
              </label>
            );
          })}
        </div>
      </div>

      {/* Real-time Calculation Summary Box */}
      <div className="booking-summary-card">
        <h4 style={{ fontSize: '0.95rem', fontWeight: '700', color: 'var(--text-main)', marginBottom: '0.85rem' }}>
          Rental Charge Calculation
        </h4>

        <div className="summary-row">
          <span>Selected Vehicle:</span>
          <strong>{selectedVehicle ? `${selectedVehicle.name} (${selectedVehicle.category})` : '—'}</strong>
        </div>

        {selectedOwner && (
          <div className="summary-row">
            <span>Vehicle Host / Owner:</span>
            <strong style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}>
              <ShieldCheck size={13} style={{ color: 'var(--success)' }} />
              {selectedOwner.name}
            </strong>
          </div>
        )}

        <div className="summary-row">
          <span>Customer:</span>
          <span>{formData.customerName || (selectedCustomer ? selectedCustomer.name : '—')}</span>
        </div>

        <div className="summary-row">
          <span>Rental Location:</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', fontWeight: '600', color: 'var(--primary)' }}>
            <MapPin size={14} /> ATV Tadepalligudem
          </span>
        </div>

        <div className="summary-row">
          <span>Rental Period:</span>
          <span>
            {formData.startDate && formData.endDate
              ? `${formatDisplayDate(formData.startDate)} → ${formatDisplayDate(formData.endDate)}`
              : '—'}
          </span>
        </div>

        <div className="summary-row">
          <span>Vehicle Base Rate:</span>
          <span>₹{baseDailyPrice.toLocaleString('en-IN')} / day</span>
        </div>

        {attachmentsDailyPrice > 0 && (
          <div className="summary-row" style={{ color: 'var(--primary)' }}>
            <span>Vehicle Attachments ({formData.attachments.length}):</span>
            <span>+₹{attachmentsDailyPrice.toLocaleString('en-IN')} / day</span>
          </div>
        )}

        <div className="summary-row">
          <span>Effective Daily Rate:</span>
          <strong>₹{effectiveDailyRate.toLocaleString('en-IN')} / day</strong>
        </div>

        <div className="summary-row">
          <span>Duration:</span>
          <span>
            {rentalDays > 0 ? (
              <strong>
                {rentalDays} {rentalDays === 1 ? 'day' : 'days'}
              </strong>
            ) : (
              '0 days (Invalid range)'
            )}
          </span>
        </div>

        <div className="summary-row total">
          <span>Total Rental Amount:</span>
          <span>₹{totalAmount.toLocaleString('en-IN')}</span>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '1.5rem', borderTop: '1px solid var(--border-color)', paddingTop: '1.25rem' }}>
        {onCancel && (
          <button
            type="button"
            className="btn btn-secondary"
            onClick={onCancel}
            disabled={isLoading}
          >
            <X size={16} /> Cancel
          </button>
        )}
        <button
          type="submit"
          className="btn btn-primary"
          disabled={isLoading || dateConflict !== null}
        >
          {isLoading ? (
            <>
              <span className="spinner" style={{ width: '14px', height: '14px', borderWidth: '2px' }}></span>
              Saving Rental...
            </>
          ) : (
            <>
              <Save size={16} /> {initialData ? 'Update Rental' : 'Confirm & Create Booking'}
            </>
          )}
        </button>
      </div>
    </form>
  );
}
