import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { rentalApi, vehicleApi, customerApi, ownerApi } from '../services/api';
import RentalForm from '../components/RentalForm';
import { LoadingSpinner, ErrorBanner } from '../components/LoadingState';
import { ArrowLeft, CalendarCheck } from 'lucide-react';

export default function RentalEdit() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [rental, setRental] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [owners, setOwners] = useState([]);
  const [allRentals, setAllRentals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchRentalData = async () => {
      setLoading(true);
      setError(null);
      try {
        const [targetRental, vData, cData, rData, oData] = await Promise.all([
          rentalApi.getById(id),
          vehicleApi.getAll(),
          customerApi.getAll(),
          rentalApi.getAll(),
          ownerApi.getAll(),
        ]);
        setRental(targetRental);
        setVehicles(vData || []);
        setCustomers(cData || []);
        setAllRentals(rData || []);
        setOwners(oData || []);
      } catch (err) {
        setError(err.message || 'Rental record not found.');
      } finally {
        setLoading(false);
      }
    };

    fetchRentalData();
  }, [id]);

  const handleUpdate = async (formData) => {
    setIsSubmitting(true);
    try {
      await rentalApi.update(id, formData);
      navigate('/rentals');
    } catch (err) {
      alert(`Failed to update rental: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return <LoadingSpinner message="Fetching rental transaction..." />;
  }

  if (error) {
    return (
      <div>
        <Link to="/rentals" className="btn btn-secondary" style={{ marginBottom: '1rem' }}>
          <ArrowLeft size={16} /> Back to Rentals
        </Link>
        <ErrorBanner message={error} />
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '780px', margin: '0 auto' }}>
      <div style={{ marginBottom: '1.25rem' }}>
        <Link to="/rentals" className="btn btn-secondary btn-sm" style={{ marginBottom: '0.75rem' }}>
          <ArrowLeft size={14} /> Back to Rental History
        </Link>
      </div>

      <div className="card">
        <div className="card-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div className="stat-icon blue" style={{ width: '38px', height: '38px' }}>
              <CalendarCheck size={18} />
            </div>
            <div>
              <div className="card-title">Edit Rental Record #{rental?.id}</div>
              <div className="card-subtitle">
                Modify dates, vehicle assignment, or booking status (Hub: ATV Tadepalligudem)
              </div>
            </div>
          </div>
        </div>
        <div className="card-body">
          <RentalForm
            initialData={rental}
            vehicles={vehicles}
            customers={customers}
            rentals={allRentals}
            owners={owners}
            onSubmit={handleUpdate}
            onCancel={() => navigate('/rentals')}
            isLoading={isSubmitting}
          />
        </div>
      </div>
    </div>
  );
}
