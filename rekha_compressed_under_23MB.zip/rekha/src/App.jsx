import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Header from './components/Header';

// Pages
import Dashboard from './pages/Dashboard';
import Marketplace from './pages/Marketplace';
import Owners from './pages/Owners';
import OwnerDashboard from './pages/OwnerDashboard';
import Vehicles from './pages/Vehicles';
import VehicleDetails from './pages/VehicleDetails';
import VehicleEdit from './pages/VehicleEdit';
import Customers from './pages/Customers';
import CustomerEdit from './pages/CustomerEdit';
import BookVehicle from './pages/BookVehicle';
import Rentals from './pages/Rentals';
import RentalEdit from './pages/RentalEdit';
import NotFound from './pages/NotFound';

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="app-container">
      <Sidebar
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      <div className="main-wrapper">
        <Header onToggleMobile={() => setMobileOpen((prev) => !prev)} />
        <main className="main-content">
          <Routes>
            {/* Initial Screen: Customer immediately sees Indian car catalogue */}
            <Route path="/" element={<Marketplace />} />
            <Route path="/marketplace" element={<Marketplace />} />
            
            {/* Administration & Operations */}
            <Route path="/admin" element={<Dashboard />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/owners" element={<Owners />} />
            <Route path="/owner-dashboard" element={<OwnerDashboard />} />
            <Route path="/vehicles" element={<Vehicles />} />
            <Route path="/vehicles/view/:id" element={<VehicleDetails />} />
            <Route path="/vehicles/edit/:id" element={<VehicleEdit />} />
            <Route path="/customers" element={<Customers />} />
            <Route path="/customers/edit/:id" element={<CustomerEdit />} />
            <Route path="/book" element={<BookVehicle />} />
            <Route path="/rentals" element={<Rentals />} />
            <Route path="/rentals/edit/:id" element={<RentalEdit />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
