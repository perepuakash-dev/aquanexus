import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { rentalApi, vehicleApi, customerApi, ownerApi, smsApi } from '../services/api';
import ConfirmDialog from '../components/ConfirmDialog';
import { LoadingSpinner, ErrorBanner, EmptyState } from '../components/LoadingState';
import { formatDisplayDate, isVehicleRentedToday } from '../utils/dateUtils';
import {
  CalendarCheck,
  Search,
  Filter,
  CheckCircle,
  XCircle,
  Trash2,
  Edit2,
  Eye,
  Plus,
  Check,
  X,
  FileText,
  AlertCircle,
  Paperclip,
  MapPin,
} from 'lucide-react';

export default function Rentals() {
  const navigate = useNavigate();

  const [rentals, setRentals] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [owners, setOwners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');

  // Modals & Action States
  const [viewRental, setViewRental] = useState(null);
  const [rentalToCancel, setRentalToCancel] = useState(null);
  const [rentalToComplete, setRentalToComplete] = useState(null);
  const [rentalToDelete, setRentalToDelete] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [rData, vData, cData, oData] = await Promise.all([
        rentalApi.getAll(),
        vehicleApi.getAll(),
        customerApi.getAll(),
        ownerApi.getAll(),
      ]);
      setRentals(rData || []);
      setVehicles(vData || []);
      setCustomers(cData || []);
      setOwners(oData || []);
    } catch (err) {
      setError(err.message || 'Failed to load rental transactions.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Helper mappings
  const getCustomer = (id) => customers.find((c) => String(c.id) === String(id));
  const getVehicle = (id) => vehicles.find((v) => String(v.id) === String(id));
  const getOwner = (id) => owners.find((o) => String(o.id) === String(id));

  // Quick Approve Booking
  const handleApproveRental = async (rental) => {
    setIsProcessing(true);
    try {
      const v = getVehicle(rental.vehicleId);
      const c = getCustomer(rental.customerId);
      const phone = rental.customerPhone || c?.phone || '';

      const updated = await rentalApi.update(rental.id, {
        ...rental,
        bookingStatus: 'Approved',
        status: 'Approved',
      });
      setRentals((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));

      let smsNotice = '';
      try {
        const smsRes = await smsApi.send({
          bookingId: rental.bookingId || `BK-2026-${rental.id}`,
          rentalId: rental.id,
          customerName: rental.customerName || c?.name,
          customerPhone: phone,
          vehicleName: v?.name,
          startDate: rental.startDate,
          endDate: rental.endDate,
          totalAmount: rental.totalAmount,
          event: 'BOOKING_APPROVED',
        });
        if (smsRes.status === 'SENT') {
          smsNotice = ` (SMS confirmation sent via ${smsRes.provider})`;
        } else if (smsRes.status === 'UNAVAILABLE') {
          smsNotice = ` (SMS service unconfigured in .env)`;
        }
      } catch (smsErr) {
        console.warn('SMS approval dispatch note:', smsErr);
      }

      setSuccessMessage(`Rental booking #${rental.bookingId || rental.id} has been Approved.${smsNotice}`);
      setTimeout(() => setSuccessMessage(null), 5000);
    } catch (err) {
      alert(`Approval failed: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  /**
   * Recalculates and updates vehicle availability flag in db.json
   * when a rental is completed, cancelled, or deleted.
   */
  const syncVehicleAvailability = async (vehicleId, updatedRentalsList) => {
    const v = vehicles.find((item) => String(item.id) === String(vehicleId));
    if (!v) return;

    // Check if vehicle has any other active rental today
    const rentedNow = isVehicleRentedToday(vehicleId, updatedRentalsList);
    const shouldBeAvailable = !rentedNow;

    if (v.available !== shouldBeAvailable) {
      try {
        const updatedVehicle = await vehicleApi.update(v.id, {
          ...v,
          available: shouldBeAvailable,
        });
        setVehicles((prev) => prev.map((item) => (item.id === v.id ? updatedVehicle : item)));
      } catch (e) {
        console.warn('Failed to sync vehicle availability:', e);
      }
    }
  };

  // Mark Rental as Completed
  const handleMarkCompleted = async () => {
    if (!rentalToComplete) return;
    setIsProcessing(true);
    try {
      const v = getVehicle(rentalToComplete.vehicleId);
      const c = getCustomer(rentalToComplete.customerId);
      const phone = rentalToComplete.customerPhone || c?.phone || '';

      const updated = await rentalApi.update(rentalToComplete.id, {
        ...rentalToComplete,
        status: 'Completed',
        bookingStatus: 'Completed',
      });

      const nextRentals = rentals.map((r) => (r.id === updated.id ? updated : r));
      setRentals(nextRentals);
      await syncVehicleAvailability(rentalToComplete.vehicleId, nextRentals);

      let smsNotice = '';
      try {
        const smsRes = await smsApi.send({
          bookingId: rentalToComplete.bookingId || `BK-2026-${rentalToComplete.id}`,
          rentalId: rentalToComplete.id,
          customerName: rentalToComplete.customerName || c?.name,
          customerPhone: phone,
          vehicleName: v?.name,
          endDate: rentalToComplete.endDate,
          event: 'BOOKING_COMPLETED',
        });
        if (smsRes.status === 'SENT') {
          smsNotice = ` (Completion SMS sent via ${smsRes.provider})`;
        } else if (smsRes.status === 'UNAVAILABLE') {
          smsNotice = ` (SMS service unconfigured in .env)`;
        }
      } catch (smsErr) {
        console.warn('SMS complete dispatch note:', smsErr);
      }

      setSuccessMessage(`Rental #${rentalToComplete.bookingId || rentalToComplete.id} marked as Completed.${smsNotice}`);
      setTimeout(() => setSuccessMessage(null), 5000);
      setRentalToComplete(null);
    } catch (err) {
      alert(`Error updating rental: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Cancel Rental
  const handleCancelRental = async () => {
    if (!rentalToCancel) return;
    setIsProcessing(true);
    try {
      const v = getVehicle(rentalToCancel.vehicleId);
      const c = getCustomer(rentalToCancel.customerId);
      const phone = rentalToCancel.customerPhone || c?.phone || '';

      const updated = await rentalApi.update(rentalToCancel.id, {
        ...rentalToCancel,
        status: 'Cancelled',
        bookingStatus: 'Cancelled',
      });

      const nextRentals = rentals.map((r) => (r.id === updated.id ? updated : r));
      setRentals(nextRentals);
      await syncVehicleAvailability(rentalToCancel.vehicleId, nextRentals);

      let smsNotice = '';
      try {
        const smsRes = await smsApi.send({
          bookingId: rentalToCancel.bookingId || `BK-2026-${rentalToCancel.id}`,
          rentalId: rentalToCancel.id,
          customerName: rentalToCancel.customerName || c?.name,
          customerPhone: phone,
          vehicleName: v?.name,
          event: 'BOOKING_CANCELLED',
        });
        if (smsRes.status === 'SENT') {
          smsNotice = ` (Cancellation SMS sent via ${smsRes.provider})`;
        } else if (smsRes.status === 'UNAVAILABLE') {
          smsNotice = ` (SMS service unconfigured in .env)`;
        }
      } catch (smsErr) {
        console.warn('SMS cancel dispatch note:', smsErr);
      }

      setSuccessMessage(`Rental #${rentalToCancel.bookingId || rentalToCancel.id} cancelled successfully.${smsNotice}`);
      setTimeout(() => setSuccessMessage(null), 5000);
      setRentalToCancel(null);
    } catch (err) {
      alert(`Error cancelling rental: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Delete Rental
  const handleDeleteRental = async () => {
    if (!rentalToDelete) return;
    setIsProcessing(true);
    try {
      await rentalApi.delete(rentalToDelete.id);
      const nextRentals = rentals.filter((r) => r.id !== rentalToDelete.id);
      setRentals(nextRentals);
      await syncVehicleAvailability(rentalToDelete.vehicleId, nextRentals);

      setSuccessMessage(`Rental record #${rentalToDelete.id} permanently deleted.`);
      setTimeout(() => setSuccessMessage(null), 4000);
      setRentalToDelete(null);
    } catch (err) {
      alert(`Error deleting rental: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // Filter rentals
  const filteredRentals = rentals.filter((r) => {
    const cust = getCustomer(r.customerId);
    const veh = getVehicle(r.vehicleId);

    // Search by customer name, vehicle name, reg number
    const query = searchQuery.trim().toLowerCase();
    if (query) {
      const custName = (cust?.name || r.customerName || '').toLowerCase();
      const vehName = veh ? veh.name.toLowerCase() : '';
      const vehReg = veh ? veh.registrationNumber.toLowerCase() : '';
      const rentalId = String(r.id).toLowerCase();
      if (!custName.includes(query) && !vehName.includes(query) && !vehReg.includes(query) && !rentalId.includes(query)) {
        return false;
      }
    }

    // Status filter
    if (statusFilter !== 'All') {
      if ((r.status || '').toLowerCase() !== statusFilter.toLowerCase()) {
        return false;
      }
    }

    // Date range filter
    if (filterStartDate) {
      if (r.startDate < filterStartDate) return false;
    }
    if (filterEndDate) {
      if (r.endDate > filterEndDate) return false;
    }

    return true;
  });

  if (loading) {
    return <LoadingSpinner message="Loading rental transaction history..." />;
  }

  return (
    <div>
      {error && <ErrorBanner message={error} onRetry={fetchData} />}

      {successMessage && (
        <div className="alert alert-success">
          <Check size={18} />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Control Bar: Search & Status & Date Filters */}
      <div className="controls-bar">
        <div className="search-input-group">
          <Search size={18} />
          <input
            type="text"
            className="form-input"
            placeholder="Search by customer, vehicle, or rental ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="filter-group">
          <select
            className="form-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ width: 'auto' }}
          >
            <option value="All">All Statuses</option>
            <option value="Pending">Pending Approval</option>
            <option value="Approved">Approved</option>
            <option value="Active">Active</option>
            <option value="Completed">Completed</option>
            <option value="Rejected">Rejected</option>
            <option value="Cancelled">Cancelled</option>
          </select>

          {/* Date range filters */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>From:</span>
            <input
              type="date"
              className="form-input"
              value={filterStartDate}
              onChange={(e) => setFilterStartDate(e.target.value)}
              style={{ width: 'auto', padding: '0.45rem 0.6rem' }}
            />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>To:</span>
            <input
              type="date"
              className="form-input"
              value={filterEndDate}
              onChange={(e) => setFilterEndDate(e.target.value)}
              style={{ width: 'auto', padding: '0.45rem 0.6rem' }}
            />
          </div>

          {(filterStartDate || filterEndDate || searchQuery || statusFilter !== 'All') && (
            <button
              className="btn btn-secondary btn-sm"
              onClick={() => {
                setSearchQuery('');
                setStatusFilter('All');
                setFilterStartDate('');
                setFilterEndDate('');
              }}
            >
              <X size={14} /> Clear
            </button>
          )}

          <button className="btn btn-primary" onClick={() => navigate('/book')}>
            <Plus size={16} /> New Booking
          </button>
        </div>
      </div>

      {/* Rentals Table */}
      {filteredRentals.length === 0 ? (
        <EmptyState
          title="No rental transactions found"
          description="Try clearing your filters or create a new booking reservation."
          action={
            <button className="btn btn-primary" onClick={() => navigate('/book')}>
              <Plus size={16} /> Create New Rental
            </button>
          }
        />
      ) : (
        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Rental ID</th>
                <th>Customer</th>
                <th>Vehicle</th>
                <th>Vehicle Owner</th>
                <th>Location</th>
                <th>Dates & Duration</th>
                <th>Daily Rate</th>
                <th>Total Amount</th>
                <th>Payment</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredRentals.map((rental) => {
                const cust = getCustomer(rental.customerId);
                const veh = getVehicle(rental.vehicleId);
                const status = rental.status || 'Active';
                const statusClass = status.toLowerCase();

                return (
                  <tr key={rental.id}>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontWeight: '700', color: 'var(--primary)' }}>
                        #{rental.id}
                      </span>
                    </td>
                    <td>
                      <div>
                        <strong>{cust ? cust.name : (rental.customerName || `Customer #${rental.customerId}`)}</strong>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {cust ? cust.phone : (rental.customerPhone || '')}
                        </div>
                      </div>
                    </td>
                    <td>
                      <div>
                        <strong>{veh ? veh.name : `Vehicle #${rental.vehicleId}`}</strong>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {veh ? `Reg: ${veh.registrationNumber} • ${veh.category}` : ''}
                        </div>
                        {Array.isArray(rental.attachments) && rental.attachments.length > 0 && (
                          <div style={{ fontSize: '0.72rem', color: 'var(--primary)', marginTop: '0.2rem', display: 'flex', alignItems: 'center', gap: '0.25rem', fontWeight: '500' }}>
                            <Paperclip size={11} /> {rental.attachments.length} attachment(s)
                          </div>
                        )}
                      </div>
                    </td>
                    <td>
                      <div>
                        <strong>{getOwner(rental.ownerId || veh?.ownerId)?.name || 'Platform Host'}</strong>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {getOwner(rental.ownerId || veh?.ownerId)?.city || 'Tadepalligudem'}
                        </div>
                      </div>
                    </td>
                    <td>
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '0.3rem',
                          fontSize: '0.78rem',
                          fontWeight: '600',
                          color: 'var(--primary)',
                          backgroundColor: 'var(--primary-light)',
                          padding: '0.2rem 0.5rem',
                          borderRadius: 'var(--radius-sm)',
                          border: '1px solid var(--primary-border)',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        <MapPin size={12} />
                        {rental.location || 'ATV Tadepalligudem'}
                      </span>
                    </td>
                    <td>
                      <div>
                        <span style={{ fontWeight: '500' }}>
                          {formatDisplayDate(rental.startDate)} → {formatDisplayDate(rental.endDate)}
                        </span>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {rental.numberOfDays || rental.days} {rental.days === 1 ? 'day' : 'days'}
                        </div>
                      </div>
                    </td>
                    <td>₹{Number(rental.dailyPrice || rental.pricePerDay || 0).toLocaleString('en-IN')} / day</td>
                    <td>
                      <strong style={{ fontSize: '0.95rem' }}>
                        ₹{Number(rental.totalAmount || 0).toLocaleString('en-IN')}
                      </strong>
                    </td>
                    <td>
                      {rental.paymentMethod ? (
                        <div>
                          <span
                            style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '0.25rem',
                              fontSize: '0.74rem',
                              fontWeight: '700',
                              color: '#5f259f',
                              backgroundColor: '#f3e8ff',
                              padding: '0.2rem 0.45rem',
                              borderRadius: '4px',
                            }}
                          >
                            {rental.paymentMethod}
                          </span>
                          {rental.transactionId && (
                            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontFamily: 'monospace', marginTop: '0.15rem' }}>
                              UTR: {rental.transactionId}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Pay at Hub</span>
                      )}
                    </td>
                    <td>
                      <span className={`badge badge-${statusClass === 'approved' ? 'available' : statusClass === 'pending' ? 'warning' : statusClass === 'rejected' ? 'danger' : statusClass}`}>
                        {rental.bookingStatus || status}
                      </span>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '0.4rem' }}>
                        {/* Quick Approve for pending */}
                        {(statusClass === 'pending') && (
                          <button
                            type="button"
                            className="btn btn-sm btn-primary"
                            onClick={() => handleApproveRental(rental)}
                            title="Approve Booking Request"
                          >
                            Approve
                          </button>
                        )}

                        {/* View details */}
                        <button
                          type="button"
                          className="btn btn-sm btn-secondary btn-icon"
                          onClick={() => setViewRental(rental)}
                          title="View Details"
                          aria-label="View Details"
                        >
                          <Eye size={15} />
                        </button>

                        {/* Edit permitted details */}
                        <button
                          type="button"
                          className="btn btn-sm btn-secondary btn-icon"
                          onClick={() => navigate(`/rentals/edit/${rental.id}`)}
                          title="Edit Rental"
                          aria-label="Edit Rental"
                        >
                          <Edit2 size={15} />
                        </button>

                        {/* Quick complete */}
                        {statusClass === 'active' && (
                          <button
                            type="button"
                            className="btn btn-sm btn-secondary btn-icon"
                            style={{ color: 'var(--success)' }}
                            onClick={() => setRentalToComplete(rental)}
                            title="Mark as Completed / Returned"
                            aria-label="Mark as Completed"
                          >
                            <CheckCircle size={15} />
                          </button>
                        )}

                        {/* Cancel rental */}
                        {(statusClass === 'active' || statusClass === 'booked') && (
                          <button
                            type="button"
                            className="btn btn-sm btn-secondary btn-icon"
                            style={{ color: 'var(--warning)' }}
                            onClick={() => setRentalToCancel(rental)}
                            title="Cancel Rental"
                            aria-label="Cancel Rental"
                          >
                            <XCircle size={15} />
                          </button>
                        )}

                        {/* Delete rental */}
                        <button
                          type="button"
                          className="btn btn-sm btn-danger-light btn-icon"
                          onClick={() => setRentalToDelete(rental)}
                          title="Delete Rental Record"
                          aria-label="Delete Rental Record"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* View Rental Modal */}
      {viewRental && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-content" style={{ maxWidth: '520px' }}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <FileText size={20} style={{ color: 'var(--primary)' }} />
                <h3>Rental Details #{viewRental.id}</h3>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setViewRental(null)}
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              {(() => {
                const c = getCustomer(viewRental.customerId);
                const v = getVehicle(viewRental.vehicleId);
                return (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem', fontSize: '0.9rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-color)', paddingBottom: '0.5rem' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Status:</span>
                      <span className={`badge badge-${(viewRental.status || '').toLowerCase()}`}>
                        {viewRental.status || 'Active'}
                      </span>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Rental Location:</span>
                      <strong style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: 'var(--primary)' }}>
                        <MapPin size={14} /> {viewRental.location || 'ATV Tadepalligudem'}
                      </strong>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Customer:</span>
                      <strong>{c ? c.name : (viewRental.customerName || 'Customer')}</strong>
                    </div>
                    {(c || viewRental.customerPhone) && (
                      <>
                        {c?.email && (
                          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <span style={{ color: 'var(--text-muted)' }}>Email:</span>
                            <span>{c.email}</span>
                          </div>
                        )}
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span style={{ color: 'var(--text-muted)' }}>Phone:</span>
                          <span>{c ? c.phone : viewRental.customerPhone}</span>
                        </div>
                        {c?.drivingLicenceNumber && (
                          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <span style={{ color: 'var(--text-muted)' }}>Licence:</span>
                            <span>{c.drivingLicenceNumber}</span>
                          </div>
                        )}
                      </>
                    )}

                    <div style={{ borderTop: '1px solid var(--border-color)', margin: '0.4rem 0' }} />

                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Vehicle:</span>
                      <strong>{v ? v.name : 'Unknown'}</strong>
                    </div>
                    {v && (
                      <>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span style={{ color: 'var(--text-muted)' }}>Registration:</span>
                          <span style={{ fontFamily: 'monospace' }}>{v.registrationNumber}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span style={{ color: 'var(--text-muted)' }}>Vehicle Owner:</span>
                          <strong>{getOwner(viewRental.ownerId || v.ownerId)?.name || 'Platform Host'}</strong>
                        </div>
                      </>
                    )}

                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Start Date:</span>
                      <strong>{formatDisplayDate(viewRental.startDate)}</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>End Date:</span>
                      <strong>{formatDisplayDate(viewRental.endDate)}</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Duration:</span>
                      <span>{viewRental.days} days</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Daily Rate:</span>
                      <span>₹{Number(viewRental.dailyPrice || 0).toLocaleString('en-IN')} / day</span>
                    </div>

                    {Array.isArray(viewRental.attachments) && viewRental.attachments.length > 0 && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ color: 'var(--text-muted)' }}>Attachments:</span>
                        <div style={{ display: 'flex', gap: '0.3rem', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                          {viewRental.attachments.map((a) => (
                            <span key={a} className="badge badge-category" style={{ textTransform: 'capitalize' }}>
                              {a.replace('_', ' ')}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* PhonePe Payment Info Section */}
                    <div
                      style={{
                        backgroundColor: '#fbf8ff',
                        border: '1px solid #e9d5ff',
                        borderRadius: 'var(--radius-sm)',
                        padding: '0.75rem',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.3rem' }}>
                        <span style={{ color: '#5f259f', fontWeight: '700', fontSize: '0.8rem' }}>Payment Method:</span>
                        <span style={{ fontWeight: '600', color: '#5f259f' }}>
                          {viewRental.paymentMethod || 'PhonePe UPI QR'}
                        </span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.3rem', fontSize: '0.82rem' }}>
                        <span style={{ color: 'var(--text-muted)' }}>PhonePe Number:</span>
                        <strong style={{ fontFamily: 'monospace' }}>
                          {viewRental.paymentNumber || '9492343566'}
                        </strong>
                      </div>
                      {viewRental.transactionId && (
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem' }}>
                          <span style={{ color: 'var(--text-muted)' }}>UTR / Transaction ID:</span>
                          <strong style={{ fontFamily: 'monospace', color: 'var(--success)' }}>
                            {viewRental.transactionId}
                          </strong>
                        </div>
                      )}
                    </div>

                    {/* SMS Notification Audit Trail */}
                    {Array.isArray(viewRental.smsNotifications) && viewRental.smsNotifications.length > 0 && (
                      <div
                        style={{
                          backgroundColor: 'var(--bg-subtle)',
                          border: '1px solid var(--border-color)',
                          borderRadius: 'var(--radius-sm)',
                          padding: '0.75rem',
                          fontSize: '0.8rem',
                        }}
                      >
                        <div style={{ fontWeight: '700', marginBottom: '0.4rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                          <FileText size={13} style={{ color: 'var(--primary)' }} /> SMS Notification Dispatch Log ({viewRental.smsNotifications.length})
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                          {viewRental.smsNotifications.map((sms, idx) => (
                            <div key={idx} style={{ padding: '0.35rem 0.5rem', backgroundColor: 'var(--card-bg)', borderRadius: '4px', border: '1px solid var(--border-color)' }}>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.2rem' }}>
                                <span style={{ fontWeight: '600', fontSize: '0.75rem' }}>{sms.event}</span>
                                <span className={`badge badge-${sms.status === 'SENT' ? 'success' : sms.status === 'UNAVAILABLE' ? 'warning' : 'danger'}`} style={{ fontSize: '0.68rem' }}>
                                  {sms.status} {sms.provider !== 'None' ? `(${sms.provider})` : ''}
                                </span>
                              </div>
                              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                                To: {sms.recipient} • {new Date(sms.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        borderTop: '1px solid var(--border-color)',
                        paddingTop: '0.65rem',
                        fontSize: '1.1rem',
                        fontWeight: '700',
                        color: 'var(--primary)',
                      }}
                    >
                      <span>Total Charge:</span>
                      <span>₹{Number(viewRental.totalAmount || 0).toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                );
              })()}
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setViewRental(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Complete Rental Confirmation */}
      <ConfirmDialog
        isOpen={rentalToComplete !== null}
        title="Complete Rental Contract"
        message={`Mark rental #${rentalToComplete?.id} as Completed? This confirms the vehicle has been returned and recalculates fleet availability.`}
        confirmText="Confirm Return / Complete"
        cancelText="Cancel"
        isDanger={false}
        isLoading={isProcessing}
        onConfirm={handleMarkCompleted}
        onCancel={() => setRentalToComplete(null)}
      />

      {/* Cancel Rental Confirmation */}
      <ConfirmDialog
        isOpen={rentalToCancel !== null}
        title="Cancel Rental Booking"
        message={`Are you sure you want to cancel rental #${rentalToCancel?.id}? The vehicle will be released for other bookings.`}
        confirmText="Yes, Cancel Rental"
        cancelText="Keep Booking"
        isDanger={true}
        isLoading={isProcessing}
        onConfirm={handleCancelRental}
        onCancel={() => setRentalToCancel(null)}
      />

      {/* Delete Rental Confirmation */}
      <ConfirmDialog
        isOpen={rentalToDelete !== null}
        title="Delete Rental Record"
        message={`Permanently remove rental record #${rentalToDelete?.id} from the database? This action cannot be reversed.`}
        confirmText="Yes, Delete Record"
        cancelText="Cancel"
        isDanger={true}
        isLoading={isProcessing}
        onConfirm={handleDeleteRental}
        onCancel={() => setRentalToDelete(null)}
      />
    </div>
  );
}
